"""Fuso horário que funciona em qualquer PC.

No Windows o Python não traz o banco de fusos (IANA). Sem o pacote `tzdata`, `ZoneInfo` falha.
Aqui há um plano B com deslocamento fixo para os fusos do Brasil (sem horário de verão desde 2019).
"""

import logging
from datetime import timedelta, timezone
from zoneinfo import ZoneInfo

log = logging.getLogger("zentry")

FALLBACK_HOURS = {
    "America/Sao_Paulo": -3, "America/Fortaleza": -3, "America/Bahia": -3, "America/Recife": -3,
    "America/Belem": -3, "America/Maceio": -3, "America/Araguaina": -3, "America/Campo_Grande": -4,
    "America/Cuiaba": -4, "America/Manaus": -4, "America/Porto_Velho": -4, "America/Boa_Vista": -4,
    "America/Rio_Branco": -5, "America/Noronha": -2, "UTC": 0,
}
_warned = set()


def get_tz(name):
    name = name or "America/Sao_Paulo"
    try:
        return ZoneInfo(name)
    except Exception:  # ZoneInfoNotFoundError, ValueError, OSError
        if name not in _warned:
            _warned.add(name)
            log.warning("Banco de fusos horários ausente para '%s' (instale 'tzdata'). Usando deslocamento fixo.", name)
        if name in FALLBACK_HOURS:
            return timezone(timedelta(hours=FALLBACK_HOURS[name]), name)
        return timezone.utc


def valid_tz(name):
    if not isinstance(name, str) or not name:
        return False
    try:
        ZoneInfo(name)
        return True
    except Exception:
        return name in FALLBACK_HOURS


def wall_epoch_to_utc(cfg, value):
    """Alguns equipamentos (Control iD) gravam a hora local do relógio como se fosse UTC.
    Converte esse "epoch de parede" para o epoch real, usando o fuso configurado."""
    from datetime import datetime
    tz = get_tz(cfg.get("timezone", "America/Sao_Paulo"))
    wall = datetime.fromtimestamp(int(value), timezone.utc).replace(tzinfo=None)
    return int(wall.replace(tzinfo=tz).timestamp())
