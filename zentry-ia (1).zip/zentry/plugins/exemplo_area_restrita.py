"""Exemplo de detector próprio (plugin). Copie este arquivo, mude o `name` e a lógica.

Como ativar: no config.json, dentro do cliente, configure
  "detectors": {"area_restrita": {"devices": ["301"], "start_hour": 19, "end_hour": 6}}
Qualquer acesso liberado nesses equipamentos fora do horário permitido gera um alerta crítico.
Sem essa configuração, o detector não faz nada.
"""

import sys, os  # noqa: E401

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from zentry.detectors import Alert, Detector  # noqa: E402


class AreaRestrita(Detector):
    name = "area_restrita"
    title = "Acesso a área restrita fora do horário"
    severity = "critico"

    def run(self, ctx):
        devices = ctx.param(self.name, "devices", [])
        if not devices:
            return []
        start, end = ctx.param(self.name, "start_hour", 19), ctx.param(self.name, "end_hour", 6)
        out = []
        for e in ctx.events(ctx.now - 20 * 60, ctx.now, kinds=("grant",)):
            if e["device_id"] not in [str(d) for d in devices]:
                continue
            h = ctx.local(e["ts"]).hour
            outside = (h >= start or h < end) if start > end else (start <= h < end)
            if outside:
                out.append(Alert(
                    self.name, self.severity,
                    f"Acesso a {ctx.device_name(e['device_id'])} às {ctx.local(e['ts']):%H:%M}: "
                    f"{ctx.user_label(e['user_id']) if e['user_id'] else 'pessoa não identificada'}",
                    "Área restrita acessada fora do horário permitido.",
                    device_id=e["device_id"], user_id=e["user_id"], key=f"e{e['id']}"))
        return out
