"""Ponto de entrada dos executáveis (PyInstaller): zentry.exe (console) e zentry-bg.exe (sem janela)."""
import os
import sys

if sys.stdout is None:  # executável sem console: evita falha ao imprimir/logar
    sys.stdout = sys.stderr = open(os.devnull, "w")

from zentry.__main__ import main  # noqa: E402

if __name__ == "__main__":
    args = sys.argv[1:] or ["run", "--open"]
    sys.exit(main(args))
