"""Painel web do Zentry IA (página única, com voz via Web Speech API do navegador)."""

PAGE = r"""<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Zentry IA</title>
<style>
:root{--bg:#f5f7fa;--card:#fff;--ink:#17202b;--mute:#5b6573;--line:#dde2e9;--accent:#0b6bcb;
--crit:#b3261e;--warn:#9a6700;--ok:#1a7f37}
@media(prefers-color-scheme:dark){:root{--bg:#0f141a;--card:#171e27;--ink:#e6ebf1;--mute:#97a3b2;--line:#2a3340;
--accent:#5aa9ff;--crit:#ff7b72;--warn:#e3b341;--ok:#56d364}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 system-ui,sans-serif}
header{display:flex;gap:12px;align-items:center;flex-wrap:wrap;padding:12px 16px;border-bottom:1px solid var(--line);background:var(--card)}
h1{font-size:18px;margin:0;flex:1}h1 small{color:var(--mute);font-weight:400}
main{max-width:1000px;margin:0 auto;padding:16px}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:16px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px}
.card b{display:block;font-size:24px}.card span{color:var(--mute);font-size:13px}
section{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px;margin-bottom:16px}
h2{font-size:15px;margin:0 0 8px}
.alert{border-top:1px solid var(--line);padding:10px 0}.alert:first-of-type{border-top:0}
.sev{font-size:11px;font-weight:700;padding:2px 6px;border-radius:4px;margin-right:6px;color:#fff}
.sev.critico{background:var(--crit)}.sev.atencao{background:var(--warn)}.sev.info{background:var(--mute)}
.detail{color:var(--mute);font-size:13px;margin:4px 0}
button,select{font:inherit;border:1px solid var(--line);background:var(--card);color:var(--ink);border-radius:8px;padding:6px 10px;cursor:pointer}
button.primary{background:var(--accent);border-color:var(--accent);color:#fff}
button.rec{background:var(--crit);border-color:var(--crit);color:#fff}
.row{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}
table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:6px 4px;border-top:1px solid var(--line);font-size:14px}
.ok{color:var(--ok)}.bad{color:var(--crit)}
#voice{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
#heard{color:var(--mute);font-size:13px;min-height:18px}#said{font-size:14px;margin-top:6px}
input[type=text]{font:inherit;flex:1;min-width:160px;border:1px solid var(--line);background:var(--card);color:var(--ink);border-radius:8px;padding:6px 10px}
</style>
</head>
<body>
<header>
  <h1>Zentry IA <small>controle de acesso inteligente</small></h1>
  <select id="client" aria-label="Cliente"></select>
  <button id="btnReport">Relatório</button>
</header>
<main>
  <section id="voice">
    <button id="btnVoice" class="primary">Ativar voz</button>
    <button id="btnTalk" disabled>Falar um comando</button>
    <label><input type="checkbox" id="chkWake" disabled> Ouvir sempre (diga "Zentry ...")</label>
    <label><input type="checkbox" id="chkSpeak" checked disabled> Falar alertas críticos</label>
    <input type="text" id="txt" placeholder='Digite um comando, ex.: "resumo" ou "alertas críticos"'>
    <button id="btnSend">Enviar</button>
    <div style="flex-basis:100%"><div id="heard"></div><div id="said"></div></div>
  </section>
  <div class="cards" id="cards"></div>
  <section><h2>Alertas em aberto</h2><div id="alerts">Carregando…</div></section>
  <section><h2>Equipamentos</h2><table id="devices"></table></section>
</main>
<script>
const params = new URLSearchParams(location.search);
const TOKEN = params.get('token') || sessionStorage.getItem('zt') || prompt('Token de acesso do Zentry:') || '';
sessionStorage.setItem('zt', TOKEN);
const H = {'Authorization': 'Bearer ' + TOKEN, 'Content-Type': 'application/json'};
const $ = id => document.getElementById(id);
const SID = sessionStorage.getItem('zsid') || (Math.random().toString(36).slice(2) + Date.now().toString(36));
sessionStorage.setItem('zsid', SID);
let client = null, spokenUpTo = Number(sessionStorage.getItem('zs') || 0), voiceOn = false;

async function api(path, opts) {
  const r = await fetch(path, Object.assign({headers: H}, opts || {}));
  if (r.status === 401) { sessionStorage.removeItem('zt'); throw new Error('Token inválido'); }
  return r.json();
}
function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
function ago(s) { if (s == null) return '—'; if (s < 90) return s + ' s'; if (s < 5400) return Math.round(s/60) + ' min'; return (s/3600).toFixed(1) + ' h'; }

async function loadAll() {
  const s = await api('/api/summary' + (client ? '?client=' + encodeURIComponent(client) : ''));
  if (!client) {
    client = s.client;
    for (const c of s.clients) { const o = el('option', '', c.name); o.value = c.id; $('client').appendChild(o); }
    $('client').value = client;
  }
  const cards = $('cards'); cards.textContent = '';
  const mk = (n, label, cls) => { const c = el('div', 'card'); c.appendChild(el('b', cls, n)); c.appendChild(el('span', '', label)); cards.appendChild(c); };
  mk(s.open_critical, 'alertas críticos', s.open_critical ? 'bad' : 'ok');
  mk(s.open_attention, 'alertas de atenção', '');
  mk(s.grants_24h, 'acessos liberados (24 h)', '');
  mk(s.fails_24h, 'negados (24 h)', '');
  mk(s.devices_offline, 'equipamentos offline', s.devices_offline ? 'bad' : 'ok');
  mk(s.patterns_known, 'padrões aprendidos', '');

  const t = $('devices'); t.textContent = '';
  const hr = el('tr'); ['Equipamento', 'Visto há', 'Eventos 24 h', 'Falhas'].forEach(x => hr.appendChild(el('th', '', x))); t.appendChild(hr);
  for (const d of s.devices) {
    const r = el('tr'); r.appendChild(el('td', '', d.name));
    r.appendChild(el('td', d.offline ? 'bad' : '', ago(d.last_seen_age)));
    r.appendChild(el('td', '', d.attempts)); r.appendChild(el('td', '', d.attempts ? Math.round(d.fail_rate * 100) + '%' : '—'));
    t.appendChild(r);
  }
  const a = await api('/api/alerts?client=' + encodeURIComponent(client));
  const box = $('alerts'); box.textContent = '';
  if (!a.alerts.length) box.textContent = 'Nenhum alerta em aberto.';
  for (const x of a.alerts) {
    const d = el('div', 'alert');
    const top = el('div'); top.appendChild(el('span', 'sev ' + x.severity, x.severity.toUpperCase()));
    top.appendChild(el('b', '', '#' + x.id + ' ' + x.title));
    if (x.count > 1) top.appendChild(el('span', 'detail', '  · visto ' + x.count + 'x'));
    d.appendChild(top);
    if (x.detail) d.appendChild(el('div', 'detail', x.detail));
    const row = el('div', 'row');
    for (const [st, label] of [['resolved', 'Marcar como resolvido']]) {
      const b = el('button', '', label); b.onclick = async () => { await api('/api/alerts/' + x.id + '/feedback', {method: 'POST', body: JSON.stringify({status: st})}); loadAll(); };
      row.appendChild(b);
    }
    d.appendChild(row); box.appendChild(d);
  }
  maybeSpeak(a.alerts);
}

// ------------------------------------------------------------- voz
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
function speak(text) {
  if (!voiceOn || !('speechSynthesis' in window)) return;
  const u = new SpeechSynthesisUtterance(text); u.lang = 'pt-BR';
  const v = speechSynthesis.getVoices().find(v => v.lang && v.lang.toLowerCase().startsWith('pt-br'));
  if (v) u.voice = v; speechSynthesis.speak(u);
}
function maybeSpeak(alerts) {
  if (!voiceOn || !$('chkSpeak').checked) return;
  const fresh = alerts.filter(a => a.severity === 'critico' && a.id > spokenUpTo).sort((x, y) => x.id - y.id);
  for (const a of fresh) { speak('Alerta crítico. ' + a.title); spokenUpTo = Math.max(spokenUpTo, a.id); }
  sessionStorage.setItem('zs', spokenUpTo);
}
async function sendCommand(text) {
  $('heard').textContent = 'Você: ' + text;
  $('said').textContent = 'Zentry está pensando…';
  const r = await api('/api/command', {method: 'POST', body: JSON.stringify({client, text, session: SID})});
  $('said').textContent = 'Zentry: ' + r.text; speak(r.speak);
  if (r.intent === 'marcar_alerta') loadAll();
}
let rec = null, wake = false;
function startRec(continuous) {
  if (!SR) { $('heard').textContent = 'Este navegador não suporta reconhecimento de voz. Use o Chrome ou Edge.'; return; }
  if (rec) { try { rec.stop(); } catch (e) {} }
  rec = new SR(); rec.lang = 'pt-BR'; rec.continuous = continuous; rec.interimResults = false;
  rec.onresult = ev => {
    const text = ev.results[ev.results.length - 1][0].transcript.trim();
    if (continuous) { const i = text.toLowerCase().indexOf('zentry'); if (i < 0) return; sendCommand(text.slice(i + 6).trim() || 'ajuda'); }
    else sendCommand(text);
  };
  rec.onend = () => { if (wake && continuous) { try { rec.start(); } catch (e) {} } };
  rec.onerror = e => { $('heard').textContent = 'Voz: ' + e.error; };
  rec.start();
}
$('btnVoice').onclick = () => {
  voiceOn = true; $('btnVoice').disabled = true; $('btnTalk').disabled = false; $('chkWake').disabled = false; $('chkSpeak').disabled = false;
  speak('Zentry ativado.'); loadAll();
};
$('btnTalk').onclick = () => { wake = false; $('chkWake').checked = false; startRec(false); };
$('chkWake').onchange = e => { wake = e.target.checked; if (wake) startRec(true); else if (rec) rec.stop(); };
$('btnSend').onclick = () => { const v = $('txt').value.trim(); if (v) { sendCommand(v); $('txt').value = ''; } };
$('txt').onkeydown = e => { if (e.key === 'Enter') $('btnSend').onclick(); };
$('client').onchange = e => { client = e.target.value; loadAll(); };
$('btnReport').onclick = () => window.open('/api/report?client=' + encodeURIComponent(client) + '&token=' + encodeURIComponent(TOKEN));
loadAll().catch(e => { $('alerts').textContent = e.message; });
setInterval(() => loadAll().catch(() => {}), 15000);
</script>
</body>
</html>
"""
