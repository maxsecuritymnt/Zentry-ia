"""Contato ativo com os equipamentos: teste de presença (probe) e coleta de logs pela API (poller).

O probe é o que permite detectar equipamento offline mesmo em modo autônomo (sem heartbeat).
O poller é opcional e serve como reforço/alternativa ao Monitor. VALIDAR em equipamento real.
"""

import json
import logging
import os
import socket
import time
import urllib.error
import urllib.request

from .ingest import _device_ts, ingest_access_log_values

log = logging.getLogger("zentry")


def probe(ip, port=80, timeout=3):
    try:
        with socket.create_connection((ip, int(port)), timeout=timeout):
            return True
    except OSError:
        return False


def probe_all(cfg, store, now=None):
    """Marca como 'visto' cada equipamento com IP que responde na porta configurada."""
    now = int(now if now is not None else time.time())
    alive = 0
    for cid, c in cfg["clients"].items():
        for did, d in c.get("devices", {}).items():
            if d.get("ip") and probe(d["ip"], d.get("port", 80)):
                store.heartbeat(cid, did, now, name=d.get("name"))
                alive += 1
    return alive


def _post(url, body, timeout=15):
    req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST",
                                 headers={"Content-Type": "application/json"})
    return json.loads(urllib.request.urlopen(req, timeout=timeout).read().decode() or "{}")


_SESSIONS = {}


_NAMES_AT = {}


def _sync_names(store, base, session, client, device_id):
    """Traz do equipamento os nomes dos usuários e os setores (áreas) dos portais, no máximo 1x a cada 2 min."""
    k = (client, device_id)
    if time.time() - _NAMES_AT.get(k, 0) < 120:
        return
    _NAMES_AT[k] = time.time()
    url = f"{base}/load_objects.fcgi?session={session}"
    try:
        for u in _post(url, {"object": "users"}).get("users", []):
            if u.get("id") not in (None, "") and u.get("name"):
                store.upsert_user(client, u["id"], u["name"], commit=False)
        store.commit()
    except Exception as e:
        log.info("Não foi possível ler os nomes de usuários de %s: %s", device_id, e)
    try:
        areas = {a.get("id"): a.get("name") for a in _post(url, {"object": "areas"}).get("areas", [])}
        sectors = {}
        for pt in _post(url, {"object": "portals"}).get("portals", []):
            sectors[str(pt.get("id"))] = areas.get(pt.get("area_to_id")) or pt.get("name") or None
        store.meta_set(f"sectors:{client}:{device_id}", json.dumps(sectors, ensure_ascii=False))
    except Exception as e:
        log.info("Não foi possível ler os setores de %s: %s", device_id, e)


def poll_device(cfg, store, client, device_id, d):
    """Busca access_logs novos pela API da Control iD (login.fcgi + load_objects.fcgi)."""
    base = f"http://{d['ip']}:{d.get('port', 80)}"
    pw = os.environ.get(d.get("password_env", ""), d.get("password", ""))
    key = f"cursor:{client}:{device_id}"
    last = int(store.meta_get(key, 0))

    def fetch(session):
        url = f"{base}/load_objects.fcgi?session={session}"
        try:
            return _post(url, {"object": "access_logs", "order": ["id"], "limit": 500,
                               "where": [{"object": "access_logs", "field": "id", "operator": ">", "value": last}]})
        except urllib.error.HTTPError as e:
            if e.code in (401, 403):
                raise
            return _post(url, {"object": "access_logs"})  # firmware que não aceita esse filtro

    # reaproveita a sessão (com consulta a cada 1-3 s, logar toda vez esgotaria as sessões do equipamento)
    sk = (base, d.get("user", "admin"))
    sess = _SESSIONS.get(sk)
    try:
        if not sess:
            raise urllib.error.HTTPError(base, 401, "sem sessão", None, None)
        data = fetch(sess)
    except urllib.error.HTTPError as e:
        if e.code not in (401, 403):
            raise
        sess = _post(f"{base}/login.fcgi", {"login": d.get("user", "admin"), "password": pw})["session"]
        _SESSIONS[sk] = sess
        data = fetch(sess)
    n = 0
    for v in data.get("access_logs", []):
        vid = int(v.get("id", 0))
        if vid <= last:
            continue
        v = dict(v)
        v.setdefault("device_id", device_id)
        # histórico antigo não é "ao vivo": só eventos recentes servem para medir atraso de relógio/offline
        recent = abs(time.time() - _device_ts(cfg, v.get("time"), time.time())) < 300
        n += int(ingest_access_log_values(store, cfg, client, device_id, v, live=recent, commit=False))
        last = max(last, vid)
    store.commit()
    store.meta_set(key, last)
    _sync_names(store, base, sess, client, device_id)
    return n


def poll_all(cfg, store):
    total = 0
    for cid, c in cfg["clients"].items():
        for did, d in c.get("devices", {}).items():
            if d.get("poll") and d.get("ip"):
                try:
                    total += poll_device(cfg, store, cid, did, d)
                except Exception as e:
                    log.warning("Falha ao coletar logs de %s/%s: %s", cid, did, e)
    return total
