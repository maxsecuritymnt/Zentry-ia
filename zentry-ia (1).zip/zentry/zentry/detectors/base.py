"""Base dos detectores: Alert, Ctx (contexto de execução) e Detector."""

from dataclasses import dataclass, field
from datetime import datetime
from ..timeutil import get_tz

from ..config import detector_cfg, device_cfg


def fmt_dur(sec):
    sec = int(sec)
    if sec < 90:
        return f"{sec}s"
    if sec < 5400:
        return f"{sec // 60} min"
    if sec < 172800:
        return f"{sec / 3600:.1f} h"
    return f"{sec // 86400} dias"


@dataclass
class Alert:
    detector: str
    severity: str  # info | atencao | critico
    title: str
    detail: str = ""
    device_id: str = None
    user_id: str = None
    key: str = ""  # complemento da "impressão digital" (evita alertas duplicados)
    evidence: dict = field(default_factory=dict)
    traits: str = ""  # características extras que entram na "assinatura" (alerta igual = mesma assinatura)


class Ctx:
    """Tudo que um detector precisa: banco, cliente, hora atual e parâmetros."""

    def __init__(self, store, client, now, cfg, tuning=None):
        self.store = store
        self.client = client
        self.now = int(now)
        self.cfg = cfg
        self.tuning = tuning or {}
        self.tz = get_tz(cfg.get("timezone", "America/Sao_Paulo"))
        self._users = {}
        self._dev_names = {}

    # parâmetros configuráveis (por detector e por cliente)
    def param(self, detector, key, default, scale=False):
        v = detector_cfg(self.cfg, self.client, detector).get(key, default)
        if scale and isinstance(v, (int, float)):
            v = v * self.mult(detector)
        return v

    def mult(self, detector):
        """Multiplicador aprendido pelo feedback (>1 = menos sensível)."""
        return self.tuning.get(detector, 1.0)

    def dev_cfg(self, device_id):
        return device_cfg(self.cfg, self.client, device_id)

    def device_name(self, device_id):
        if device_id not in self._dev_names:
            n = self.dev_cfg(device_id).get("name")
            if not n:
                r = self.store.one("SELECT name FROM devices WHERE client=? AND device_id=?",
                                   (self.client, str(device_id)))
                n = (r["name"] if r else None) or f"Equipamento {device_id}"
            self._dev_names[device_id] = n
        return self._dev_names[device_id]

    def devices(self):
        return self.store.rows("SELECT * FROM devices WHERE client=?", (self.client,))

    def events(self, t0, t1, kinds=None, device_id=None, user_id=None):
        sql = "SELECT * FROM events WHERE client=? AND ts>=? AND ts<=?"
        p = [self.client, int(t0), int(t1)]
        if kinds:
            sql += " AND kind IN (%s)" % ",".join("?" * len(kinds))
            p += list(kinds)
        if device_id is not None:
            sql += " AND device_id=?"
            p.append(str(device_id))
        if user_id is not None:
            sql += " AND user_id=?"
            p.append(str(user_id))
        return self.store.rows(sql + " ORDER BY ts, id", p)

    def local(self, ts):
        return datetime.fromtimestamp(ts, self.tz)

    def user_label(self, user_id):
        if user_id not in self._users:
            r = self.store.one("SELECT name FROM users WHERE client=? AND user_id=?",
                               (self.client, str(user_id)))
            name = r["name"] if r and r["name"] else None
            self._users[user_id] = f"{name} (#{user_id})" if name else f"usuário #{user_id}"
        return self._users[user_id]


class Detector:
    """Para criar um detector novo: herde desta classe, defina `name` e implemente `run`."""

    name = ""
    title = ""
    description = ""
    # parâmetros editáveis na interface: (chave, padrão, rótulo, unidade). Um teste confere com ctx.param().
    params = []
    severity = "atencao"

    def run(self, ctx):  # -> list[Alert]
        return []
