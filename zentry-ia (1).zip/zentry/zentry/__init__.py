"""Zentry IA - monitoramento inteligente de controle de acesso (MaxSecurity)."""

__version__ = "0.9.0"
