import csv
import json
import os
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from zentry import assistant, chat  # noqa: E402
from zentry.app import App  # noqa: E402
from zentry.config import DEFAULTS, deep_merge  # noqa: E402
from zentry.ingest import anon_id, handle_device_push, import_csv  # noqa: E402
from zentry.simulate import DEMO_CLIENT, DEMO_NOW, build_demo, demo_config  # noqa: E402

EXPECTED = {
    "equipamento_offline", "relogio_desajustado", "equipamento_silencioso", "degradacao_leitora",
    "porta_aberta_tempo_excessivo", "forca_bruta", "excesso_negacoes", "viagem_impossivel",
    "horario_atipico", "anti_passback", "credenciais_inativas", "catraca_divergencia",
}
os.environ.pop("ANTHROPIC_API_KEY", None)


def make_app(problems=True):
    tmp = tempfile.mkdtemp()
    cfg = demo_config(deep_merge(DEFAULTS, {}))
    cfg["db_path"] = os.path.join(tmp, "t.db")
    cfg["plugins_dir"] = None
    app = App(cfg)
    build_demo(app.store, cfg, problems=problems)
    return app, cfg


class FakeLLM:
    """Substitui a API: devolve respostas roteirizadas e guarda o que foi enviado."""

    def __init__(self, script):
        self.script, self.calls = list(script), []

    def __call__(self, payload):
        self.calls.append(json.loads(json.dumps(payload, default=str)))
        return self.script.pop(0)


def tool_use(name, inp=None, tid="t1"):
    return {"stop_reason": "tool_use", "content": [{"type": "tool_use", "id": tid, "name": name, "input": inp or {}}]}


def final(text):
    return {"stop_reason": "end_turn", "content": [{"type": "text", "text": text}]}


class DetectorTests(unittest.TestCase):
    def test_all_detectors_fire_on_problem_night(self):
        app, _ = make_app()
        got = {a["detector"] for a in app.engine.run_once(now=DEMO_NOW, notify=False)}
        self.assertEqual(EXPECTED - got, set(), f"detectores que não dispararam: {EXPECTED - got}")

    def test_specific_findings(self):
        app, _ = make_app()
        titles = " | ".join(a["title"] for a in app.engine.run_once(now=DEMO_NOW, notify=False))
        self.assertIn("Catraca Social - Saída: sem comunicação", titles)
        self.assertIn("possível carona", titles)
        self.assertIn("giro sem liberação", titles)
        self.assertIn("5 de ", titles)  # 5 liberações sem giro
        self.assertIn("Morador 10", titles)  # viagem impossível
        self.assertIn("Morador 5", titles)  # força bruta

    def test_healthy_operation_has_no_alerts(self):
        app, _ = make_app(problems=False)
        self.assertEqual([a["title"] for a in app.engine.run_once(now=DEMO_NOW, notify=False)], [])


class LearningTests(unittest.TestCase):
    def test_identical_alerts_are_ignored_and_counted(self):
        app, _ = make_app()
        first = app.engine.run_once(now=DEMO_NOW, notify=False)
        self.assertTrue(first)
        self.assertEqual(app.engine.run_once(now=DEMO_NOW + 60, notify=False), [])
        self.assertEqual(app.engine.run_once(now=DEMO_NOW + 120, notify=False), [])
        repeats = app.store.scalar("SELECT SUM(times-1) FROM known_patterns")
        self.assertGreater(repeats, 0, "as repetições devem ser contadas")
        self.assertEqual(app.store.scalar("SELECT COUNT(*) FROM known_patterns"), len(first))

    def test_new_pattern_alerts_but_known_pattern_does_not(self):
        app, _ = make_app()
        app.engine.run_once(now=DEMO_NOW, notify=False)
        n = DEMO_NOW + 300
        for uid, name, off in (("1007", "Morador 7", 400), ("1005", "Morador 5", 380)):  # 1005 já é conhecido
            for i in range(7):
                t = n - off + i * 30
                app.store.add_event(DEMO_CLIENT, "201", t, "deny", user_id=uid, user_name=name, now=t + 1)
        got = {(a["detector"], a["user_id"]) for a in app.engine.run_once(now=n, notify=False)}
        self.assertIn(("forca_bruta", "1007"), got)
        self.assertNotIn(("forca_bruta", "1005"), got)

    def test_resolved_problem_that_returns_is_reopened_once(self):
        app, _ = make_app()
        first = app.engine.run_once(now=DEMO_NOW, notify=False)
        off = next(a for a in first if a["detector"] == "equipamento_offline")
        app.engine.feedback(off["id"], "resolved", now=DEMO_NOW)
        again = [a for a in app.engine.run_once(now=DEMO_NOW + 60, notify=False) if a["detector"] == "equipamento_offline"]
        self.assertEqual(len(again), 1)
        self.assertTrue(again[0]["title"].startswith("Reincidência"))
        later = [a for a in app.engine.run_once(now=DEMO_NOW + 120, notify=False) if a["detector"] == "equipamento_offline"]
        self.assertEqual(later, [])

    def test_there_is_no_false_positive_status(self):
        app, _ = make_app()
        a = app.engine.run_once(now=DEMO_NOW, notify=False)[0]
        with self.assertRaises(ValueError):
            app.engine.feedback(a["id"], "false_positive")


class AssistantRulesTests(unittest.TestCase):
    def setUp(self):
        self.app, _ = make_app()
        self.app.engine.run_once(now=DEMO_NOW, notify=False)

    def ask(self, text):
        return assistant.answer(self.app, DEMO_CLIENT, text, now=DEMO_NOW)

    def test_summary_and_alerts_offline_mode(self):
        r = self.ask("Zentry, como está a situação?")
        self.assertEqual((r["intent"], r["mode"]), ("resumo", "regras"))
        self.assertIn("alerta", self.ask("zentry quais são os alertas críticos")["text"])

    def test_offline_and_counts(self):
        self.assertIn("Catraca Social - Saída", self.ask("equipamentos offline")["text"])
        self.assertIn("acessos liberados", self.ask("quantos acessos nas últimas 2 horas")["text"])
        self.assertIn("negados", self.ask("acessos negados")["text"])

    def test_resolve_alert_by_voice(self):
        aid = self.app.store.scalar("SELECT id FROM alerts WHERE detector='forca_bruta' LIMIT 1")
        r = self.ask(f"zentry marcar alerta {aid} como resolvido")
        self.assertEqual(r["intent"], "marcar_alerta")
        self.assertEqual(self.app.store.scalar("SELECT status FROM alerts WHERE id=?", (aid,)), "resolved")

    def test_question_is_never_taken_as_a_command(self):
        aid = self.app.store.scalar("SELECT id FROM alerts WHERE detector='forca_bruta' LIMIT 1")
        self.ask(f"como foi resolvido o alerta {aid}?")
        self.assertEqual(self.app.store.scalar("SELECT status FROM alerts WHERE id=?", (aid,)), "new")

    def test_false_positive_explains_instead_of_marking(self):
        aid = self.app.store.scalar("SELECT id FROM alerts WHERE detector='forca_bruta' LIMIT 1")
        r = self.ask(f"marcar alerta {aid} como falso positivo")
        self.assertIn("todo alerta é considerado útil", r["text"])
        self.assertEqual(self.app.store.scalar("SELECT status FROM alerts WHERE id=?", (aid,)), "new")

    def test_learned_patterns_question(self):
        self.assertIn("padrões de alerta", self.ask("o que você aprendeu?")["text"])

    def test_no_door_control(self):
        self.assertEqual(self.ask("abrir a porta da garagem")["intent"], "desconhecido")

    def test_notes_teach_and_forget(self):
        r = self.ask("Zentry, anote que o morador do 12 viaja toda semana")
        self.assertEqual(r["intent"], "nota")
        self.assertIn("viaja toda semana", self.ask("quais são as minhas notas")["text"])
        nid = self.app.store.scalar("SELECT id FROM notes")
        self.ask(f"esquecer nota {nid}")
        self.assertEqual(self.app.store.scalar("SELECT COUNT(*) FROM notes"), 0)


class ChatTests(unittest.TestCase):
    def setUp(self):
        self.app, self.cfg = make_app()
        self.app.engine.run_once(now=DEMO_NOW, notify=False)

    def test_tool_loop_keeps_names_private_and_restores_them(self):
        pseudo = anon_id(self.cfg, "1005")
        llm = FakeLLM([tool_use("list_alerts", {"detector": "forca_bruta"}),
                       final(f"{pseudo} teve 7 negações seguidas na garagem.")])
        out = chat.ask(self.app, DEMO_CLIENT, "o que houve com o morador 5?", now=DEMO_NOW, transport=llm)
        self.assertIn("Morador 5 (#1005)", out)  # nome real volta para quem pergunta
        sent = json.dumps(llm.calls[1]["messages"], ensure_ascii=False).lower()
        self.assertNotIn("morador 5", sent)  # e nunca vai para o modelo
        self.assertIn(pseudo.lower(), sent)
        self.assertEqual(len(llm.calls), 2)

    def test_tools_return_data_and_errors_are_handled(self):
        llm = FakeLLM([
            {"stop_reason": "tool_use", "content": [
                {"type": "tool_use", "id": "a", "name": "overview", "input": {}},
                {"type": "tool_use", "id": "b", "name": "apagar_tudo", "input": {}}]},
            final("Tudo certo.")])
        chat.ask(self.app, DEMO_CLIENT, "resuma", now=DEMO_NOW, transport=llm)
        results = llm.calls[1]["messages"][-1]["content"]
        self.assertIn("eventos_24h", results[0]["content"])
        self.assertIn("ferramenta desconhecida", results[1]["content"])

    def test_only_read_only_tools_are_exposed(self):
        names = {t["name"] for t in chat.TOOL_DEFS}
        self.assertEqual(names, {"overview", "list_alerts", "device_status", "query_events", "user_history",
                                 "known_patterns", "compare_periods", "report_snapshot"})

    def test_query_tools_work(self):
        tools = chat.Tools(self.app, DEMO_CLIENT, DEMO_NOW)
        by_dev = tools.run("query_events", {"since_hours": 24, "group_by": "device"})
        self.assertGreater(by_dev["total"], 0)
        hist = tools.run("user_history", {"user": "Morador 5", "days": 30})
        self.assertEqual(hist["usuario"], anon_id(self.cfg, "1005"))
        self.assertIn("erro", tools.run("user_history", {"user": "ninguém"}))
        self.assertIn("periodo_anterior", tools.run("compare_periods", {"days": 7}))
        self.assertTrue(tools.run("known_patterns", {})["padroes"])

    def test_notes_and_history_reach_the_prompt(self):
        assistant.answer(self.app, DEMO_CLIENT, "anote que a limpeza trabalha à noite", now=DEMO_NOW)
        llm = FakeLLM([final("Ok."), final("Certo.")])
        chat.ask(self.app, DEMO_CLIENT, "olá", session="s1", now=DEMO_NOW, transport=llm)
        chat.ask(self.app, DEMO_CLIENT, "e agora?", session="s1", now=DEMO_NOW, transport=llm)
        self.assertIn("limpeza trabalha à noite", llm.calls[0]["system"])
        self.assertEqual(llm.calls[1]["messages"][0]["content"], "olá")  # memória da conversa

    def test_assistant_uses_ai_and_falls_back_offline(self):
        llm = FakeLLM([final("A garagem está com 38% de falhas.")])
        with mock.patch.object(chat, "available", return_value=True), \
                mock.patch.object(chat, "_http_transport", return_value=llm):
            r = assistant.answer(self.app, DEMO_CLIENT, "por que a garagem está ruim?", now=DEMO_NOW)
        self.assertEqual((r["intent"], r["mode"]), ("conversa", "ia"))

        def boom(payload):
            raise chat.ChatUnavailable("sem internet")
        with mock.patch.object(chat, "available", return_value=True), \
                mock.patch.object(chat, "_http_transport", return_value=boom):
            r = assistant.answer(self.app, DEMO_CLIENT, "equipamentos offline", now=DEMO_NOW)
        self.assertEqual(r["mode"], "regras")
        self.assertIn("Catraca Social - Saída", r["text"])

    def test_direct_actions_never_go_through_the_model(self):
        aid = self.app.store.scalar("SELECT id FROM alerts LIMIT 1")
        llm = FakeLLM([])  # qualquer chamada estouraria
        with mock.patch.object(chat, "available", return_value=True), \
                mock.patch.object(chat, "_http_transport", return_value=llm):
            r = assistant.answer(self.app, DEMO_CLIENT, f"marcar alerta {aid} como resolvido", now=DEMO_NOW)
        self.assertEqual(r["intent"], "marcar_alerta")
        self.assertEqual(llm.calls, [])


class IngestTests(unittest.TestCase):
    def test_monitor_push_dao_and_door(self):
        app, cfg = make_app(problems=False)
        payload = {"device_id": 101, "object_changes": [
            {"object": "access_logs", "type": "inserted",
             "values": {"id": "9001", "time": str(DEMO_NOW), "event": "7", "device_id": "101", "user_id": "1000"}}]}
        self.assertEqual(handle_device_push(app.store, cfg, "/api/notifications/dao", payload, "192.0.2.101", DEMO_NOW), 1)
        self.assertEqual(handle_device_push(app.store, cfg, "/api/notifications/dao", payload, "192.0.2.101", DEMO_NOW), 0)
        handle_device_push(app.store, cfg, "/api/notifications/door", {"device_id": 201, "id": 1, "open": True},
                           "192.0.2.201", DEMO_NOW)
        self.assertEqual(app.store.scalar("SELECT COUNT(*) FROM events WHERE kind='door_open' AND device_id='201' AND ts=?",
                                          (DEMO_NOW,)), 1)

    def test_csv_import(self):
        app, cfg = make_app(problems=False)
        path = os.path.join(tempfile.mkdtemp(), "acessos.csv")
        with open(path, "w", newline="", encoding="latin-1") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["Data/Hora", "Usuário", "Equipamento", "Resultado"])
            w.writerow(["20/10/2026 08:01:10", "Ana Souza", "Portaria Principal", "Acesso autorizado"])
            w.writerow(["20/10/2026 08:05:00", "Bruno Lima", "Portaria Principal", "Acesso negado"])
        dry = import_csv(app.store, cfg, "default", path, dry_run=True)
        self.assertEqual(dry["columns"]["ts"], "Data/Hora")
        res = import_csv(app.store, cfg, "default", path, anonymize=True)
        self.assertEqual(res["imported"], 2)
        kinds = {r["kind"] for r in app.store.rows("SELECT kind FROM events WHERE client='default'")}
        self.assertEqual(kinds, {"grant", "deny"})
        self.assertEqual(app.store.scalar("SELECT COUNT(*) FROM users WHERE client='default' AND user_id LIKE 'U-%'"), 2)


if __name__ == "__main__":
    unittest.main()
