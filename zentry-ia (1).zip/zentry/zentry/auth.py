"""Contas, senhas, sessões e auditoria.

- Senhas: PBKDF2-HMAC-SHA256 com sal aleatório (só biblioteca padrão).
- Sessões: token aleatório no cookie; no banco fica só o hash SHA-256 do token.
- Papéis: viewer (só vê) < operator (resolve alertas, anota, conversa) < admin (configura, usuários).
- Limite de tentativas de login por IP+usuário.
"""

import base64
import hashlib
import hmac
import os
import secrets
import threading
import time

ROLES = ("viewer", "operator", "admin")
ROLE_LEVEL = {r: i for i, r in enumerate(ROLES)}
PBKDF2_ITER = 240_000
MIN_PASSWORD = 8
MAX_FAILS = 5
LOCK_SECONDS = 300


class AuthError(Exception):
    pass


def hash_password(password, iterations=PBKDF2_ITER):
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return "pbkdf2$%d$%s$%s" % (iterations, base64.b64encode(salt).decode(), base64.b64encode(dk).decode())


def verify_password(password, stored):
    try:
        scheme, it, salt, dk = stored.split("$")
        if scheme != "pbkdf2":
            return False
        calc = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), base64.b64decode(salt), int(it))
        return hmac.compare_digest(calc, base64.b64decode(dk))
    except (ValueError, TypeError):
        return False


def has_role(role, needed):
    return ROLE_LEVEL.get(role, -1) >= ROLE_LEVEL[needed]


def _th(token):
    return hashlib.sha256(token.encode()).hexdigest()


class Auth:
    def __init__(self, store, cfg):
        self.store = store
        self.cfg = cfg
        self._fails = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------ contas
    def count_accounts(self):
        return self.store.scalar("SELECT COUNT(*) FROM accounts") or 0

    def _check_password_policy(self, password):
        if len(password or "") < MIN_PASSWORD:
            raise AuthError(f"A senha precisa ter pelo menos {MIN_PASSWORD} caracteres.")

    def create_account(self, username, password, role="operator", display_name=None, now=None):
        username = (username or "").strip().lower()
        if not username or len(username) > 40 or not all(c.isalnum() or c in "._-" for c in username):
            raise AuthError("Usuário inválido (use letras, números, ponto, traço).")
        if role not in ROLES:
            raise AuthError("Papel inválido.")
        self._check_password_policy(password)
        if self.store.one("SELECT 1 FROM accounts WHERE username=?", (username,)):
            raise AuthError("Esse usuário já existe.")
        self.store.conn().execute(
            "INSERT INTO accounts(username,pw_hash,role,display_name,created_at) VALUES(?,?,?,?,?)",
            (username, hash_password(password), role, display_name or username, int(now or time.time())))
        self.store.commit()
        return self.get_account(username)

    def get_account(self, username):
        r = self.store.one("SELECT id,username,role,display_name,created_at,last_login,disabled "
                           "FROM accounts WHERE username=?", ((username or "").lower(),))
        return dict(r) if r else None

    def list_accounts(self):
        return [dict(r) for r in self.store.rows(
            "SELECT id,username,role,display_name,created_at,last_login,disabled FROM accounts ORDER BY id")]

    def _admins_left(self, excluding_id):
        return self.store.scalar("SELECT COUNT(*) FROM accounts WHERE role='admin' AND disabled=0 AND id<>?",
                                 (excluding_id,)) or 0

    def update_account(self, username, role=None, disabled=None, display_name=None):
        acc = self.get_account(username)
        if not acc:
            raise AuthError("Usuário não encontrado.")
        new_role = role if role is not None else acc["role"]
        new_dis = int(disabled) if disabled is not None else acc["disabled"]
        if new_role not in ROLES:
            raise AuthError("Papel inválido.")
        if (new_role != "admin" or new_dis) and acc["role"] == "admin" and not acc["disabled"] \
                and self._admins_left(acc["id"]) == 0:
            raise AuthError("Não é possível remover o último administrador.")
        self.store.conn().execute("UPDATE accounts SET role=?,disabled=?,display_name=? WHERE id=?",
                                  (new_role, new_dis, display_name or acc["display_name"], acc["id"]))
        if new_dis:
            self.store.conn().execute("DELETE FROM sessions WHERE account_id=?", (acc["id"],))
        self.store.commit()
        return self.get_account(username)

    def set_password(self, username, password):
        self._check_password_policy(password)
        acc = self.get_account(username)
        if not acc:
            raise AuthError("Usuário não encontrado.")
        self.store.conn().execute("UPDATE accounts SET pw_hash=? WHERE id=?", (hash_password(password), acc["id"]))
        self.store.conn().execute("DELETE FROM sessions WHERE account_id=?", (acc["id"],))
        self.store.commit()

    def delete_account(self, username):
        acc = self.get_account(username)
        if not acc:
            raise AuthError("Usuário não encontrado.")
        if acc["role"] == "admin" and not acc["disabled"] and self._admins_left(acc["id"]) == 0:
            raise AuthError("Não é possível remover o último administrador.")
        self.store.conn().execute("DELETE FROM sessions WHERE account_id=?", (acc["id"],))
        self.store.conn().execute("DELETE FROM accounts WHERE id=?", (acc["id"],))
        self.store.commit()

    # ------------------------------------------------------------ login / sessão
    def _locked(self, key, now):
        with self._lock:
            n, first = self._fails.get(key, (0, now))
            if n >= MAX_FAILS and now - first < LOCK_SECONDS:
                return int(LOCK_SECONDS - (now - first))
            if now - first >= LOCK_SECONDS:
                self._fails.pop(key, None)
        return 0

    def _fail(self, key, now):
        with self._lock:
            n, first = self._fails.get(key, (0, now))
            self._fails[key] = (n + 1, first if n else now)

    def login(self, username, password, ip="", now=None):
        """Retorna (token, conta). Levanta AuthError."""
        now = now if now is not None else time.time()
        username = (username or "").strip().lower()
        key = f"{ip}|{username}"
        wait = self._locked(key, now)
        if wait:
            raise AuthError(f"Muitas tentativas. Aguarde {wait}s.")
        r = self.store.one("SELECT * FROM accounts WHERE username=?", (username,))
        # compara mesmo se o usuário não existe, para não revelar quais usuários existem
        ok = verify_password(password or "", r["pw_hash"] if r else hash_password("x", 1000))
        if not r or not ok or r["disabled"]:
            self._fail(key, now)
            raise AuthError("Usuário ou senha incorretos.")
        with self._lock:
            self._fails.pop(key, None)
        token = secrets.token_urlsafe(32)
        hours = float(self.cfg["server"].get("session_hours", 12))
        c = self.store.conn()
        c.execute("DELETE FROM sessions WHERE expires_at<?", (int(now),))
        c.execute("INSERT INTO sessions(token_hash,account_id,created_at,expires_at,ip) VALUES(?,?,?,?,?)",
                  (_th(token), r["id"], int(now), int(now + hours * 3600), ip))
        c.execute("UPDATE accounts SET last_login=? WHERE id=?", (int(now), r["id"]))
        self.store.commit()
        return token, self.get_account(username)

    def session(self, token, now=None):
        if not token:
            return None
        now = int(now if now is not None else time.time())
        r = self.store.one(
            "SELECT a.id,a.username,a.role,a.display_name,a.disabled,s.expires_at FROM sessions s "
            "JOIN accounts a ON a.id=s.account_id WHERE s.token_hash=?", (_th(token),))
        if not r or r["disabled"] or r["expires_at"] < now:
            return None
        return {"id": r["id"], "username": r["username"], "role": r["role"], "display_name": r["display_name"]}

    def logout(self, token):
        if token:
            self.store.conn().execute("DELETE FROM sessions WHERE token_hash=?", (_th(token),))
            self.store.commit()

    # ------------------------------------------------------------ chave de integração
    def api_key_ok(self, presented):
        key = self.cfg["server"].get("token") or ""
        return bool(key) and bool(presented) and hmac.compare_digest(str(presented), key)

    # ------------------------------------------------------------ auditoria
    def audit(self, username, action, detail="", ip="", now=None):
        self.store.conn().execute("INSERT INTO audit(ts,username,action,detail,ip) VALUES(?,?,?,?,?)",
                                  (int(now or time.time()), username, action, str(detail)[:500], ip))
        self.store.commit()

    def audit_list(self, limit=200):
        return [dict(r) for r in self.store.rows("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (int(limit),))]
