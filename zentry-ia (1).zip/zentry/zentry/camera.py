"""Câmera e interfonia SIP dos equipamentos (Control iD iDFace).

Documentação usada: save_screenshot.fcgi (foto da câmera), módulo `onvif` (RTSP), módulo `pjsip` + make_sip_call.fcgi.
SIP exige licença PRO no iDFace. Não validado em equipamento real.
"""

import json
import os
import urllib.error
import urllib.request

from . import devices

SIP_FIELDS = ("enabled", "server_ip", "server_port", "branch", "login", "numeric_branch_enabled", "peer_to_peer_enabled",
              "video_enabled", "open_door_enabled", "open_door_command", "auto_answer_enabled", "auto_answer_delay",
              "audio_codecs_enabled", "max_call_time", "mic_volume", "speaker_volume", "password")


class DeviceError(Exception):
    pass


def _creds(d):
    return d.get("user", "admin"), os.environ.get(d.get("password_env", ""), d.get("password", ""))


def _login(d):
    base = f"http://{d['ip']}:{d.get('port', 80)}"
    u, pw = _creds(d)
    sess = devices._post(f"{base}/login.fcgi", {"login": u, "password": pw})["session"]
    devices._SESSIONS[(base, u)] = sess
    return sess


def request(d, endpoint, body=None, raw=False, timeout=15):
    """Chamada autenticada ao equipamento; reaproveita a sessão e refaz o login se ela expirou."""
    if not d.get("ip"):
        raise DeviceError("Equipamento sem IP cadastrado.")
    base = f"http://{d['ip']}:{d.get('port', 80)}"
    u, _ = _creds(d)
    for attempt in (0, 1):
        sess = devices._SESSIONS.get((base, u)) if attempt == 0 else None
        try:
            sess = sess or _login(d)
            req = urllib.request.Request(f"{base}/{endpoint}?session={sess}", data=json.dumps(body or {}).encode(),
                                         method="POST", headers={"Content-Type": "application/json"})
            data = urllib.request.urlopen(req, timeout=timeout).read()
            return data if raw else (json.loads(data.decode() or "{}") if data else {})
        except urllib.error.HTTPError as e:
            if e.code in (401, 403) and attempt == 0:
                devices._SESSIONS.pop((base, u), None)
                continue
            raise DeviceError(f"O equipamento respondeu HTTP {e.code}.")
        except (urllib.error.URLError, OSError, ValueError) as e:
            raise DeviceError(f"Sem resposta do equipamento: {getattr(e, 'reason', e)}")


def snapshot(d, camera="rgb"):
    """Foto atual da câmera (PNG). camera = 'rgb' ou 'ir'."""
    return request(d, "save_screenshot.fcgi", {"frame_type": "camera", "camera": "ir" if camera == "ir" else "rgb"}, raw=True)


def rtsp_info(d):
    cfg = request(d, "get_configuration.fcgi", {"onvif": ["rtsp_enabled", "rtsp_port", "rtsp_username", "rtsp_codec", "rtsp_rgb"]}).get("onvif", {})
    port = cfg.get("rtsp_port") or 554
    return {"enabled": str(cfg.get("rtsp_enabled")) == "1", "port": port, "codec": cfg.get("rtsp_codec"),
            "has_login": bool(cfg.get("rtsp_username")),
            "url": f"rtsp://{d['ip']}:{port}/main_stream"}


def rtsp_set(d, enabled):
    request(d, "set_configuration.fcgi", {"onvif": {"rtsp_enabled": "1" if enabled else "0"}})
    return {"restart_needed": True}


def sip_get(d):
    cfg = request(d, "get_configuration.fcgi", {"pjsip": [f for f in SIP_FIELDS if f != "password"]}).get("pjsip", {})
    cfg["password"] = "********" if cfg.get("login") else ""
    return cfg


def sip_set(d, values):
    clean = {}
    for k, v in (values or {}).items():
        if k not in SIP_FIELDS:
            continue
        if k == "password" and (v in ("", "********", None)):
            continue
        if k == "password" and len(str(v)) > 16:
            raise DeviceError("A senha SIP aceita no máximo 16 caracteres (limite do equipamento).")
        clean[k] = "1" if v is True else "0" if v is False else str(v)
    if not clean:
        raise DeviceError("Nada para salvar.")
    request(d, "set_configuration.fcgi", {"pjsip": clean})
    return {"saved": sorted(clean), "restart_needed": "video_enabled" in clean}


def sip_status(d):
    return request(d, "get_sip_status.fcgi", {})


def sip_call(d, target):
    t = str(target or "").strip()
    if not t or len(t) > 64:
        raise DeviceError("Informe o ramal ou número de destino.")
    return request(d, "make_sip_call.fcgi", {"target": t})


def sip_hangup(d):
    return request(d, "finalize_sip_call.fcgi", {})
