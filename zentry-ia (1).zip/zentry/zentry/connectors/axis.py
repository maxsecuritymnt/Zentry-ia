"""Axis (A1001, A1601, A1210… e terminais com PACS).

A Axis envia eventos por “Regras de ação → Enviar notificação HTTP” para qualquer URL. Aponte para /api/push/generic
com os parâmetros na URL (veja `help`). Também aceita o JSON do serviço de log de eventos da Axis ({"Event":[…]}).
"""

import json
import time

from ..config import resolve_device
from .base import Connector
from .common import extract_json, norm_kind, parse_ts


def parse_axis_events(payload):
    """{"Event":[{"UtcTime","KeyValues":[{"Key","Value"}]}]} -> lista de eventos normalizados."""
    out = []
    for ev in (payload or {}).get("Event", []) or []:
        kv = {k.get("Key"): k.get("Value") for k in ev.get("KeyValues", []) or []}
        if kv.get("topic0") != "AccessControl":
            continue
        kind = norm_kind(kv.get("topic1"), "other")
        out.append({"ts": parse_ts(ev.get("UtcTime")), "kind": kind, "user_id": kv.get("CredentialToken"),
                    "user_name": kv.get("CredentialHolderName"), "portal_id": kv.get("AccessPointToken"),
                    "src_id": str(ev.get("rowid") or ev.get("UUID") or ""), "code": None})
    return out


class AxisConnector(Connector):
    name = "axis"
    label = "Axis (controladoras de porta)"
    push_path = "/api/push/axis"
    help = ("PUSH: na Axis, crie uma Regra de ação com a condição “Controle de acesso → Acesso concedido/negado” e a ação "
            "“Enviar notificação HTTP” para http://IP-DESTE-PC:8000/api/push/generic?device=ID&kind=grant&user_id=… "
            "(use uma regra para concedido e outra para negado). O ID deve ser o mesmo cadastrado aqui.")

    def handle_push(self, cfg, store, path, query, body, ip, now=None):
        now = int(now if now is not None else time.time())
        payload = extract_json(body)
        evs = parse_axis_events(payload) if isinstance(payload, dict) else []
        client, did = resolve_device(cfg, None, ip)
        store.heartbeat(client, did, now)
        n = 0
        for e in evs:
            n += int(store.add_event(client, did, e["ts"] or now, e["kind"], e["user_id"], e["user_name"], e["portal_id"],
                                     None, e["src_id"] or None, json.dumps(e, ensure_ascii=False), live=True, now=now))
        return 200, "OK", n
