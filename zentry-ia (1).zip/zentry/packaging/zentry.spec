# PyInstaller: gera dist/zentry/ com zentry.exe (console) e zentry-bg.exe (sem janela)
from PyInstaller.utils.hooks import collect_data_files, collect_submodules
import sys

hidden = collect_submodules("zentry")
datas = [("../zentry/web", "zentry/web")]
if sys.platform == "win32":
    datas += collect_data_files("tzdata")
a = Analysis(["launcher.py"], pathex=[".."], datas=datas, hiddenimports=hidden)
pyz = PYZ(a.pure)
console = EXE(pyz, a.scripts, [], exclude_binaries=True, name="zentry", console=True)
windowed = EXE(pyz, a.scripts, [], exclude_binaries=True, name="zentry-bg", console=False)
COLLECT(console, windowed, a.binaries, a.datas, name="zentry")
