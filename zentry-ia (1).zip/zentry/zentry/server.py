"""Servidor HTTP: arquivos do painel (zentry/web), API e recebimento de eventos dos equipamentos."""

import json
import logging
import mimetypes
import os
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from . import __version__, maintenance
from .api import Api, Request, Response
from .connectors import all_connectors

log = logging.getLogger("zentry")
MAX_BODY = 2 * 1024 * 1024
WEB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")
CSP = ("default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; "
       "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
SECURITY_HEADERS = {"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY",
                    "Referrer-Policy": "no-referrer", "Cache-Control": "no-store"}


def static_file(path):
    """Resolve /algo para um arquivo dentro de web/ (sem sair da pasta)."""
    rel = "index.html" if path in ("", "/") else path.lstrip("/")
    full = os.path.realpath(os.path.join(WEB_DIR, rel))
    if not full.startswith(os.path.realpath(WEB_DIR) + os.sep) or not os.path.isfile(full):
        return None
    return full


def make_handler(app, api, device_only=False):
    cfg = app.cfg

    class Handler(BaseHTTPRequestHandler):
        server_version = f"Zentry/{__version__}"

        def log_message(self, fmt, *args):
            log.debug("%s - %s", self.client_address[0], fmt % args)

        def _write(self, resp):
            body = resp.body
            if isinstance(body, (dict, list)):
                data = json.dumps(body, ensure_ascii=False, default=str).encode()
            elif isinstance(body, str):
                data = body.encode()
            else:
                data = body or b""
            ct = resp.ctype
            if ct.startswith(("text/", "application/json")) and "charset" not in ct:
                ct += "; charset=utf-8"
            self.send_response(resp.status)
            self.send_header("Content-Type", ct)
            self.send_header("Content-Length", str(len(data)))
            for k, v in {**SECURITY_HEADERS, **resp.headers}.items():
                self.send_header(k, v)
            if ct.startswith("text/html") and "Content-Security-Policy" not in resp.headers:
                self.send_header("Content-Security-Policy", CSP)
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(data)

        def _serve(self, method):
            u = urlparse(self.path)
            if device_only and not api.is_device_path(u.path):
                return self._write(Response(404, {"error": "não encontrado"}))
            qs = parse_qs(u.query)
            body, raw = {}, b""
            if method in ("POST", "PUT", "PATCH", "DELETE"):
                n = int(self.headers.get("Content-Length") or 0)
                if n > MAX_BODY:
                    return self._write(Response(413, {"error": "corpo grande demais"}))
                raw = self.rfile.read(n) if n else b""
                try:
                    body = json.loads(raw.decode() or "{}")
                except ValueError:
                    body = {}
                if cfg["server"].get("debug_dump") and (u.path.startswith("/api/notifications") or u.path.endswith(".fcgi")):
                    with open(os.path.join(cfg.get("_home", "."), "raw_dump.jsonl"), "a", encoding="utf-8") as f:
                        f.write(json.dumps({"t": int(time.time()), "ip": self.client_address[0], "path": self.path,
                                            "body": raw.decode(errors="replace")}, ensure_ascii=False) + "\n")
            if method in ("GET", "HEAD") and not (u.path.startswith("/api/") or u.path == "/health"
                                                   or u.path.startswith("/iclock/") or u.path.endswith(".fcgi")):
                f = static_file(u.path)
                if f is None:
                    f = static_file("/")  # SPA: qualquer rota desconhecida abre o painel
                    if os.path.splitext(u.path)[1]:  # mas arquivo inexistente é 404
                        return self._write(Response(404, {"error": "não encontrado"}))
                if f is None:
                    return self._write(Response(404, {"error": "painel não instalado"}))
                with open(f, "rb") as fh:
                    ctype = mimetypes.guess_type(f)[0] or "application/octet-stream"
                    return self._write(Response(200, fh.read(), ctype))
            req = Request("GET" if method == "HEAD" else method, u.path, qs, body if isinstance(body, dict) else {},
                          dict(self.headers.items()), self.client_address[0], raw)
            self._write(api.handle(req))

        def do_GET(self): self._serve("GET")
        def do_HEAD(self): self._serve("HEAD")
        def do_POST(self): self._serve("POST")
        def do_PUT(self): self._serve("PUT")
        def do_PATCH(self): self._serve("PATCH")
        def do_DELETE(self): self._serve("DELETE")

    return Handler


def _loop(fn, interval, stop, name):
    def run():
        while not stop.is_set():
            try:
                fn()
            except Exception:
                log.exception("Erro no ciclo %s", name)
            stop.wait(interval() if callable(interval) else interval)
    t = threading.Thread(target=run, name=name, daemon=True)
    t.start()
    return t


def ensure_cert(cfg):
    """Retorna (cert, key) para HTTPS. Se não existirem, gera um certificado autoassinado com o openssl (se houver)."""
    import subprocess
    from .paths import home_path
    t = cfg["server"]["tls"]
    cert, key = home_path(cfg, t.get("cert_file", "tls/zentry.crt")), home_path(cfg, t.get("key_file", "tls/zentry.key"))
    if os.path.exists(cert) and os.path.exists(key):
        return cert, key
    os.makedirs(os.path.dirname(cert), exist_ok=True)
    cmd = ["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", key, "-out", cert, "-days", "825",
           "-subj", "/CN=Zentry IA", "-addext", "subjectAltName=DNS:localhost,IP:127.0.0.1"]
    try:
        subprocess.run(cmd, check=True, capture_output=True, timeout=60)
    except (OSError, subprocess.SubprocessError) as e:
        raise RuntimeError("Não há certificado e o openssl não está disponível para gerar um. Coloque seu certificado "
                           f"em {cert} e a chave em {key}, ou desligue o HTTPS. ({e})")
    try:
        os.chmod(key, 0o600)
    except OSError:
        pass
    return cert, key


def wrap_tls(srv, cfg):
    import ssl
    cert, key = ensure_cert(cfg)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(cert, key)
    srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
    return srv


def setup_logging(cfg):
    d = os.path.join(cfg.get("_home", "."), cfg.get("logs_dir", "logs"))
    try:
        os.makedirs(d, exist_ok=True)
        from logging.handlers import RotatingFileHandler
        h = RotatingFileHandler(os.path.join(d, "zentry.log"), maxBytes=2_000_000, backupCount=5, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        logging.getLogger().addHandler(h)
    except OSError:
        pass


def serve(app, open_browser=False):
    cfg = app.cfg
    setup_logging(cfg)
    api = Api(app)
    stop = threading.Event()
    tls = bool(cfg["server"].get("tls", {}).get("enabled"))
    scheme = "https" if tls else "http"
    try:
        srv = ThreadingHTTPServer((cfg["server"]["host"], int(cfg["server"]["port"])), make_handler(app, api))
        if tls:
            wrap_tls(srv, cfg)
    except OSError:
        log.warning("A porta %s já está em uso: o Zentry provavelmente já está aberto.", cfg["server"]["port"])
        if open_browser:
            import webbrowser
            webbrowser.open(f"{scheme}://127.0.0.1:{cfg['server']['port']}/")
        return
    except RuntimeError as exc:
        log.error("HTTPS indisponível: %s", exc)
        raise SystemExit(str(exc))
    dev_srv = None
    if tls:  # equipamentos não costumam falar HTTPS com certificado próprio: porta HTTP simples, só para envio de eventos
        try:
            dev_srv = ThreadingHTTPServer((cfg["server"]["host"], int(cfg["server"].get("device_port", 8001))),
                                          make_handler(app, api, device_only=True))
            threading.Thread(target=dev_srv.serve_forever, name="device-http", daemon=True).start()
        except OSError:
            log.warning("Porta de equipamentos %s indisponível.", cfg["server"].get("device_port"))

    def restart():
        import sys
        log.warning("Reiniciando a pedido do painel…")
        try:
            srv.shutdown()
            srv.server_close()
            if dev_srv:
                dev_srv.shutdown()
                dev_srv.server_close()
        finally:
            args = [sys.executable] + (sys.argv[1:] if getattr(sys, "frozen", False) else sys.argv)
            os.execv(sys.executable, args)
    app.restart_hook = restart
    e = lambda k: (lambda: cfg["engine"][k])  # lê a cada ciclo: mudanças nas configurações valem sem reiniciar
    conns = all_connectors()
    from .devices import probe_all
    _loop(lambda: probe_all(cfg, app.store), e("probe_interval_seconds"), stop, "probe")
    _loop(lambda: [c.poll_all(cfg, app.store) for c in conns], e("poll_interval_seconds"), stop, "poll")
    _loop(lambda: (app.engine.run_once(), app.notifier.flush_outbox()), e("interval_seconds"), stop, "engine")
    _loop(lambda: maintenance.run_daily(app), 600, stop, "maintenance")
    from .updater import loop as update_loop
    threading.Thread(target=update_loop, args=(app, app.updater, stop), daemon=True, name="update").start()
    url = f"{scheme}://127.0.0.1:{cfg['server']['port']}/"
    log.info("Zentry IA %s no ar: %s (dados em %s)", __version__, url, cfg.get("_home"))
    if open_browser:
        import webbrowser
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()
        srv.server_close()
        if dev_srv:
            dev_srv.server_close()
