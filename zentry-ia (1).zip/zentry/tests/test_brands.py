import json, os, shutil, ssl, sys, tempfile, threading, time, unittest, urllib.request
from http.server import ThreadingHTTPServer
from unittest import mock
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from zentry import maintenance, settings
from zentry.api import Api, Request
from zentry.app import App
from zentry.config import init_config, load_config
from zentry.connectors import REGISTRY, device_brand, get
from zentry.connectors import hikvision, dahua, axis, zkteco
from zentry.engine import Notifier


def make(devices=None):
    d = tempfile.mkdtemp()
    path = os.path.join(d, "config.json")
    init_config(path)
    cfg = load_config(path)
    cfg["clients"] = {"c1": {"name": "C1", "devices": devices or {}, "detectors": {}}}
    cfg["llm"]["enabled"] = False
    app = App(cfg, config_path=path)
    return app, Api(app), d


def req(method, path, qs=None, raw=b"", body=None, ip="10.0.0.9", headers=None):
    return Request(method, path, qs or {}, body or {}, headers or {}, ip, raw)


class BrandParsers(unittest.TestCase):
    def test_hikvision_normalize_and_push(self):
        app, api, _ = make({"hik1": {"ip": "10.0.0.9", "brand": "hikvision"}})
        payload = {"ipAddress": "10.0.0.9", "dateTime": "2026-10-24T10:00:00-03:00", "eventType": "AccessControllerEvent",
                   "AccessControllerEvent": {"majorEventType": 5, "subEventType": 75, "employeeNoString": "42", "name": "Maria", "serialNo": 77}}
        multipart = (b'--b\r\nContent-Disposition: form-data; name="event_log"\r\nContent-Type: application/json\r\n\r\n'
                     + json.dumps(payload).encode() + b'\r\n--b--\r\n')
        r = api.handle(req("POST", "/api/push/hikvision", raw=multipart))
        self.assertEqual((r.status, r.body), (200, "OK"))
        row = app.store.one("SELECT * FROM events WHERE client='c1'")
        self.assertEqual((row["device_id"], row["kind"], row["user_id"], row["user_name"]), ("hik1", "grant", "42", "Maria"))
        # negado (76), outro major é ignorado, e repetir não duplica
        payload["AccessControllerEvent"].update(subEventType=76, serialNo=78)
        api.handle(req("POST", "/api/push/hikvision", raw=json.dumps(payload).encode()))
        payload["AccessControllerEvent"].update(majorEventType=3, serialNo=79)
        api.handle(req("POST", "/api/push/hikvision", raw=json.dumps(payload).encode()))
        api.handle(req("POST", "/api/push/hikvision", raw=multipart))
        kinds = [r["kind"] for r in app.store.rows("SELECT kind FROM events ORDER BY id")]
        self.assertEqual(kinds, ["grant", "deny"])
        # mapa personalizado
        app.cfg["hikvision_event_map"] = {"75": "deny"}
        self.assertEqual(hikvision.minor_kind(app.cfg, 5, 75), "deny")

    def test_hikvision_poll_paginates_and_keeps_cursor(self):
        app, _, _ = make({"hik1": {"ip": "1.2.3.4", "brand": "hikvision", "poll": True}})
        pages = [
            {"AcsEvent": {"responseStatusStrg": "MORE", "InfoList": [
                {"major": 5, "minor": 75, "time": "2026-10-24T09:00:00-03:00", "employeeNoString": "1", "name": "A", "serialNo": 1}]}},
            {"AcsEvent": {"responseStatusStrg": "OK", "InfoList": [
                {"major": 5, "minor": 39, "time": "2026-10-24T09:05:00-03:00", "cardNo": "999", "serialNo": 2}]}}]
        calls = []
        def transport(d, method, path, body):
            calls.append((method, path, json.loads(body)["AcsEventCond"]["searchResultPosition"]))
            return json.dumps(pages[len(calls) - 1])
        conn = get(brand="hikvision"); conn.transport = transport
        self.assertEqual(conn.poll_all(app.cfg, app.store), 2)
        self.assertEqual(calls[0][1], "/ISAPI/AccessControl/AcsEvent?format=json")
        self.assertEqual([c[2] for c in calls], [0, 1])
        self.assertEqual(int(app.store.meta_get("cursor:c1:hik1")), 1792843500)

    def test_dahua_intelbras_parse_and_poll(self):
        text = ("found=2\nrecords[0].RecNo=10\nrecords[0].CardNo=ABC\nrecords[0].UserID=7\nrecords[0].CreateTime=1792850000\n"
                "records[0].Status=1\nrecords[0].Door=0\nrecords[1].RecNo=11\nrecords[1].CardNo=DEF\nrecords[1].CreateTime=1792850100\nrecords[1].Status=0\n")
        recs = dahua.parse_records(text)
        self.assertEqual(len(recs), 2)
        self.assertEqual([dahua.normalize(r)["kind"] for r in recs], ["grant", "deny"])
        app, _, _ = make({"i1": {"ip": "1.1.1.1", "brand": "intelbras", "poll": True}})
        conn = get(brand="intelbras"); conn.transport = lambda d, m, p, b: text
        self.assertEqual(conn.poll_all(app.cfg, app.store), 2)
        self.assertEqual(conn.poll_all(app.cfg, app.store), 0)  # cursor RecNo evita repetir
        self.assertEqual(app.store.scalar("SELECT COUNT(*) FROM events"), 2)

    def test_axis_events_and_generic_url_push(self):
        payload = {"Event": [{"rowid": 5, "UtcTime": "2026-10-24T13:00:00Z", "KeyValues": [
            {"Key": "topic0", "Value": "AccessControl"}, {"Key": "topic1", "Value": "AccessDenied"},
            {"Key": "CredentialHolderName", "Value": "João"}, {"Key": "CredentialToken", "Value": "c9"}]}]}
        self.assertEqual(axis.parse_axis_events(payload)[0]["kind"], "deny")
        app, api, _ = make({"ax1": {"ip": "10.0.0.9", "brand": "axis"}})
        api.handle(req("POST", "/api/push/axis", raw=json.dumps(payload).encode()))
        self.assertEqual(app.store.one("SELECT kind,user_name FROM events")["user_name"], "João")
        r = api.handle(req("GET", "/api/push/generic", qs={"device": ["ax1"], "kind": ["Liberado"], "user_id": ["5"], "user_name": ["Zé"]}))
        self.assertEqual(r.status, 200)
        r = api.handle(req("POST", "/api/push/generic", raw=json.dumps({"events": [{"device": "ax1", "kind": "turn"}, {"device": "ax1", "kind": "deny", "user_id": "9"}]}).encode()))
        self.assertEqual(app.store.scalar("SELECT COUNT(*) FROM events"), 4)
        self.assertEqual(api.handle(req("GET", "/api/push/generic")).status, 400)

    def test_zkteco_flow(self):
        app, api, _ = make({"SN123": {"brand": "zkteco", "name": "ZK"}})
        hs = api.handle(req("GET", "/iclock/cdata", qs={"SN": ["SN123"], "options": ["all"]}))
        self.assertIn("Realtime=1", hs.body)
        body = b"time=2026-10-24 10:00:00\tpin=15\tcardno=0\teventtype=0\tindex=1\tlinkid=1\ntime=2026-10-24 10:01:00\tpin=16\teventtype=27\tindex=2\n"
        r = api.handle(req("POST", "/iclock/cdata", qs={"SN": ["SN123"], "table": ["rtlog"]}, raw=body))
        self.assertEqual(r.body, "OK")
        self.assertEqual([x["kind"] for x in app.store.rows("SELECT kind FROM events ORDER BY ts")], ["grant", "deny"])
        att = b"21\t2026-10-24 11:00:00\t0\t1\t0\n"
        api.handle(req("POST", "/iclock/cdata", qs={"SN": ["SN123"], "table": ["ATTLOG"]}, raw=att))
        self.assertEqual(app.store.scalar("SELECT COUNT(*) FROM events WHERE device_id='SN123'"), 3)

    def test_push_blocked_for_unlisted_ip_but_key_allows(self):
        app, api, _ = make({"d": {"brand": "generic"}})
        app.cfg["server"]["allowed_device_ips"] = ["192.168.1.5"]
        q = {"device": ["d"], "kind": ["grant"]}
        self.assertEqual(api.handle(req("GET", "/api/push/generic", qs=q, ip="6.6.6.6")).status, 403)
        self.assertEqual(api.handle(req("GET", "/api/push/generic", qs=q, ip="192.168.1.5")).status, 200)
        key = app.cfg["server"]["token"]
        self.assertEqual(api.handle(req("GET", "/api/push/generic", qs=q, ip="6.6.6.6", headers={"Authorization": "Bearer " + key})).status, 200)

    def test_brand_resolution_and_registry(self):
        cfg = {"clients": {"c": {"connector": "hikvision", "devices": {"a": {}, "b": {"brand": "axis"}}}}}
        self.assertEqual(device_brand(cfg, "c", cfg["clients"]["c"]["devices"]["a"]), "hikvision")
        self.assertEqual(device_brand(cfg, "c", cfg["clients"]["c"]["devices"]["b"]), "axis")
        for n in ("controlid", "hikvision", "intelbras", "dahua", "axis", "zkteco", "generic"):
            self.assertIn(n, REGISTRY)


class Improvements(unittest.TestCase):
    def test_device_password_masked_and_preserved(self):
        app, api, _ = make({"a": {"ip": "1.1.1.1", "user": "admin", "password": "s3gredo", "brand": "hikvision"}})
        self.assertEqual(settings.public_view(app.cfg)["clients"]["c1"]["devices"]["a"]["password"], settings.MASK)
        view = settings.public_view(app.cfg)["clients"]
        settings.apply_clients(app.cfg, app.config_path, view)
        self.assertEqual(app.cfg["clients"]["c1"]["devices"]["a"]["password"], "s3gredo")
        view["c1"]["devices"]["a"]["brand"] = "marcax"
        with self.assertRaises(settings.SettingsError):
            settings.apply_clients(app.cfg, app.config_path, view)

    def test_recurrence_alert_only_for_separate_episodes(self):
        from zentry.detectors.base import Alert
        app, _, _ = make()
        eng = app.engine
        a = Alert("forca_bruta", "atencao", "Teste", "d", device_id="1", user_id="9", key="k")
        eng._record("c1", a, 1000)
        got = []
        t = 1000
        for i in range(12):  # mesmo problema contínuo, a cada 30 s: NÃO é recorrência
            t += 30
            got.append(eng._record("c1", a, t))
        self.assertTrue(all(x is None for x in got))
        for k in range(1, 6):  # reaparece em episódios separados (2 h entre eles)
            t += 7200
            r = eng._record("c1", a, t)
            if r is not None:
                got.append(r)
        titles = [x["title"] for x in got if x is not None]
        self.assertEqual(len(titles), 1)
        self.assertTrue(titles[0].startswith("Recorrente (5×)"))

    def test_notifier_telegram_and_ntfy(self):
        app, _, _ = make()
        app.cfg["notify"]["telegram"].update(enabled=True, bot_token="T0K", chat_id="123")
        app.cfg["notify"]["ntfy"].update(enabled=True, topic="meu-topico")
        seen = []
        def fake(req_, timeout=0):
            seen.append((req_.full_url, req_.data, dict(req_.header_items())))
            return mock.Mock(read=lambda: b"")
        with mock.patch("urllib.request.urlopen", fake):
            res = app.notifier.test_channels()
        self.assertEqual(res, {"telegram": "ok", "ntfy": "ok"})
        urls = [u for u, _, _ in seen]
        self.assertIn("https://api.telegram.org/botT0K/sendMessage", urls)
        self.assertIn("https://ntfy.sh/meu-topico", urls)
        self.assertEqual(json.loads(seen[0][1])["chat_id"], "123")
        # sem internet -> vai para a fila
        with mock.patch("urllib.request.urlopen", side_effect=OSError("sem rede")):
            app.notifier.send({"severity": "critico", "client": "c1", "title": "X", "detail": "", "id": 1, "detector": "d"})
        self.assertGreaterEqual(app.store.scalar("SELECT COUNT(*) FROM outbox WHERE channel IN ('telegram','ntfy')"), 2)

    def test_restore_backup_roundtrip(self):
        app, api, d = make()
        app.store.add_event("c1", "1", int(time.time()), "grant", user_id="1")
        name = os.path.basename(maintenance.make_backup(app))
        app.store.add_event("c1", "1", int(time.time()) + 1, "grant", user_id="2")
        self.assertEqual(app.store.scalar("SELECT COUNT(*) FROM events"), 2)
        maintenance.stage_restore(app.cfg, name)
        with self.assertRaises(ValueError):
            maintenance.stage_restore(app.cfg, "zentry-20200101-000000.db")
        app.store.conn().close()  # num reinício real o processo todo termina
        app2 = App(load_config(app.config_path), config_path=app.config_path)  # "reinício"
        self.assertEqual(app2.store.scalar("SELECT COUNT(*) FROM events"), 1)
        self.assertFalse(os.path.exists(os.path.join(d, "restore.pending")))
        self.assertGreaterEqual(len(maintenance.list_backups(app2.cfg)), 2)  # inclui cópia de segurança do estado anterior

    def test_recent_pushes_inspector(self):
        app, api, _ = make({"d": {"brand": "generic"}})
        api.handle(req("GET", "/api/push/generic", qs={"device": ["d"], "kind": ["grant"]}))
        self.assertEqual(api.recent[0]["brand"], "generic")
        self.assertEqual(api.recent[0]["events"], 1)

    @unittest.skipUnless(shutil.which("openssl"), "openssl indisponível")
    def test_https_listener(self):
        from zentry.server import make_handler, wrap_tls
        app, api, _ = make()
        app.cfg["server"]["tls"]["enabled"] = True
        srv = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(app, api))
        wrap_tls(srv, app.cfg)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        dev = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(app, api, device_only=True))
        threading.Thread(target=dev.serve_forever, daemon=True).start()
        try:
            ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
            r = urllib.request.urlopen(f"https://127.0.0.1:{srv.server_address[1]}/health", context=ctx)
            self.assertEqual(json.load(r)["ok"], True)
            self.assertEqual(urllib.request.urlopen(f"http://127.0.0.1:{dev.server_address[1]}/health").status, 200)
            with self.assertRaises(urllib.error.HTTPError) as cm:  # a porta de equipamentos não serve painel nem API
                urllib.request.urlopen(f"http://127.0.0.1:{dev.server_address[1]}/api/overview")
            self.assertEqual(cm.exception.code, 404)
            self.assertIn("Secure", api._cookie("x", 10))
        finally:
            srv.shutdown(); dev.shutdown()


if __name__ == "__main__":
    unittest.main()
