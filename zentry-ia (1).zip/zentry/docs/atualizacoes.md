# Atualizações

## Para quem usa
Quando existe uma versão nova, aparece uma faixa no topo do painel: **“Atualização disponível: Zentry X.Y.Z”**, com o botão **Novidades** e, para administradores no Windows, **Baixar e instalar**. O Zentry baixa o instalador, confere a soma SHA-256 oficial, faz um backup do banco, instala e reabre sozinho (o Windows pede a confirmação de administrador). Dados, contas e configurações são mantidos.
Fora do Windows (ou se a versão não trouxer a soma de verificação) a faixa leva à página da versão para baixar manualmente.

Configure em **Configurações → Atualizações**: informe o repositório do GitHub (`dono/nome`) onde as versões são publicadas. Sem isso, o Zentry não consulta nada. “Verificar agora” força a consulta.

## Para quem publica
1. Atualize `zentry/__init__.py` (versão), `CHANGELOG.md` e `installer/zentry.iss`.
2. `git tag v0.6.0 && git push --tags`.
3. O GitHub Actions (`release.yml`) gera o instalador, assina (se houver certificado nos *secrets* `CODESIGN_PFX_BASE64` e `CODESIGN_PASSWORD`), cria o `.sha256` e publica a *Release*. O texto da Release vira “Novidades” no painel.
4. Em até 12 horas (ou ao clicar em “Verificar agora”) todos os Zentry instalados mostram o aviso.

Segurança: só são aceitos downloads por HTTPS de github.com/githubusercontent.com, e a instalação é recusada se a soma SHA-256 não bater ou não existir.
