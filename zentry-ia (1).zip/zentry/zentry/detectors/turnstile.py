"""Detectores de catraca: casa 'liberação' com 'giro'."""

from collections import defaultdict

from .base import Alert, Detector


class TurnstileMismatch(Detector):
    name = "catraca_divergencia"
    title = "Divergência entre liberação e giro da catraca"
    description = "Giro sem liberação, dois giros para uma liberação (carona) e liberações sem giro."
    params = [('match_seconds', 15, 'Tolerância entre liberação e giro', 's'), ('tailgate_seconds', 8, 'Intervalo de giros que caracteriza carona', 's'), ('lookback_minutes', 15, 'Janela de análise', 'min'), ('min_no_turn', 3, 'Liberações sem giro para alertar', 'liberações'), ('ratio_no_turn', 0.3, 'Proporção de liberações sem giro', ''), ('forced_count', 3, 'Giros sem liberação para alertar', 'giros')]
    severity = "atencao"

    def run(self, ctx):
        gap = ctx.param(self.name, "match_seconds", 15)
        tail_gap = ctx.param(self.name, "tailgate_seconds", 8)
        settle = 20
        lookback = ctx.param(self.name, "lookback_minutes", 15) * 60
        min_no_turn = int(ctx.param(self.name, "min_no_turn", 3, scale=True))
        ratio_no_turn = ctx.param(self.name, "ratio_no_turn", 0.3)
        forced_n = int(ctx.param(self.name, "forced_count", 3))
        t0, t1 = ctx.now - lookback, ctx.now - settle

        turn_devs = {r["device_id"] for r in ctx.store.rows(
            "SELECT DISTINCT device_id FROM events WHERE client=? AND kind='turn' AND ts>=?",
            (ctx.client, ctx.now - 86400))}
        for d in ctx.devices():
            if ctx.dev_cfg(d["device_id"]).get("type") == "turnstile":
                turn_devs.add(d["device_id"])

        rows = ctx.store.rows(
            "SELECT id, device_id, ts, kind FROM events WHERE client=? AND ts>=? AND ts<=? "
            "AND kind IN ('grant','turn') ORDER BY ts, id", (ctx.client, t0 - gap, ctx.now))
        by_dev = defaultdict(list)
        for r in rows:
            if r["device_id"] in turn_devs:
                by_dev[r["device_id"]].append(r)

        out = []
        for dev, evs in by_dev.items():
            credits, expired, grants_in_win = [], [], 0
            unauthorized, last_turn_ts, last_turn_ok = [], None, False
            for e in evs:
                keep = []
                for g in credits:
                    if e["ts"] - g["ts"] > gap:
                        if t0 <= g["ts"] <= t1:
                            expired.append(g)
                    else:
                        keep.append(g)
                credits = keep
                if e["kind"] == "grant":
                    credits.append(e)
                    if t0 <= e["ts"] <= t1:
                        grants_in_win += 1
                else:  # turn
                    if credits:
                        credits.pop(0)
                        last_turn_ts, last_turn_ok = e["ts"], True
                    else:
                        if e["ts"] >= t0:
                            tail = last_turn_ok and last_turn_ts is not None and e["ts"] - last_turn_ts <= tail_gap
                            unauthorized.append((e, tail))
                        last_turn_ts, last_turn_ok = e["ts"], False
            for g in credits:
                if t0 <= g["ts"] <= t1 and ctx.now - g["ts"] > gap:
                    expired.append(g)

            nm = ctx.device_name(dev)
            forced = 0
            for e, tail in unauthorized:
                if tail:
                    out.append(Alert(
                        self.name, "atencao", f"{nm}: possível carona (2 giros para 1 liberação)",
                        "Duas passagens seguidas com uma única liberação.",
                        device_id=dev, key=f"tail{e['id']}"))
                else:
                    forced += 1
                    out.append(Alert(
                        self.name, "atencao", f"{nm}: giro sem liberação",
                        "A catraca girou sem liberação registrada: passagem forçada, pulo ou falha do equipamento.",
                        device_id=dev, key=f"forced{e['id']}"))
            if forced >= forced_n:
                out.append(Alert(
                    self.name, "critico", f"{nm}: {forced} giros sem liberação em {lookback // 60} min",
                    "Padrão repetido de passagem sem autorização. Verifique a catraca e as câmeras.",
                    device_id=dev, key="forced-agg"))
            n_exp = len(expired)
            if n_exp >= min_no_turn and grants_in_win and n_exp / grants_in_win >= ratio_no_turn:
                out.append(Alert(
                    self.name, "atencao",
                    f"{nm}: {n_exp} de {grants_in_win} liberações sem giro",
                    "Muitas liberações sem passagem: sensor de giro com defeito, catraca travada ou "
                    "pessoas desistindo. Teste o sentido de giro e o sensor.",
                    device_id=dev, key="no-turn"))
        return out
