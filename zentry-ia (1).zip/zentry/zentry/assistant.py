"""Assistente Zentry: entende comandos em português (texto ou voz transcrita) e responde.

Funciona offline (regras por palavras-chave). Só faz CONSULTAS e TRIAGEM de alertas.
Por segurança, não existe comando de voz que abra porta ou altere equipamento.
"""

import logging
import re
import time
import unicodedata
from datetime import datetime
from .timeutil import get_tz

from . import chat
from .config import SEVERITY_ORDER

log = logging.getLogger("zentry")
ACTION_INTENTS = {"marcar_alerta", "ajuda", "relatorio", "aprendizado", "nota"}

RESOLVE_WORDS = ("resolvido", "resolvi", "resolver", "fechar", "fechado", "concluido", "tratado")
FALSE_WORDS = ("falso positivo", "falso", "ignorar", "ignora", "descartar")

HELP = ("Posso dizer: resumo, alertas críticos, equipamentos offline, quantos acessos hoje, "
        "acessos negados, o que você aprendeu, gerar relatório. Também posso fechar alertas, por exemplo: "
        "marcar alerta 12 como resolvido.")


def norm(s):
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9 ]+", " ", s).strip()


def _num_words(text):
    return {"um": 1, "uma": 1, "dois": 2, "duas": 2, "tres": 3, "quatro": 4, "cinco": 5, "seis": 6,
            "doze": 12, "vinte e quatro": 24}.get(text)


def _hours_from(t):
    m = re.search(r"ultim[ao]s? (\d+|\w+) hora", t)
    if m:
        v = m.group(1)
        return int(v) if v.isdigit() else _num_words(v)
    if "ultima hora" in t:
        return 1
    return None


def _speak_list(items):
    return "; ".join(items)


def rules_answer(app, client, text, engine=None, now=None):
    """Respostas por regras (offline). Retorna {"intent","text","speak"}."""
    store, cfg = app.store, app.cfg
    now = int(now if now is not None else time.time())
    tz = get_tz(cfg.get("timezone", "America/Sao_Paulo"))
    t = norm(text)
    t = re.sub(r"\b(zentry|ei|ola|oi)\b", " ", t).strip()
    t = re.sub(r"\s+", " ", t)

    def reply(intent, msg):
        return {"intent": intent, "text": msg, "speak": msg}

    if not t or t in ("ajuda", "help") or "o que voce faz" in t or "comandos" in t:
        return reply("ajuda", HELP)

    # --- triagem de alertas: "marcar alerta 12 como falso positivo"
    m = re.search(r"alerta (?:numero )?(\d+)", t)
    if m and re.match(r"^(marc\w*|fech\w*|resolv\w*|classific\w*|ignor\w*|descart\w*|dar baixa)\b", t):
        if any(w in t for w in FALSE_WORDS):
            return reply("marcar_alerta", "No Zentry todo alerta é considerado útil, e alertas iguais não se repetem. "
                                          f"Se já foi tratado, diga: marcar alerta {m.group(1)} como resolvido.")
        if any(w in t for w in RESOLVE_WORDS):
            row = (app.engine or engine).feedback(int(m.group(1)), "resolved", now)
            if row is None:
                return reply("marcar_alerta", f"Não encontrei o alerta {m.group(1)}.")
            return reply("marcar_alerta", f"Alerta {m.group(1)} marcado como resolvido.")

    if "aprendeu" in t or "aprendizado" in t or "padroes" in t or "padrao" in t:
        n = store.scalar("SELECT COUNT(*) FROM known_patterns WHERE client=?", (client,))
        new24 = store.scalar("SELECT COUNT(*) FROM known_patterns WHERE client=? AND first_seen>=?", (client, now - 86400))
        rep = store.scalar("SELECT COALESCE(SUM(times-1),0) FROM known_patterns WHERE client=?", (client,))
        return reply("aprendizado", f"Já aprendi {n} padrões de alerta, {new24} deles nas últimas 24 horas. "
                                    f"Ignorei {rep} repetições de alertas iguais.")

    if "relatorio" in t:
        return reply("relatorio", "O relatório está no botão Relatório do painel. Posso resumir a situação agora se quiser.")

    if "offline" in t or "equipamentos" in t or "status dos" in t or "sem comunicacao" in t:
        rows = store.rows("SELECT * FROM devices WHERE client=?", (client,))
        lim = cfg["engine"].get("probe_interval_seconds", 60) * 10
        off = []
        for r in rows:
            dc = cfg["clients"].get(client, {}).get("devices", {}).get(r["device_id"], {})
            if (dc.get("ip") or dc.get("heartbeat")) and r["last_seen"] and now - r["last_seen"] > lim:
                off.append(dc.get("name") or r["name"] or f"equipamento {r['device_id']}")
        if off:
            return reply("equipamentos", f"{len(off)} equipamento(s) sem comunicação: {_speak_list(off)}.")
        return reply("equipamentos", f"Todos os {len(rows)} equipamentos monitorados estão respondendo.")

    if "critico" in t or "urgente" in t or "alertas" in t or "alerta" in t or "problema" in t or "preocup" in t:
        sev = 2 if ("critico" in t or "urgente" in t) else 1
        rows = store.rows(
            "SELECT id,severity,title FROM alerts WHERE client=? AND status='new' "
            "ORDER BY created_at DESC LIMIT 100", (client,))
        rows = [r for r in rows if SEVERITY_ORDER.get(r["severity"], 0) >= sev]
        rows.sort(key=lambda r: -SEVERITY_ORDER.get(r["severity"], 0))
        if not rows:
            return reply("alertas", "Nenhum alerta crítico em aberto." if sev == 2 else "Nenhum alerta em aberto.")
        top = [f"alerta {r['id']}: {r['title']}" for r in rows[:5]]
        more = f" Mais {len(rows) - 5} no painel." if len(rows) > 5 else ""
        return reply("alertas", f"{len(rows)} alerta(s) em aberto. " + _speak_list(top) + "." + more)

    if "negad" in t or "negacao" in t or "negacoes" in t:
        t0 = now - 86400
        n = store.scalar("SELECT COUNT(*) FROM events WHERE client=? AND ts>=? AND kind IN ('deny','not_identified')",
                         (client, t0))
        tot = store.scalar("SELECT COUNT(*) FROM events WHERE client=? AND ts>=? AND kind IN ('grant','deny','not_identified')",
                           (client, t0))
        pct = f" ({n / tot:.0%})" if tot else ""
        return reply("negados", f"Nas últimas 24 horas foram {n} acessos negados ou não identificados{pct}.")

    if "acesso" in t or "quantos" in t or "passagem" in t or "passagens" in t:
        hours = _hours_from(t)
        if hours:
            t0, label = now - hours * 3600, f"nas últimas {hours} hora(s)"
        else:
            t0 = int(datetime.fromtimestamp(now, tz).replace(hour=0, minute=0, second=0, microsecond=0).timestamp())
            label = "hoje"
        n = store.scalar("SELECT COUNT(*) FROM events WHERE client=? AND ts>=? AND kind='grant'", (client, t0))
        return reply("acessos", f"{n} acessos liberados {label}.")

    if any(w in t for w in ("resumo", "situacao", "como esta", "tudo bem", "status", "panorama", "o que aconteceu", "novidade", "alguma coisa")):
        t0 = now - 86400
        n = store.scalar("SELECT COUNT(*) FROM events WHERE client=? AND ts>=? AND kind='grant'", (client, t0))
        crit = store.scalar("SELECT COUNT(*) FROM alerts WHERE client=? AND severity='critico' AND status='new'", (client,))
        att = store.scalar("SELECT COUNT(*) FROM alerts WHERE client=? AND severity='atencao' AND status='new'", (client,))
        msg = f"Nas últimas 24 horas: {n} acessos liberados. "
        msg += f"{crit} alerta(s) crítico(s) e {att} de atenção em aberto." if (crit or att) \
            else "Nenhum alerta em aberto."
        return reply("resumo", msg)

    return reply("desconhecido", "Não entendi. " + HELP)


# ------------------------------------------------------------------ notas do operador
NOTE_RE = re.compile(r"^\s*(?:zentry[,:]?\s*)?(?:anot[ae]|lembr[ae]|guard[ae]|memoriz[ae])(?:\s+(?:isso|que))?\s*[:,\-]?\s+(.+)$",
                     re.I | re.S)
DEL_NOTE_RE = re.compile(r"(?:esquec\w*|apag\w*|remov\w*)\s+(?:a\s+)?nota\s+(?:numero\s+)?(\d+)")


def _notes(app, client, text, now):
    """Ensinar o Zentry: 'anote que ...'. Salvo só por comando direto seu (nunca por dados lidos)."""
    store = app.store

    def reply(msg):
        return {"intent": "nota", "text": msg, "speak": msg}

    m = NOTE_RE.match(text)
    if m:
        note = m.group(1).strip()[:500]
        cur = store.conn().execute("INSERT INTO notes(client,text,created_at) VALUES(?,?,?)", (client, note, now))
        store.commit()
        return reply(f"Anotado como nota {cur.lastrowid}. Vou considerar isso nas próximas análises.")
    t = norm(text)
    d = DEL_NOTE_RE.search(t)
    if d:
        n = store.conn().execute("DELETE FROM notes WHERE id=? AND client=?", (int(d.group(1)), client)).rowcount
        store.commit()
        return reply(f"Nota {d.group(1)} esquecida." if n else f"Não encontrei a nota {d.group(1)}.")
    if ("notas" in t or "anotacoes" in t or "anotou" in t) and any(w in t for w in ("quais", "listar", "lista", "minhas", "o que", "mostre", "mostrar")):
        rows = store.rows("SELECT id,text FROM notes WHERE client=? ORDER BY id", (client,))
        if not rows:
            return reply("Ainda não tenho nenhuma nota. Diga, por exemplo: anote que o morador do 12 viaja toda semana.")
        return reply(f"{len(rows)} nota(s): " + " ".join(f"Nota {r['id']}: {r['text']}." for r in rows[:10]))
    return None


def answer(app, client, text, engine=None, now=None, session=None):
    """Ponto de entrada (texto ou voz transcrita). Ações diretas e notas são tratadas por regras; o resto
    é conversa livre com a IA. Sem IA/internet, responde pelas regras locais."""
    now = int(now if now is not None else time.time())
    note = _notes(app, client, text, now)
    if note:
        return note
    r = rules_answer(app, client, text, engine, now)
    if r["intent"] in ACTION_INTENTS:
        return r
    if chat.available(app.cfg):
        try:
            msg = chat.ask(app, client, text, session=session, now=now)
            return {"intent": "conversa", "text": msg, "speak": msg, "mode": "ia"}
        except chat.ChatUnavailable as e:
            log.warning("IA indisponível (%s); respondendo por regras locais.", e)
    r["mode"] = "regras"
    return r
