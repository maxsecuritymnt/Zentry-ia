/* Zentry IA — páginas de configuração (somente administradores). */
(function () {
'use strict';
const Z = window.Z, h = Z.h, api = Z.api, add = (el, k) => { for (const x of [].concat(k).flat(Infinity)) if (x != null && x !== false) el.append(x.nodeType ? x : document.createTextNode(String(x))); return el; };
const MASK = '********';
const get = (o, p) => p.reduce((a, k) => (a == null ? undefined : a[k]), o);
function put(o, p, v) { let d = o; p.slice(0, -1).forEach(k => { d = d[k] = d[k] || {}; }); d[p[p.length - 1]] = v; }

const GROUPS = {
  general: [
    ['timezone', 'Fuso horário', 'text', 'Ex.: America/Sao_Paulo'],
    ['server.host', 'Endereço de escuta', 'text', '0.0.0.0 = acessível na rede local; 127.0.0.1 = só este computador (reiniciar)'],
    ['server.port', 'Porta do painel', 'int', 'Reiniciar o Zentry para valer'],
    ['server.session_hours', 'Duração do login (horas)', 'num', ''],
    ['server.allowed_device_ips', 'IPs dos equipamentos autorizados a enviar eventos', 'lines', 'Um por linha. Vazio = aceita qualquer IP da rede.'],
    ['server.debug_dump', 'Gravar corpo bruto dos envios (diagnóstico)', 'bool', 'Use só para validar o formato dos eventos; grava raw_dump.jsonl'],
    ['engine.interval_seconds', 'Intervalo da análise (s)', 'int', ''],
    ['engine.probe_interval_seconds', 'Intervalo de verificação de presença (s)', 'int', ''],
    ['engine.poll_interval_seconds', 'Intervalo de consulta direta aos equipamentos (s)', 'int', ''],
    ['engine.reopen_resolved', 'Reabrir alerta se o problema voltar depois de resolvido', 'bool', ''],
    ['engine.episode_gap_minutes', 'Minutos de silêncio para considerar um novo episódio', 'int', 'Um problema que some por esse tempo e volta conta como nova ocorrência'],
    ['engine.recurrence_milestones', 'Avisar “já aconteceu N vezes” em', 'intlist', 'Números separados por vírgula, ex.: 5, 10, 25, 50, 100'],
    ['server.tls.enabled', 'Painel em HTTPS (conexão criptografada)', 'bool', 'Gera um certificado autoassinado se não houver um. Reiniciar para valer. Os equipamentos continuam enviando em HTTP pela porta abaixo.'],
    ['server.tls.cert_file', 'Arquivo do certificado', 'text', 'Relativo à pasta de dados'],
    ['server.tls.key_file', 'Arquivo da chave', 'text', ''],
    ['server.device_port', 'Porta HTTP só para equipamentos (com HTTPS ligado)', 'int', 'Aceita apenas o envio de eventos; não abre painel nem API'],
  ],
  notify: [
    ['notify.console', 'Mostrar alertas no console', 'bool', ''],
    ['notify.min_severity', 'Severidade mínima para notificar', 'sev', ''],
    ['notify.webhooks', 'Webhooks (Slack, Teams, WhatsApp via gateway…)', 'lines', 'Uma URL por linha'],
    ['notify.telegram.enabled', 'Telegram: enviar alertas', 'bool', 'Crie um bot com o @BotFather, mande uma mensagem a ele e informe o chat_id'],
    ['notify.telegram.bot_token', 'Telegram: token do bot', 'secret', ''],
    ['notify.telegram.chat_id', 'Telegram: chat_id (pessoa ou grupo)', 'text', ''],
    ['notify.ntfy.enabled', 'ntfy (notificação no celular): enviar alertas', 'bool', 'Instale o app ntfy e assine o mesmo tópico'],
    ['notify.ntfy.server', 'ntfy: servidor', 'text', 'Padrão https://ntfy.sh (ou o seu próprio)'],
    ['notify.ntfy.topic', 'ntfy: tópico (use um nome difícil de adivinhar)', 'text', ''],
    ['notify.ntfy.token', 'ntfy: token de acesso (opcional)', 'secret', ''],
    ['notify.voice.enabled', 'Falar alertas pelas caixas de som do PC', 'bool', ''],
    ['notify.voice.min_severity', 'Severidade mínima para falar', 'sev', ''],
    ['notify.voice.rate', 'Velocidade da voz (-10 a 10)', 'int', ''],
  ],
  ai: [
    ['llm.enabled', 'Conversar com a IA (Claude)', 'bool', 'Desligado ou sem internet: o Zentry responde por regras locais'],
    ['llm.model', 'Modelo', 'text', ''],
    ['llm.api_key', 'Chave da API Anthropic', 'secret', 'Fica só neste computador. Em branco = usa a variável de ambiente ANTHROPIC_API_KEY'],
    ['llm.send_real_names', 'Enviar nomes reais à IA', 'bool', 'Desligado (recomendado): pessoas viram códigos como U-a1b2c3 e o nome volta só na resposta'],
  ],
  update: [
    ['update.enabled', 'Verificar atualizações automaticamente', 'bool', 'Quando houver versão nova, um aviso aparece no topo do painel'],
    ['update.repo', 'Repositório das versões (GitHub)', 'text', 'Formato dono/repositório, ex.: minha-empresa/zentry-ia. As versões são as “Releases” publicadas lá.'],
    ['update.check_hours', 'Verificar a cada (horas)', 'num', ''],
  ],
  maint: [
    ['maintenance.backup_enabled', 'Backup diário automático', 'bool', ''],
    ['maintenance.backup_hour', 'Hora do backup (0–23)', 'int', ''],
    ['maintenance.backup_keep', 'Quantos backups manter', 'int', ''],
    ['maintenance.events_retention_days', 'Guardar eventos por (dias)', 'int', 'Eventos mais antigos são apagados na manutenção'],
    ['maintenance.audit_retention_days', 'Guardar auditoria por (dias)', 'int', ''],
  ],
};

function field(cfg, [path, label, type, hint], inputs) {
  const p = path.split('.'), cur = get(cfg, p);
  let el, read;
  if (type === 'bool') {
    el = h('input', { type: 'checkbox', checked: !!cur }); read = () => el.checked;
    inputs.push({ p, read, orig: !!cur });
    return h('label', { class: 'chk' }, el, h('span', {}, label), hint ? h('small', { class: 'dim', style: 'margin-left:6px' }, hint) : null);
  }
  if (type === 'sev') { el = h('select', {}, ['info', 'atencao', 'alto', 'critico'].map(v => h('option', { value: v, selected: cur === v }, Z.SEV[v]))); read = () => el.value; }
  else if (type === 'lines') { el = h('textarea', { rows: 3 }); el.value = (cur || []).join('\n'); read = () => el.value.split('\n').map(x => x.trim()).filter(Boolean); }
  else if (type === 'intlist') { el = h('input', { class: 'input', value: (cur || []).join(', ') }); read = () => el.value.split(',').map(x => parseInt(x.trim(), 10)).filter(x => !isNaN(x)); }
  else if (type === 'secret') { el = h('input', { class: 'input', type: 'password', autocomplete: 'off', placeholder: cur ? 'chave salva — deixe assim para manter' : 'sk-ant-…' }); el.value = cur ? MASK : ''; read = () => el.value; }
  else if (type === 'int' || type === 'num') { el = h('input', { class: 'input', type: 'number', step: type === 'int' ? 1 : 'any', value: cur }); read = () => (type === 'int' ? parseInt(el.value, 10) : parseFloat(el.value)); }
  else { el = h('input', { class: 'input', value: cur ?? '' }); read = () => el.value.trim(); }
  inputs.push({ p, read, orig: (type === 'lines' || type === 'intlist') ? JSON.stringify(cur || []) : cur, lines: type === 'lines' || type === 'intlist' });
  return h('label', { class: 'f' }, h('span', {}, label), el, hint ? h('small', {}, hint) : null);
}

async function formTab(root, data, group, extra, reload) {
  const inputs = [];
  const fields = GROUPS[group].map(f => field(data.config, f, inputs));
  const msg = h('div', { class: 'err', role: 'alert' });
  const save = h('button', { class: 'btn pri', onclick: async () => {
    const body = {};
    for (const i of inputs) {
      const v = i.read();
      if ((i.lines ? JSON.stringify(v) : v) !== i.orig) put(body, i.p, v);
    }
    if (!Object.keys(body).length) { Z.toast('Nada mudou.'); return; }
    try {
      const r = await api('PUT', '/api/config', body);
      Z.toast('Configurações salvas.' + (r.restart_needed ? ' Reinicie o Zentry para aplicar.' : ''));
      if (r.restart_needed && confirm('Reiniciar o Zentry agora para aplicar?')) { try { await api('POST', '/api/restart', {}); Z.toast('Reiniciando… recarregue a página em alguns segundos.'); } catch (e) { /* já caiu */ } return; }
      reload();
    } catch (e) { msg.textContent = e.message; }
  } }, 'Salvar');
  add(root, h('div', { class: 'card' }, fields, msg, h('div', { class: 'row' }, save, extra)));
}

/* ---------------------------------------------------------------- clientes e equipamentos */
function clientsTab(root, data) {
  const clients = JSON.parse(JSON.stringify(data.config.clients));
  const connectors = data.connectors;
  const msg = h('div', { class: 'err', role: 'alert' });
  const body = h('div', {});
  function draw() {
    body.replaceChildren();
    for (const [cid, c] of Object.entries(clients)) {
      c.devices = c.devices || {};
      const rows = Object.entries(c.devices).map(([did, d]) => {
        const inp = (key, ph, w) => h('input', { class: 'input', value: d[key] ?? '', placeholder: ph, style: `min-width:${w || 90}px`, 'aria-label': ph, oninput: e => { d[key] = e.target.value.trim(); if (!d[key]) delete d[key]; } });
        const sel = (key, opts) => h('select', { 'aria-label': key, onchange: e => { d[key] = e.target.value; if (!d[key]) delete d[key]; } }, opts.map(([v, l]) => h('option', { value: v, selected: (d[key] || '') === v }, l)));
        const det = h('tr', { hidden: true }, h('td', { colspan: 8 }, h('div', { class: 'grid g4', style: 'padding:6px 0 14px' },
          h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: !!d.poll, onchange: e => { if (e.target.checked) d.poll = true; else delete d.poll; } }), 'Consultar o equipamento (polling)'),
          h('label', { class: 'f' }, h('span', {}, 'Usuário do equipamento'), inp('user', 'admin')),
          h('label', { class: 'f' }, h('span', {}, 'Senha do equipamento'), h('input', { class: 'input', type: 'password', autocomplete: 'off', value: d.password || '', oninput: e => { d.password = e.target.value; if (!d.password) delete d.password; } })),
          h('label', { class: 'f' }, h('span', {}, 'Porta (opcional)'), h('input', { class: 'input', type: 'number', value: d.port || '', oninput: e => { const v = parseInt(e.target.value, 10); if (v) d.port = v; else delete d.port; } })))));
        const main = h('tr', {}, h('td', { class: 'mono' }, did), h('td', {}, inp('name', 'Nome', 150)),
          h('td', {}, h('select', { 'aria-label': 'Marca', onchange: e => { d.brand = e.target.value; if (!d.brand) delete d.brand; } }, [['', '(do cliente)']].concat(connectors.map(k => [k.id, k.label.split(' (')[0]])).map(([v, l]) => h('option', { value: v, selected: (d.brand || '') === v }, l)))),
          h('td', {}, inp('ip', 'IP', 120)),
          h('td', {}, sel('type', [['', 'tipo…'], ['face', 'Facial'], ['turnstile', 'Catraca'], ['reader', 'Leitora']])), h('td', {}, sel('direction', [['', 'sentido…'], ['in', 'Entrada'], ['out', 'Saída']])),
          h('td', {}, inp('zone', 'Zona', 90)),
          h('td', {}, h('button', { class: 'btn sm', onclick: async () => {
            try { const r = await api('POST', '/api/test/device', { client: cid, device_id: did }); Z.toast(r.detail, r.ok ? '' : 'atencao'); } catch (e) { Z.toast(e.message, 'critico'); } } }, 'Testar'),
            ' ', h('button', { class: 'btn sm', onclick: () => { det.hidden = !det.hidden; } }, 'Conexão'),
            ' ', h('button', { class: 'btn sm danger', 'aria-label': 'Remover', onclick: () => { delete c.devices[did]; draw(); } }, '✕')));
        return [main, det];
      });
      const found = h('div', { style: 'margin-top:10px' });
      const newId = h('input', { class: 'input', placeholder: 'ID do equipamento (o mesmo do iDSecure)', style: 'max-width:300px' });
      body.append(h('div', { class: 'card', style: 'margin-bottom:16px' },
        h('h2', {}, 'Cliente', h('span', { class: 'sp' }), Object.keys(clients).length > 1 ? h('button', { class: 'btn sm danger', onclick: () => { delete clients[cid]; draw(); } }, 'Remover cliente') : null),
        h('div', { class: 'grid g2' }, h('label', { class: 'f' }, h('span', {}, 'Nome'), h('input', { class: 'input', value: c.name || '', oninput: e => { c.name = e.target.value; } })),
          h('label', { class: 'f' }, h('span', {}, 'Conector (marca)'), h('select', { onchange: e => { c.connector = e.target.value; } }, connectors.map(k => h('option', { value: k.id, selected: (c.connector || 'controlid') === k.id }, k.label))))),
        h('div', { class: 'tablewrap' }, h('table', {}, h('thead', {}, h('tr', {}, ['ID', 'Nome', 'Marca', 'IP', 'Tipo', 'Sentido', 'Zona', ''].map(x => h('th', {}, x)))), h('tbody', {}, rows))),
        !rows.length ? h('div', { class: 'empty' }, 'Nenhum equipamento neste cliente.') : null,
        h('div', { class: 'row', style: 'margin-top:12px' }, newId, h('button', { class: 'btn', onclick: () => { const id = newId.value.trim(); if (!id) return; c.devices[id] = { name: 'Equipamento ' + id }; draw(); } }, '+ Adicionar equipamento'),
          h('button', { class: 'btn', onclick: async e => {
            const b = e.target; b.disabled = true; b.textContent = 'Procurando… (até 1 min)';
            try {
              const r = await api('POST', '/api/discover', {});
              found.replaceChildren(h('div', { class: 'muted' }, 'Redes varridas: ' + r.subnets.join(', ')),
                !r.devices.length ? h('div', { class: 'empty' }, 'Nada encontrado. O PC precisa estar na mesma rede do equipamento.') : null,
                ...r.devices.map(d => h('div', { class: 'row', style: 'margin-top:6px' },
                  h('span', { class: 'mono' }, d.ip), h('span', { class: 'muted' }, (d.label || 'Equipamento desconhecido') + ' · portas ' + d.ports.join(', ')),
                  h('span', { class: 'sp' }),
                  h('button', { class: 'btn sm', onclick: () => { const id = d.ip.replace(/\./g, '-'); c.devices[id] = { name: d.label || ('Equipamento ' + d.ip), ip: d.ip, ...(d.brand ? { brand: d.brand } : {}) }; draw(); Z.toast('Adicionado. Confira ID, tipo e senha e salve.'); } }, 'Adicionar'))));
            } catch (err) { Z.toast(err.message, 'critico'); }
            b.disabled = false; b.textContent = '🔎 Procurar na rede';
          } }, '🔎 Procurar na rede')),
        found));
    }
    const nn = h('input', { class: 'input', placeholder: 'Nome do novo cliente', style: 'max-width:300px' });
    body.append(h('div', { class: 'row' }, nn, h('button', { class: 'btn', onclick: () => { const n = nn.value.trim(); if (!n) return; clients[n.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'cliente'] = { name: n, devices: {}, detectors: {} }; draw(); } }, '+ Adicionar cliente'),
      h('span', { class: 'sp' }), msg, h('button', { class: 'btn pri', onclick: async () => {
        try { await api('PUT', '/api/clients', clients); Z.toast('Clientes e equipamentos salvos.'); msg.textContent = ''; } catch (e) { msg.textContent = e.message; } } }, 'Salvar')));
  }
  draw();
  add(root, [h('div', { class: 'note', style: 'margin-bottom:14px' }, 'O ID é o número do equipamento no iDSecure/Monitor (ou o número de série, na ZKTeco). Equipamentos com IP têm presença monitorada. Veja a aba “Marcas” para saber como conectar cada fabricante.'), body]);
}

/* ---------------------------------------------------------------- detectores */
async function detectorsTab(root, data) {
  const client = Z.state.client;
  const [dets] = await Promise.all([api('GET', Z.q('/api/detectors'))]);
  const clients = JSON.parse(JSON.stringify(data.config.clients));
  const cc = clients[client] = clients[client] || { devices: {}, detectors: {} };
  cc.detectors = cc.detectors || {};
  const cards = dets.detectors.map(d => {
    const ov = cc.detectors[d.name] = cc.detectors[d.name] || {};
    return h('div', { class: 'card' }, h('h2', {}, d.title), h('p', { class: 'muted', style: 'margin-top:-4px' }, d.description),
      h('div', { class: 'grid g2' }, d.params.map(p => h('label', { class: 'f' }, h('span', {}, p.label + (p.unit ? ` (${p.unit})` : '')),
        h('input', { class: 'input', type: 'number', step: 'any', value: p.value, oninput: e => { const v = parseFloat(e.target.value); if (isNaN(v) || v === p.default) delete ov[p.key]; else ov[p.key] = v; } }),
        h('small', {}, 'padrão: ' + p.default)))));
  });
  const msg = h('div', { class: 'err' });
  add(root, [h('div', { class: 'note', style: 'margin-bottom:14px' }, 'Limites deste cliente. Valores iguais ao padrão não são gravados. Para criar um detector novo, veja a pasta plugins/ e o guia em docs/.'),
    h('div', { class: 'grid g2' }, cards), h('div', { class: 'row', style: 'margin-top:14px' }, msg, h('span', { class: 'sp' }), h('button', { class: 'btn pri', onclick: async () => {
      for (const k of Object.keys(cc.detectors)) if (!Object.keys(cc.detectors[k]).length) delete cc.detectors[k];
      try { await api('PUT', '/api/clients', clients); Z.toast('Detectores salvos.'); } catch (e) { msg.textContent = e.message; } } }, 'Salvar'))]);
}

/* ---------------------------------------------------------------- usuários, backups, auditoria */
async function usersTab(root) {
  const r = await api('GET', '/api/accounts');
  const u = h('input', { class: 'input', placeholder: 'usuário' }), pw = h('input', { class: 'input', type: 'password', placeholder: 'senha (mín. 8)', autocomplete: 'new-password' });
  const role = h('select', {}, r.roles.map(x => h('option', { value: x, selected: x === 'operator' }, x === 'admin' ? 'Administrador' : x === 'operator' ? 'Operador' : 'Somente leitura')));
  const msg = h('div', { class: 'err', role: 'alert' });
  const reload = () => { root.replaceChildren(); usersTab(root); };
  add(root, [h('div', { class: 'card', style: 'margin-bottom:16px' }, h('h2', {}, 'Contas'), h('div', { class: 'tablewrap' }, h('table', {}, h('thead', {}, h('tr', {}, ['Usuário', 'Papel', 'Último acesso', ''].map(x => h('th', {}, x)))),
    h('tbody', {}, r.accounts.map(a => h('tr', {}, h('td', {}, a.username, a.disabled ? h('span', { class: 'badge b-atencao', style: 'margin-left:8px' }, 'desativado') : null),
      h('td', {}, h('select', { 'aria-label': 'Papel', onchange: async e => { try { await api('PATCH', '/api/accounts/' + a.username, { role: e.target.value }); Z.toast('Papel alterado.'); } catch (x) { Z.toast(x.message, 'critico'); reload(); } } }, r.roles.map(x => h('option', { value: x, selected: x === a.role }, x)))),
      h('td', { class: 'dim' }, Z.fmt.dt(a.last_login)),
      h('td', {}, h('button', { class: 'btn sm', onclick: async () => { const np = prompt('Nova senha para ' + a.username + ' (mín. 8 caracteres):'); if (!np) return; try { await api('PATCH', '/api/accounts/' + a.username, { password: np }); Z.toast('Senha alterada.'); } catch (x) { Z.toast(x.message, 'critico'); } } }, 'Trocar senha'), ' ',
        h('button', { class: 'btn sm', onclick: async () => { try { await api('PATCH', '/api/accounts/' + a.username, { disabled: !a.disabled }); reload(); } catch (x) { Z.toast(x.message, 'critico'); } } }, a.disabled ? 'Ativar' : 'Desativar'), ' ',
        h('button', { class: 'btn sm danger', onclick: async () => { if (!confirm('Apagar a conta ' + a.username + '?')) return; try { await api('DELETE', '/api/accounts/' + a.username); reload(); } catch (x) { Z.toast(x.message, 'critico'); } } }, 'Apagar'))))))),
    h('div', { class: 'note', style: 'margin-top:12px' }, 'Somente leitura: vê tudo. Operador: também resolve alertas, anota e conversa. Administrador: também configura e gerencia contas.')),
  h('div', { class: 'card' }, h('h2', {}, 'Nova conta'), h('div', { class: 'grid g3' }, h('label', { class: 'f' }, h('span', {}, 'Usuário'), u), h('label', { class: 'f' }, h('span', {}, 'Senha'), pw), h('label', { class: 'f' }, h('span', {}, 'Papel'), role)), msg,
    h('button', { class: 'btn pri', onclick: async () => { try { await api('POST', '/api/accounts', { username: u.value, password: pw.value, role: role.value }); Z.toast('Conta criada.'); reload(); } catch (x) { msg.textContent = x.message; } } }, 'Criar conta'))]);
}
async function backupsTab(root) {
  const r = await api('GET', '/api/backups');
  add(root, h('div', { class: 'card' }, h('h2', {}, 'Cópias do banco', h('span', { class: 'sp' }), h('button', { class: 'btn pri sm', onclick: async () => { try { await api('POST', '/api/backups', {}); Z.toast('Backup criado.'); root.replaceChildren(); backupsTab(root); } catch (x) { Z.toast(x.message, 'critico'); } } }, 'Fazer backup agora')),
    r.backups.length ? h('table', {}, h('tbody', {}, r.backups.map(b => h('tr', {}, h('td', { class: 'mono' }, b.name), h('td', { class: 'dim' }, Z.fmt.dt(b.mtime)), h('td', { class: 'dim' }, (b.size / 1024 / 1024).toFixed(2).replace('.', ',') + ' MB'),
      h('td', {}, h('a', { href: '/api/backups/' + encodeURIComponent(b.name), download: b.name }, 'Baixar'), ' ',
        h('button', { class: 'btn sm', onclick: async () => {
          if (!confirm('Restaurar ' + b.name + '? Os dados atuais serão guardados em uma cópia de segurança e o Zentry reinicia.')) return;
          try { await api('POST', '/api/backups/' + encodeURIComponent(b.name) + '/restore', {}); const r = await api('POST', '/api/restart', {}); Z.toast(r.detail + ' Recarregue a página em alguns segundos.', r.ok ? '' : 'atencao', 9000); } catch (x) { Z.toast(x.message, 'critico'); } } }, 'Restaurar')))))) : h('div', { class: 'empty' }, 'Nenhum backup ainda.'),
    h('div', { class: 'note', style: 'margin-top:12px' }, 'Restaurar guarda uma cópia do banco atual (arquivo terminado em -pre.db) antes de trocar. Se o reinício automático não for possível, feche e abra o Zentry.')));
}
async function auditTab(root) {
  const r = await api('GET', '/api/audit');
  add(root, h('div', { class: 'card' }, h('h2', {}, 'Quem fez o quê'), r.audit.length ? h('div', { class: 'tablewrap' }, h('table', {}, h('thead', {}, h('tr', {}, ['Quando', 'Usuário', 'Ação', 'Detalhe', 'IP'].map(x => h('th', {}, x)))),
    h('tbody', {}, r.audit.map(a => h('tr', {}, h('td', { class: 'dim' }, Z.fmt.dt(a.ts)), h('td', {}, a.username), h('td', { class: 'mono' }, a.action), h('td', { class: 'muted' }, a.detail), h('td', { class: 'mono dim' }, a.ip)))))) : h('div', { class: 'empty' }, 'Sem registros.')));
}

function brandsTab(root, data) {
  const base = location.protocol + '//' + location.host;
  add(root, [h('div', { class: 'note', style: 'margin-bottom:14px' }, 'Marcas suportadas. As integrações foram escritas a partir da documentação pública e ainda não foram validadas em equipamentos reais: confira o que chega em Diagnóstico → Últimos envios dos equipamentos.'),
    h('div', { class: 'grid g2' }, data.connectors.map(c => h('div', { class: 'card' }, h('h2', {}, c.label, h('span', { class: 'sp' }), h('span', { class: 'badge ' + (c.validated ? 'b-ok' : 'b-atencao') }, c.validated ? 'validado' : 'não validado')),
      h('p', { class: 'muted', style: 'margin-top:-4px' }, c.help),
      c.push_path ? h('div', { class: 'mono', style: 'font-size:12px;word-break:break-all' }, 'URL de envio: ' + base.replace(/:\d+$/, '') + ':' + (location.port || '8000') + c.push_path) : null))) ]);
}

const TABS = [['general', 'Geral'], ['update', 'Atualizações'], ['clients', 'Clientes e equipamentos'], ['brands', 'Marcas'], ['detectors', 'Detectores'], ['notify', 'Notificações e voz'], ['ai', 'Inteligência'], ['users', 'Usuários'], ['maint', 'Manutenção'], ['backups', 'Backups'], ['audit', 'Auditoria']];

Z.pages.config = async function (soft, root, token, tabArg) {
  let tab = tabArg || Z.state.cfgTab || 'general';
  Z.state.cfgTab = tab;
  const data = await api('GET', '/api/config');
  root.replaceChildren();
  const body = h('div', {});
  add(root, [h('div', { class: 'tabs', role: 'tablist' }, TABS.map(([id, l]) => h('button', { role: 'tab', class: id === tab ? 'on' : '', 'aria-selected': id === tab, onclick: () => Z.pages.config(true, root, token, id) }, l))), body]);
  if (GROUPS[tab]) {
    const extra = tab === 'notify' ? [h('button', { class: 'btn', onclick: async () => { try { const r = await api('POST', '/api/test/voice', {}); Z.toast(r.detail, r.ok ? '' : 'atencao'); } catch (e) { Z.toast(e.message, 'critico'); } } }, 'Testar voz do PC'),
      h('button', { class: 'btn', onclick: async () => { try { const r = await api('POST', '/api/test/notify', {}); const k = Object.entries(r.results); Z.toast(k.length ? k.map(([n, v]) => n + ': ' + v).join(' · ') : 'Nenhum canal ativo. Salve as configurações primeiro.', k.every(([, v]) => v === 'ok') ? '' : 'atencao', 8000); } catch (e) { Z.toast(e.message, 'critico'); } } }, 'Enviar mensagem de teste')] : null;
    const upd = tab === 'update' ? h('button', { class: 'btn', onclick: async () => {
      try { const u = await api('POST', '/api/update/check', {}); await Z.loadUpdate();
        Z.toast(u.error ? u.error : u.available ? 'Nova versão: ' + u.latest.version : 'Você está na versão mais recente (' + u.current + ').', u.error ? 'atencao' : '', 6000); } catch (e) { Z.toast(e.message, 'critico'); } } }, 'Verificar agora') : null;
    return formTab(body, data, tab, upd || extra, () => Z.pages.config(true, root, token, tab));
  }
  if (tab === 'clients') return clientsTab(body, data);
  if (tab === 'brands') return brandsTab(body, data);
  if (tab === 'detectors') return detectorsTab(body, data);
  if (tab === 'users') return usersTab(body);
  if (tab === 'backups') return backupsTab(body);
  if (tab === 'audit') return auditTab(body);
};
})();
