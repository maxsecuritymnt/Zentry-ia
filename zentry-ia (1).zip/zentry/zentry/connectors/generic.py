"""Push genérico: qualquer equipamento/sistema que consiga chamar uma URL (HTTP) ou enviar JSON.

GET/POST /api/push/generic?device=ID&kind=grant&user_id=123&user_name=Maria&ts=2026-10-24T10:00:00-03:00
JSON: {"device": "ID", "kind": "grant", "user_id": "123", "user_name": "Maria", "ts": 1792850000}
ou   {"events": [ {...}, {...} ]}
"""

import json
import time

from ..config import resolve_device
from .base import Connector
from .common import extract_json, norm_kind, parse_ts


def first(v):
    return v[0] if isinstance(v, list) and v else v


class GenericConnector(Connector):
    name = "generic"
    label = "Genérico (HTTP/JSON)"
    push_path = "/api/push/generic"
    help = ("Envie eventos para http://IP-DESTE-PC:8000/api/push/generic com device, kind (grant, deny, not_identified, turn, "
            "door_open, door_close, alarm), user_id, user_name e ts (opcional). Use a chave de integração (Configurações → Geral) "
            "no cabeçalho Authorization: Bearer … ou em ?token=…, ou cadastre o IP em “IPs autorizados”.")

    def handle_push(self, cfg, store, path, query, body, ip, now=None):
        now = int(now if now is not None else time.time())
        payload = extract_json(body) if body else None
        items = []
        if isinstance(payload, dict) and isinstance(payload.get("events"), list):
            items = payload["events"]
        elif isinstance(payload, dict):
            items = [payload]
        else:
            items = [{k: first(v) for k, v in (query or {}).items()}]
        n, valid = 0, 0
        for it in items:
            if not isinstance(it, dict) or not (it.get("device") or it.get("device_id")):
                continue
            valid += 1
            did_in = it.get("device") or it.get("device_id")
            client, did = resolve_device(cfg, did_in, ip)
            if it.get("client"):
                client = str(it["client"])
            store.heartbeat(client, did, now)
            ts = parse_ts(it.get("ts")) or now
            n += int(store.add_event(client, did, ts, norm_kind(it.get("kind"), "other"), it.get("user_id"),
                                     it.get("user_name"), it.get("portal"), None, it.get("src_id"),
                                     json.dumps(it, ensure_ascii=False, default=str), live=True, now=now))
        return (200, "OK", n) if valid else (400, "nenhum evento (informe pelo menos device e kind)", 0)
