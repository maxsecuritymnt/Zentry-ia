# Arquitetura

```
Equipamentos Control iD ──push (Monitor)──▶ server.py ─▶ api.py ─▶ ingest.py ─▶ SQLite (db.py)
        ▲                                                                   │
        └──── conectores (connectors/): presença e consulta de logs ◀────────┤
                                                       engine.py ◀ detectors/ ┘
engine ─▶ alertas + aprendizado (padrões) ─▶ notificações (console, voz, webhook, e-mail)
web/ (painel) ─▶ api.py ─▶ assistant.py / chat.py (regras offline ou Claude com ferramentas somente leitura)
```

- **Pasta de dados** (`paths.py`): `config.json`, `zentry.db`, `backups/`, `logs/`, `plugins/`. Fica fora da pasta do programa, então atualizar ou desinstalar não apaga nada.
- **Segurança** (`auth.py`): PBKDF2, sessões com hash no banco, papéis, CSRF por cabeçalho, auditoria.
- **Aprendizado** (`engine.py`): cada alerta tem uma assinatura (detector + equipamento + pessoa + características); assinatura já conhecida não se repete, assinatura nova é aprendida e avisada.
- **Conectores**: para outra marca, implemente `connectors.base.Connector` e registre em `connectors.REGISTRY`.
