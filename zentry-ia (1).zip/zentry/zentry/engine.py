"""Motor: roda os detectores, grava alertas (sem duplicar), notifica e aprende com o feedback."""

import json
import logging
import os
import re
import smtplib
import time
import urllib.request
from email.message import EmailMessage

from .config import SEVERITY_LABEL, SEVERITY_ORDER, client_name
from .detectors import Ctx, discover

log = logging.getLogger("zentry")

STATUSES = ("new", "resolved")  # todo alerta é útil; só existe aberto ou resolvido


class Notifier:
    """Console + webhooks + e-mail. Se estiver sem internet, guarda na fila (outbox) e reenvia."""

    def __init__(self, cfg, store):
        self.cfg = cfg
        self.store = store

    def format(self, alert_row):
        name = client_name(self.cfg, alert_row["client"])
        sev = SEVERITY_LABEL.get(alert_row["severity"], alert_row["severity"].upper())
        text = f"[{sev}] {name} - {alert_row['title']}"
        if alert_row["detail"]:
            text += f"\n{alert_row['detail']}"
        return text

    def send(self, alert_row):
        ncfg = self.cfg["notify"]
        if SEVERITY_ORDER.get(alert_row["severity"], 0) < SEVERITY_ORDER.get(ncfg.get("min_severity", "atencao"), 1):
            return
        text = self.format(alert_row)
        if ncfg.get("console", True):
            log.warning("ALERTA %s", text.replace("\n", " | "))
        vcfg = ncfg.get("voice", {})
        if vcfg.get("enabled") and SEVERITY_ORDER.get(alert_row["severity"], 0) >= SEVERITY_ORDER.get(
                vcfg.get("min_severity", "critico"), 2):
            from . import voice
            voice.speak(f"Alerta {alert_row['severity'].replace('atencao', 'de atenção').replace('critico', 'crítico')}. "
                        f"{alert_row['title']}", vcfg.get("rate", 0))
        payload = {"text": text, "severity": alert_row["severity"], "client": alert_row["client"],
                   "alert_id": alert_row["id"], "detector": alert_row["detector"]}
        for url in ncfg.get("webhooks", []):
            self._deliver("webhook", url, payload, queue_on_fail=True)
        if ncfg.get("telegram", {}).get("enabled"):
            self._deliver("telegram", "", {"text": text}, queue_on_fail=True)
        if ncfg.get("ntfy", {}).get("enabled"):
            self._deliver("ntfy", "", {"text": text, "title": alert_row["title"], "severity": alert_row["severity"]},
                          queue_on_fail=True)
        if ncfg.get("smtp", {}).get("host"):
            self._deliver("smtp", "", {"subject": text.split("\n")[0], "body": text}, queue_on_fail=True)

    def _deliver(self, channel, target, payload, queue_on_fail=False):
        try:
            if channel == "webhook":
                req = urllib.request.Request(
                    target, data=json.dumps(payload).encode(), method="POST",
                    headers={"Content-Type": "application/json"})
                urllib.request.urlopen(req, timeout=10).read()
            elif channel == "smtp":
                self._send_mail(payload)
            elif channel == "telegram":
                self._send_telegram(payload)
            elif channel == "ntfy":
                self._send_ntfy(payload)
            return True
        except Exception as e:  # sem internet, serviço fora do ar, etc.
            log.warning("Falha ao enviar por %s (%s). %s", channel, e,
                        "Guardado na fila." if queue_on_fail else "")
            if queue_on_fail:
                self.store.conn().execute(
                    "INSERT INTO outbox(created_at,channel,target,payload) VALUES(?,?,?,?)",
                    (int(time.time()), channel, target, json.dumps(payload)))
                self.store.commit()
            return False

    def _send_telegram(self, payload):
        t = self.cfg["notify"]["telegram"]
        if not t.get("bot_token") or not t.get("chat_id"):
            raise ValueError("Telegram sem bot_token/chat_id")
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{t['bot_token']}/sendMessage", method="POST",
            data=json.dumps({"chat_id": t["chat_id"], "text": payload["text"][:3800]}).encode(),
            headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=10).read()

    def _send_ntfy(self, payload):
        n = self.cfg["notify"]["ntfy"]
        if not n.get("topic"):
            raise ValueError("ntfy sem tópico")
        prio = {"critico": "5", "alto": "4", "atencao": "3"}.get(payload.get("severity"), "2")
        headers = {"Title": (payload.get("title") or "Zentry IA").encode("utf-8").decode("latin-1", "ignore")[:200],
                   "Priority": prio, "Tags": "rotating_light" if prio == "5" else "warning"}
        if n.get("token"):
            headers["Authorization"] = "Bearer " + n["token"]
        req = urllib.request.Request(n.get("server", "https://ntfy.sh").rstrip("/") + "/" + n["topic"],
                                     data=payload["text"].encode("utf-8"), method="POST", headers=headers)
        urllib.request.urlopen(req, timeout=10).read()

    def test_channels(self):
        """Envia uma mensagem de teste por cada canal configurado. Retorna {canal: 'ok' | erro}."""
        n = self.cfg["notify"]
        out = {}
        msg = {"text": "Zentry IA: teste de notificação. Se você recebeu isto, o canal está funcionando.",
               "title": "Teste do Zentry IA", "severity": "atencao"}
        jobs = [("telegram", n.get("telegram", {}).get("enabled"), self._send_telegram),
                ("ntfy", n.get("ntfy", {}).get("enabled"), self._send_ntfy),
                ("e-mail", bool(n.get("smtp", {}).get("host")), lambda p: self._send_mail({"subject": p["title"], "body": p["text"]}))]
        for name, on, fn in jobs:
            if on:
                try:
                    fn(msg)
                    out[name] = "ok"
                except Exception as e:
                    out[name] = str(e)
        for url in n.get("webhooks", []):
            try:
                urllib.request.urlopen(urllib.request.Request(url, data=json.dumps(msg).encode(), method="POST",
                                       headers={"Content-Type": "application/json"}), timeout=10).read()
                out["webhook " + url[:40]] = "ok"
            except Exception as e:
                out["webhook " + url[:40]] = str(e)
        return out

    def _send_mail(self, payload):
        s = self.cfg["notify"]["smtp"]
        msg = EmailMessage()
        msg["Subject"] = payload["subject"]
        msg["From"] = s.get("from", s.get("user"))
        msg["To"] = ", ".join(s.get("to", []))
        msg.set_content(payload["body"])
        port = int(s.get("port", 587))
        cls = smtplib.SMTP_SSL if port == 465 else smtplib.SMTP
        with cls(s["host"], port, timeout=15) as smtp:
            if port != 465:
                smtp.starttls()
            if s.get("user"):
                smtp.login(s["user"], os.environ.get(s.get("password_env", ""), s.get("password", "")))
            smtp.send_message(msg)

    def flush_outbox(self, max_items=50):
        """Reenvia o que ficou na fila (chamado a cada ciclo do motor)."""
        rows = self.store.rows("SELECT * FROM outbox ORDER BY id LIMIT ?", (max_items,))
        for r in rows:
            ok = self._deliver(r["channel"], r["target"], json.loads(r["payload"]), queue_on_fail=False)
            if ok or r["attempts"] >= 20:
                self.store.conn().execute("DELETE FROM outbox WHERE id=?", (r["id"],))
            else:
                self.store.conn().execute("UPDATE outbox SET attempts=attempts+1 WHERE id=?", (r["id"],))
        self.store.commit()


class Engine:
    def __init__(self, cfg, store, notifier=None, detectors=None):
        self.cfg = cfg
        self.store = store
        self.notifier = notifier or Notifier(cfg, store)
        self.detectors = detectors if detectors is not None else discover(cfg.get("plugins_dir"))

    # ---------- execução ----------
    def run_once(self, now=None, notify=True):
        now = int(now if now is not None else time.time())
        created = []
        for client in self.cfg["clients"]:
            ctx = Ctx(self.store, client, now, self.cfg, self.store.get_tuning(client))
            for name, det in self.detectors.items():
                if not ctx.param(name, "enabled", True):
                    continue
                try:
                    alerts = det.run(ctx)
                except Exception:
                    log.exception("Detector %s falhou (cliente %s)", name, client)
                    continue
                for a in alerts:
                    row = self._record(client, a, now)
                    if row is not None:
                        created.append(row)
                        if notify:
                            self.notifier.send(row)
        return created

    # ---------- aprendizado de padrões ----------
    @staticmethod
    def signature(a):
        """O que define 'alerta igual': detector + equipamento + pessoa + tipo do achado + características."""
        return "|".join([a.detector, a.device_id or "", a.user_id or "", re.sub(r"\d+", "", a.key), a.traits])

    def _record(self, client, a, now):
        """Todo alerta é útil. Padrão NOVO: gera alerta e é aprendido. Padrão JÁ CONHECIDO: só conta a repetição.
        Exceção: se a pessoa marcou o alerta anterior como 'resolvido' e o problema volta, é reincidência."""
        sig = self.signature(a)
        c = self.store.conn()
        kp = self.store.one("SELECT * FROM known_patterns WHERE client=? AND signature=?", (client, sig))
        title = a.title
        if kp is not None:
            last = self.store.one("SELECT id,status FROM alerts WHERE id=?", (kp["last_alert_id"],))
            reopen = (self.cfg["engine"].get("reopen_resolved", True)
                      and last is not None and last["status"] == "resolved")
            if not reopen:
                gap = int(self.cfg["engine"].get("episode_gap_minutes", 60)) * 60
                new_episode = now - (kp["last_seen"] or 0) >= gap
                c.execute("UPDATE known_patterns SET times=times+1,last_seen=?,episodes=episodes+? "
                          "WHERE client=? AND signature=?", (now, 1 if new_episode else 0, client, sig))
                if last is not None:
                    c.execute("UPDATE alerts SET count=count+1,last_seen_at=? WHERE id=?", (now, last["id"]))
                c.commit()
                return self._recurrence(client, a, sig, kp["episodes"] + 1, now) if new_episode else None
            title = "Reincidência: " + title
        cur = c.execute(
            "INSERT INTO alerts(client,detector,severity,title,detail,device_id,user_id,fingerprint,"
            "evidence,status,count,created_at,last_seen_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,'new',1,?,?,?)",
            (client, a.detector, a.severity, title, a.detail, a.device_id, a.user_id, sig,
             json.dumps(a.evidence, default=str), now, now, now))
        c.execute(
            "INSERT INTO known_patterns(client,signature,detector,first_seen,last_seen,times,last_alert_id) "
            "VALUES(?,?,?,?,?,1,?) ON CONFLICT(client,signature) DO UPDATE SET "
            "last_seen=excluded.last_seen, times=times+1, last_alert_id=excluded.last_alert_id",
            (client, sig, a.detector, now, now, cur.lastrowid))
        c.commit()
        return self.store.one("SELECT * FROM alerts WHERE id=?", (cur.lastrowid,))

    def _recurrence(self, client, a, sig, times, now):
        """Alerta igual continua sendo ignorado, mas quando o MESMO padrão volta em episódios separados
        (sumiu por 1 h e reapareceu) e atinge um marco (5, 10, 25…), o Zentry avisa UMA vez “aconteceu N vezes”,
        para um problema crônico não ficar invisível. Um problema contínuo não conta várias vezes."""
        marks = self.cfg["engine"].get("recurrence_milestones") or []
        if times not in marks:
            return None
        fp = f"rec:{sig}:{times}"
        if self.store.one("SELECT id FROM alerts WHERE client=? AND fingerprint=?", (client, fp)):
            return None
        sev = "atencao" if a.severity == "info" else a.severity
        c = self.store.conn()
        cur = c.execute(
            "INSERT INTO alerts(client,detector,severity,title,detail,device_id,user_id,fingerprint,evidence,status,"
            "count,created_at,last_seen_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,'new',?,?,?,?)",
            (client, a.detector, sev, f"Recorrente ({times}×): {a.title}",
             f"Este mesmo padrão já aconteceu {times} vezes. {a.detail}".strip(), a.device_id, a.user_id, fp,
             json.dumps({"recorrencias": times, **(a.evidence or {})}, default=str), times, now, now, now))
        c.commit()
        return self.store.one("SELECT * FROM alerts WHERE id=?", (cur.lastrowid,))

    def resolve(self, alert_id, now=None):
        return self.feedback(alert_id, "resolved", now)

    def feedback(self, alert_id, status, now=None):
        """Fecha (resolved) ou reabre (new) um alerta. Não existe 'falso positivo': todo alerta é útil."""
        if status not in STATUSES:
            raise ValueError(f"status inválido: {status} (use: {', '.join(STATUSES)})")
        now = int(now if now is not None else time.time())
        if self.store.one("SELECT id FROM alerts WHERE id=?", (alert_id,)) is None:
            return None
        self.store.conn().execute("UPDATE alerts SET status=?,updated_at=? WHERE id=?", (status, now, alert_id))
        self.store.commit()
        return self.store.one("SELECT * FROM alerts WHERE id=?", (alert_id,))
