"""Voz do próprio PC: o Zentry fala pelas caixas de som, sem depender do painel aberto.

Sem dependências: Windows (SAPI via PowerShell), macOS (`say`) e Linux (`espeak-ng`/`espeak`/`spd-say`).
As falas entram numa fila para não se atropelarem.
"""

import logging
import os
import platform
import queue
import shutil
import subprocess
import threading

log = logging.getLogger("zentry")

_q = queue.Queue(maxsize=20)
_worker = None
_lock = threading.Lock()

PS_SCRIPT = (
    "Add-Type -AssemblyName System.Speech;"
    "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
    "$v = $s.GetInstalledVoices() | Where-Object { $_.VoiceInfo.Culture.Name -eq 'pt-BR' } | Select-Object -First 1;"
    "if ($v) { $s.SelectVoice($v.VoiceInfo.Name) };"
    "$s.Rate = [int]$env:ZENTRY_RATE;"
    "$s.Speak($env:ZENTRY_TEXT)"
)


def _command(text, rate):
    """Monta o comando do sistema. O texto vai por variável de ambiente (Windows) para evitar injeção."""
    text = text.replace("\n", " ").strip().lstrip("-")
    env = dict(os.environ, ZENTRY_TEXT=text, ZENTRY_RATE=str(int(rate)))
    system = platform.system()
    if system == "Windows":
        return ["powershell", "-NoProfile", "-NonInteractive", "-Command", PS_SCRIPT], env
    if system == "Darwin" and shutil.which("say"):
        return ["say", text], env
    for exe in ("espeak-ng", "espeak"):
        if shutil.which(exe):
            return [exe, "-v", "pt-br", text], env
    if shutil.which("spd-say"):
        return ["spd-say", "-l", "pt-BR", text], env
    return None, env


def available():
    cmd, _ = _command("teste", 0)
    return cmd is not None


def _run(text, rate):
    cmd, env = _command(text, rate)
    if cmd is None:
        log.warning("Nenhum sintetizador de voz encontrado neste computador.")
        return False
    kw = {"creationflags": 0x08000000} if platform.system() == "Windows" else {}  # sem janela preta
    try:
        subprocess.run(cmd, env=env, timeout=90, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kw)
        return True
    except Exception as e:
        log.warning("Falha ao falar: %s", e)
        return False


def _loop():
    while True:
        text, rate = _q.get()
        _run(text, rate)


def speak(text, rate=0, wait=False):
    """Fala `text` pelas caixas de som. `wait=True` bloqueia até terminar (útil em teste)."""
    global _worker
    if wait:
        return _run(text, rate)
    with _lock:
        if _worker is None:
            _worker = threading.Thread(target=_loop, name="voz", daemon=True)
            _worker.start()
    try:
        _q.put_nowait((text, rate))
        return True
    except queue.Full:
        return False
