"""Leitura/edição segura da configuração pela interface (somente administradores).

- Só chaves da lista branca podem ser alteradas.
- Segredos saem mascarados ("********"); enviar a máscara de volta mantém o valor atual.
- Grava de forma atômica e atualiza o `cfg` em memória no mesmo objeto (sem reiniciar).
"""

import copy
import json
import os
import tempfile

from .timeutil import valid_tz

MASK = "********"
SECRETS = [("llm", "api_key"), ("server", "token"), ("notify", "smtp", "password"),
           ("notify", "telegram", "bot_token"), ("notify", "ntfy", "token")]
HIDDEN = [("anonymize", "salt")]
SEVS = ("info", "atencao", "alto", "critico")

# caminho -> (tipo, mínimo, máximo)
EDITABLE = {
    ("timezone",): ("tz",),
    ("server", "host"): ("str",),
    ("server", "port"): ("int", 1, 65535),
    ("server", "session_hours"): ("num", 0.5, 720),
    ("server", "allowed_device_ips"): ("strlist",),
    ("server", "debug_dump"): ("bool",),
    ("engine", "interval_seconds"): ("int", 1, 3600),
    ("engine", "probe_interval_seconds"): ("int", 1, 3600),
    ("engine", "poll_interval_seconds"): ("int", 1, 3600),
    ("engine", "reopen_resolved"): ("bool",),
    ("engine", "episode_gap_minutes"): ("int", 5, 10080),
    ("engine", "recurrence_milestones"): ("intlist",),
    ("server", "device_port"): ("int", 1, 65535),
    ("update", "enabled"): ("bool",),
    ("update", "repo"): ("repo",),
    ("update", "check_hours"): ("num", 1, 168),
    ("server", "tls", "enabled"): ("bool",),
    ("server", "tls", "cert_file"): ("str",),
    ("server", "tls", "key_file"): ("str",),
    ("notify", "telegram", "enabled"): ("bool",),
    ("notify", "telegram", "bot_token"): ("str",),
    ("notify", "telegram", "chat_id"): ("str",),
    ("notify", "ntfy", "enabled"): ("bool",),
    ("notify", "ntfy", "server"): ("str",),
    ("notify", "ntfy", "topic"): ("str",),
    ("notify", "ntfy", "token"): ("str",),
    ("notify", "console"): ("bool",),
    ("notify", "min_severity"): ("sev",),
    ("notify", "webhooks"): ("strlist",),
    ("notify", "voice", "enabled"): ("bool",),
    ("notify", "voice", "min_severity"): ("sev",),
    ("notify", "voice", "rate"): ("int", -10, 10),
    ("llm", "enabled"): ("bool",),
    ("llm", "model"): ("str",),
    ("llm", "api_key"): ("str",),
    ("llm", "send_real_names"): ("bool",),
    ("maintenance", "backup_enabled"): ("bool",),
    ("maintenance", "backup_keep"): ("int", 1, 365),
    ("maintenance", "backup_hour"): ("int", 0, 23),
    ("maintenance", "events_retention_days"): ("int", 30, 3650),
    ("maintenance", "audit_retention_days"): ("int", 30, 3650),
}


class SettingsError(ValueError):
    pass


def _get(d, path, default=None):
    for k in path:
        if not isinstance(d, dict) or k not in d:
            return default
        d = d[k]
    return d


def _set(d, path, value):
    for k in path[:-1]:
        d = d.setdefault(k, {})
    d[path[-1]] = value


def _coerce(path, spec, v):
    kind = spec[0]
    name = ".".join(path)
    try:
        if kind == "bool":
            if isinstance(v, bool):
                return v
            raise ValueError
        if kind in ("int", "num"):
            if isinstance(v, bool):
                raise ValueError
            n = int(v) if kind == "int" else float(v)
            if not spec[1] <= n <= spec[2]:
                raise SettingsError(f"{name}: valor fora do intervalo ({spec[1]} a {spec[2]}).")
            return n
        if kind == "str":
            if not isinstance(v, str):
                raise ValueError
            return v.strip()
        if kind == "strlist":
            if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
                raise ValueError
            return [x.strip() for x in v if x.strip()]
        if kind == "repo":
            import re as _re
            if not isinstance(v, str) or (v.strip() and not _re.match(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$", v.strip())):
                raise SettingsError(f"{name}: use o formato dono/repositório (ex.: minha-empresa/zentry-ia).")
            return v.strip()
        if kind == "intlist":
            if not isinstance(v, list) or not all(isinstance(x, int) and not isinstance(x, bool) and 2 <= x <= 100000 for x in v):
                raise ValueError
            return sorted(set(v))
        if kind == "sev":
            if v not in SEVS:
                raise SettingsError(f"{name}: use uma de {', '.join(SEVS)}.")
            return v
        if kind == "tz":
            if not isinstance(v, str) or not valid_tz(v):
                raise SettingsError(f"{name}: fuso horário desconhecido.")
            return v
    except (TypeError, ValueError) as e:
        if isinstance(e, SettingsError):
            raise
        raise SettingsError(f"{name}: valor inválido.")
    raise SettingsError(f"{name}: tipo não suportado.")


def public_view(cfg):
    """Cópia da configuração segura para exibir: sem segredos e sem chaves internas."""
    out = {k: copy.deepcopy(v) for k, v in cfg.items() if not k.startswith("_")}
    for p in SECRETS:
        if _get(out, p):
            _set(out, p, MASK)
    for p in HIDDEN:
        if _get(out, p) is not None:
            _set(out, p, MASK)
    for c in (out.get("clients") or {}).values():  # senhas dos equipamentos
        for d in (c.get("devices") or {}).values():
            if d.get("password"):
                d["password"] = MASK
    return out


def validate_changes(changes):
    """changes: dict aninhado parcial. Retorna lista [(path, valor)] já validada."""
    flat = []

    def walk(d, prefix):
        for k, v in d.items():
            p = prefix + (k,)
            if p in EDITABLE:
                flat.append((p, v))
            elif isinstance(v, dict) and any(e[:len(p)] == p for e in EDITABLE):
                walk(v, p)
            else:
                raise SettingsError(f"Configuração não editável: {'.'.join(p)}")
    if not isinstance(changes, dict):
        raise SettingsError("Formato inválido.")
    walk(changes, ())
    return [(p, _coerce(p, EDITABLE[p], v)) for p, v in flat]


def apply_changes(cfg, config_path, changes):
    """Valida, aplica em memória e grava. Retorna a lista de caminhos alterados."""
    items = validate_changes(changes)
    changed = []
    for p, v in items:
        if p in SECRETS and v == MASK:
            continue
        if _get(cfg, p) != v:
            _set(cfg, p, v)
            changed.append(".".join(p))
    if changed:
        save(cfg, config_path)
    return changed


def apply_clients(cfg, config_path, clients):
    """Substitui a seção `clients` (clientes/equipamentos/limiares de detectores) após validar."""
    if not isinstance(clients, dict) or not clients:
        raise SettingsError("Informe pelo menos um cliente.")
    for cid, c in clients.items():
        if not isinstance(c, dict) or not str(cid).strip():
            raise SettingsError("Cliente inválido.")
        for did, d in (c.get("devices") or {}).items():
            if not isinstance(d, dict):
                raise SettingsError(f"Equipamento {did}: formato inválido.")
            if d.get("direction") not in (None, "", "in", "out"):
                raise SettingsError(f"Equipamento {did}: direction deve ser 'in' ou 'out'.")
            if d.get("brand") not in (None, ""):
                from .connectors import REGISTRY
                if d["brand"] not in REGISTRY:
                    raise SettingsError(f"Equipamento {did}: marca desconhecida ({d['brand']}).")
            if d.get("type") not in (None, "", "face", "turnstile", "reader"):
                raise SettingsError(f"Equipamento {did}: type deve ser face, turnstile ou reader.")
        for dn, params in (c.get("detectors") or {}).items():
            if not isinstance(params, dict):
                raise SettingsError(f"Detector {dn}: formato inválido.")
    clients = copy.deepcopy(clients)
    for cid, c in clients.items():  # senha mascarada = manter a que já estava salva
        for did, d in (c.get("devices") or {}).items():
            if d.get("password") == MASK:
                old = _get(cfg, ("clients", cid, "devices", did, "password"))
                if old:
                    d["password"] = old
                else:
                    d.pop("password")
    cfg["clients"] = clients
    save(cfg, config_path)
    return list(clients)


def save(cfg, path):
    data = {k: v for k, v in cfg.items() if not k.startswith("_")}
    d = os.path.dirname(os.path.abspath(path))
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".config-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
