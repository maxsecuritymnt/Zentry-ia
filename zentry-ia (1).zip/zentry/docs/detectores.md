# Criando um detector

Coloque um arquivo `.py` na pasta `plugins/` dentro da pasta de dados do Zentry (aparece em *Diagnóstico → Pasta de dados*).

```python
from zentry.detectors.base import Alert, Detector

class PortaDoFundos(Detector):
    name = "porta_do_fundos"            # identificador único
    title = "Acesso na porta dos fundos"
    description = "Alerta qualquer acesso liberado na porta dos fundos."
    params = [("janela_min", 15, "Janela de análise", "min")]   # aparece em Configurações → Detectores

    def run(self, ctx):
        win = ctx.param(self.name, "janela_min", 15) * 60
        for e in ctx.events(ctx.now - win, ctx.now, kinds=["grant"], device_id="7"):
            yield Alert(self.name, "atencao", "Acesso na porta dos fundos",
                        device_id=e["device_id"], user_id=e["user_id"], key=str(e["user_id"]))
```

`ctx` oferece `events()`, `devices()`, `param()`, `device_name()`. O Zentry cuida da assinatura do alerta, do aprendizado (alerta igual é ignorado) e das notificações.
Veja `plugins/exemplo_area_restrita.py` e `zentry/detectors/` para mais exemplos.
