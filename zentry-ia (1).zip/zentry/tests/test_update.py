import hashlib, io, os, sys, tempfile, time, unittest
from unittest import mock
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from zentry import updater, __version__
from zentry.api import Api, Request
from zentry.app import App
from zentry.config import init_config, load_config
from zentry.updater import Updater, is_newer, parse_version

EXE = b"MZ-instalador-falso" * 100
SHA = hashlib.sha256(EXE).hexdigest()


def release(version="9.9.9", digest=True):
    a = {"name": f"ZentryIA-Setup-{version}.exe", "size": len(EXE),
         "browser_download_url": f"https://github.com/acme/zentry-ia/releases/download/v{version}/ZentryIA-Setup-{version}.exe"}
    if digest:
        a["digest"] = "sha256:" + SHA
    return {"tag_name": "v" + version, "name": "Versão " + version, "body": "- novidade 1", "html_url": "https://github.com/acme/zentry-ia/releases/tag/v" + version,
            "assets": [a]}


class Resp(io.BytesIO):
    def __enter__(self): return self
    def __exit__(self, *a): return False


def make(repo="acme/zentry-ia", **kw):
    d = tempfile.mkdtemp(); p = os.path.join(d, "config.json"); init_config(p)
    cfg = load_config(p); cfg["update"]["repo"] = repo
    app = App(cfg, config_path=p)
    app.updater = Updater(app, **kw)
    return app, d


def wait(up, phases=("installing", "error"), t=5):
    end = time.time() + t
    while time.time() < end and up.state["phase"] not in phases:
        time.sleep(0.02)
    return up.state["phase"]


class UpdateTests(unittest.TestCase):
    def test_versions(self):
        self.assertTrue(is_newer("0.4.1", "0.4.0")); self.assertTrue(is_newer("1.0", "0.9.9"))
        self.assertFalse(is_newer("0.4.0", "0.4.0")); self.assertFalse(is_newer("0.3.9", "0.4.0"))
        self.assertEqual(parse_version("v1.2.3-beta"), (1, 2, 3))

    def test_check_available_and_throttled(self):
        calls = []
        app, _ = make(fetch_json=lambda url: calls.append(url) or release())
        with mock.patch("zentry.updater.sys.platform", "win32"), mock.patch("zentry.updater.frozen", return_value=True):
            st = app.updater.check(force=True)
            self.assertTrue(st["available"] and st["can_install"])
            self.assertEqual(st["latest"]["version"], "9.9.9")
            app.updater.check()  # dentro do intervalo: não consulta de novo
        self.assertEqual(len(calls), 1)
        self.assertIn("/repos/acme/zentry-ia/releases/latest", calls[0])

    def test_no_repo_offline_and_up_to_date(self):
        app, _ = make(repo="")
        self.assertIn("repositório", app.updater.check(force=True)["error"])
        app, _ = make(fetch_json=lambda u: (_ for _ in ()).throw(OSError("sem rede")))
        st = app.updater.check(force=True)
        self.assertFalse(st["available"]); self.assertIn("Não foi possível", st["error"])
        app, _ = make(fetch_json=lambda u: release(__version__))
        self.assertFalse(app.updater.check(force=True)["available"])

    def test_cannot_install_without_checksum_or_off_windows(self):
        app, _ = make(fetch_json=lambda u: release(digest=False), fetch_text=lambda u: "")
        with mock.patch("zentry.updater.sys.platform", "win32"), mock.patch("zentry.updater.frozen", return_value=True):
            st = app.updater.check(force=True)
            self.assertTrue(st["available"]); self.assertFalse(st["can_install"])
            with self.assertRaises(ValueError):
                app.updater.start_install()
        app, _ = make(fetch_json=lambda u: release())
        app.updater.check(force=True)  # Linux
        self.assertFalse(app.updater.status()["can_install"])

    def test_sidecar_checksum(self):
        rel = release(digest=False)
        rel["assets"].append({"name": "ZentryIA-Setup-9.9.9.exe.sha256", "browser_download_url": "https://github.com/x/y/z.sha256"})
        app, _ = make(fetch_json=lambda u: rel, fetch_text=lambda u: f"{SHA}  ZentryIA-Setup-9.9.9.exe\n")
        with mock.patch("zentry.updater.sys.platform", "win32"), mock.patch("zentry.updater.frozen", return_value=True):
            self.assertTrue(app.updater.check(force=True)["can_install"])

    def test_install_verifies_hash_then_launches(self):
        launched = []
        app, d = make(fetch_json=lambda u: release(), opener=lambda url: Resp(EXE), launcher=launched.append)
        with mock.patch("zentry.updater.sys.platform", "win32"), mock.patch("zentry.updater.frozen", return_value=True):
            app.updater.check(force=True)
            app.updater.start_install()
            self.assertEqual(wait(app.updater), "installing")
        self.assertEqual(len(launched), 1)
        self.assertEqual(open(launched[0], "rb").read(), EXE)
        self.assertTrue(any(f.endswith(".db") for f in os.listdir(os.path.join(d, "backups"))))  # backup antes de instalar

    def test_install_rejects_tampered_file(self):
        launched = []
        app, d = make(fetch_json=lambda u: release(), opener=lambda url: Resp(EXE + b"x"), launcher=launched.append)
        with mock.patch("zentry.updater.sys.platform", "win32"), mock.patch("zentry.updater.frozen", return_value=True):
            app.updater.check(force=True)
            app.updater.start_install()
            self.assertEqual(wait(app.updater), "error")
        self.assertEqual(launched, [])
        self.assertIn("não confere", app.updater.state["error"])
        self.assertEqual(os.listdir(os.path.join(d, "updates")), [])

    def test_download_host_guard(self):
        app, _ = make()
        for bad in ("http://github.com/a", "https://evil.example.com/a.exe", "https://github.com.evil.com/a", "file:///etc/passwd"):
            with self.assertRaises(ValueError):
                app.updater._guard(bad)
        app.updater._guard("https://github.com/acme/zentry-ia/releases/download/v1/x.exe")
        app.updater._guard("https://objects.githubusercontent.com/abc")

    def test_api_permissions(self):
        app, _ = make(fetch_json=lambda u: release())
        api = Api(app)
        api.auth.create_account("v", "senha-forte-1", "viewer"); api.auth.create_account("o", "senha-forte-1", "operator"); api.auth.create_account("a", "senha-forte-1", "admin")
        def call(user, method, path):
            tok, _a = api.auth.login(user, "senha-forte-1", "1.1.1.1")
            return api.handle(Request(method, path, {}, {}, {"Cookie": "zentry_session=" + tok, "X-Requested-With": "zentry"}, "1.1.1.1"))
        self.assertEqual(call("v", "GET", "/api/update").status, 200)
        self.assertEqual(call("o", "POST", "/api/update/check").status, 403)
        self.assertEqual(call("a", "POST", "/api/update/check").body["latest"]["version"], "9.9.9")
        self.assertEqual(call("o", "POST", "/api/update/install").status, 403)
        self.assertEqual(call("a", "POST", "/api/update/install").status, 400)  # Linux: sem instalação automática

    def test_repo_setting_validation(self):
        from zentry import settings
        app, _ = make()
        settings.apply_changes(app.cfg, app.config_path, {"update": {"repo": "minha-empresa/zentry-ia"}})
        for bad in ("sem-barra", "a/b/c", "x; rm -rf /"):
            with self.assertRaises(settings.SettingsError):
                settings.apply_changes(app.cfg, app.config_path, {"update": {"repo": bad}})


if __name__ == "__main__":
    unittest.main()


class ZipApplyTests(unittest.TestCase):
    def test_apply_zip_updates_code_keeps_data(self):
        import tempfile, zipfile
        from zentry.updater import apply_zip
        with tempfile.TemporaryDirectory() as d:
            prog = os.path.join(d, "prog"); os.makedirs(os.path.join(prog, "zentry"))
            open(os.path.join(prog, "zentry", "__init__.py"), "w").write("old")
            open(os.path.join(prog, "config.json"), "w").write("{mine}")
            z = os.path.join(d, "n.zip")
            with zipfile.ZipFile(z, "w") as f:
                f.writestr("zentry/zentry/__init__.py", "new"); f.writestr("zentry/config.json", "{overwritten}")
            apply_zip(z, prog)
            self.assertEqual(open(os.path.join(prog, "zentry", "__init__.py")).read(), "new")
            self.assertEqual(open(os.path.join(prog, "config.json")).read(), "{mine}")
            with zipfile.ZipFile(z, "w") as f:
                f.writestr("zentry/../../evil.txt", "x"); f.writestr("zentry/zentry/__init__.py", "z")
            apply_zip(z, prog)
            self.assertFalse(os.path.exists(os.path.join(d, "evil.txt")))
            with zipfile.ZipFile(z, "w") as f:
                f.writestr("foo/bar.txt", "x")
            with self.assertRaises(ValueError):
                apply_zip(z, prog)
