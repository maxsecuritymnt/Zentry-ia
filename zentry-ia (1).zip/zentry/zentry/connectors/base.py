import logging
import socket

from ..config import device_cfg  # noqa: F401  (usado pelas subclasses)

log = logging.getLogger("zentry")


def device_brand(cfg, client, d):
    return (d.get("brand") or (cfg.get("clients", {}).get(client, {}) or {}).get("connector") or "controlid")


class Connector:
    """Como o Zentry conversa com uma marca. Duas formas de receber eventos:

    * **push**: o equipamento envia para o Zentry (mais rápido; configure no equipamento). Veja `help`.
    * **polling**: o Zentry consulta o equipamento (`poll_device`), usado quando `poll: true` e `ip` estão no cadastro.

    Tudo aqui foi escrito a partir de documentação pública e NÃO foi validado em equipamento real
    (`validated = False`); use Configurações → Diagnóstico → “Últimos envios” para conferir o que chega.
    """
    name = "base"
    label = "Base"
    default_port = 80
    push_path = None       # caminho que o equipamento deve chamar (se houver)
    validated = False
    help = ""
    transport = None       # para testes: função (d, method, path, body) -> texto

    # ----- cadastro
    def devices(self, cfg):
        for cid, c in cfg.get("clients", {}).items():
            for did, d in (c.get("devices") or {}).items():
                if device_brand(cfg, cid, d) == self.name:
                    yield cid, did, d

    def info(self):
        return {"id": self.name, "label": self.label, "port": self.default_port, "push_path": self.push_path,
                "validated": self.validated, "help": self.help}

    def request(self, d, method, path, body=None, headers=None):
        if self.transport:
            return self.transport(d, method, path, body)
        from .common import http_request
        return http_request(d, method, path, body, headers)

    # ----- polling
    def poll_all(self, cfg, store):
        total = 0
        for cid, did, d in self.devices(cfg):
            if d.get("poll") and d.get("ip"):
                try:
                    total += self.poll_device(cfg, store, cid, did, d)
                except Exception as e:
                    log.warning("Falha ao coletar de %s/%s (%s): %s", cid, did, self.name, e)
        return total

    def poll_device(self, cfg, store, client, device_id, d):
        return 0

    # ----- push
    def handle_push(self, cfg, store, path, query, body, ip, now=None):
        """Retorna (status, texto, nº de eventos). Implementado pelas marcas que recebem push."""
        return 404, "não suportado", 0

    # ----- diagnóstico
    def test_device(self, cfg, client, device_id):
        d = (cfg.get("clients", {}).get(client, {}) or {}).get("devices", {}).get(str(device_id), {})
        ip = d.get("ip")
        if not ip:
            return {"ok": False, "detail": "Equipamento sem IP (só recebe push)."}
        try:
            with socket.create_connection((ip, int(d.get("port", self.default_port))), timeout=3):
                pass
        except OSError:
            return {"ok": False, "detail": f"{ip}:{d.get('port', self.default_port)} não respondeu (rede/IP/porta)."}
        if d.get("poll") and (d.get("user") or d.get("password")):
            try:
                self.check(d)
            except Exception as e:
                return {"ok": False, "detail": f"Porta aberta, mas a consulta falhou: {e}"}
            return {"ok": True, "detail": f"{ip} respondeu e as credenciais funcionaram."}
        return {"ok": True, "detail": f"{ip} respondeu na porta {d.get('port', self.default_port)}."}

    def check(self, d):
        """Chamada leve para confirmar login. Pode ser sobrescrita."""
        return True
