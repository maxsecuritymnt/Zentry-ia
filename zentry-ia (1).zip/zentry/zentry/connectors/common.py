"""Utilidades compartilhadas pelos conectores: HTTP com autenticação, datas e tipos de evento."""

import json
import os
import re
import urllib.request
from datetime import datetime, timezone

KINDS = ("grant", "deny", "not_identified", "turn", "door_open", "door_close", "alarm", "other")
KIND_ALIASES = {
    "grant": "grant", "granted": "grant", "accessgranted": "grant", "liberado": "grant", "autorizado": "grant",
    "permitido": "grant", "ok": "grant", "success": "grant", "1": "grant",
    "deny": "deny", "denied": "deny", "accessdenied": "deny", "negado": "deny", "bloqueado": "deny",
    "recusado": "deny", "fail": "deny", "failed": "deny", "0": "deny",
    "not_identified": "not_identified", "unknown": "not_identified", "naoidentificado": "not_identified",
    "turn": "turn", "giro": "turn", "door_open": "door_open", "open": "door_open", "aberta": "door_open",
    "door_close": "door_close", "close": "door_close", "closed": "door_close", "fechada": "door_close",
    "alarm": "alarm", "alarme": "alarm",
}


def norm_kind(value, default="other"):
    key = re.sub(r"[\s\-]+", "", str(value or "")).lower().replace("não", "nao")
    return KIND_ALIASES.get(key, default)


def parse_ts(value, tz_offset_default=None):
    """Aceita epoch (s ou ms), ISO 8601 (com ou sem fuso) e 'AAAA-MM-DD HH:MM:SS'. Retorna epoch em segundos ou None."""
    if value in (None, ""):
        return None
    s = str(value).strip()
    if re.fullmatch(r"\d{9,13}(\.\d+)?", s):
        n = float(s)
        return int(n / 1000) if n > 1e11 else int(n)
    s = s.replace("Z", "+00:00").replace(" ", "T", 1)
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=tz_offset_default or timezone.utc)
    return int(dt.timestamp())


def extract_json(body):
    """Pega o primeiro objeto JSON de um corpo (aceita multipart/form-data enviado por equipamentos)."""
    if isinstance(body, (bytes, bytearray)):
        body = bytes(body).decode("utf-8", errors="replace")
    try:
        return json.loads(body)
    except ValueError:
        pass
    i, j = body.find("{"), body.rfind("}")
    if i >= 0 and j > i:
        try:
            return json.loads(body[i:j + 1])
        except ValueError:
            return None
    return None


def device_password(d):
    return os.environ.get(d.get("password_env", ""), "") or d.get("password", "")


def http_request(d, method, path, body=None, headers=None, timeout=15, https=None):
    """Chamada HTTP ao equipamento com autenticação Digest (padrão Hikvision/Dahua/Intelbras/Axis) ou Basic."""
    scheme = "https" if (https if https is not None else d.get("https")) else "http"
    url = f"{scheme}://{d['ip']}:{d.get('port', 443 if scheme == 'https' else 80)}{path}"
    mgr = urllib.request.HTTPPasswordMgrWithDefaultRealm()
    mgr.add_password(None, url, d.get("user", "admin"), device_password(d))
    handlers = [urllib.request.HTTPDigestAuthHandler(mgr), urllib.request.HTTPBasicAuthHandler(mgr)]
    if scheme == "https":  # equipamentos usam certificado autoassinado
        import ssl
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        handlers.append(urllib.request.HTTPSHandler(context=ctx))
    opener = urllib.request.build_opener(*handlers)
    data = body.encode() if isinstance(body, str) else body
    req = urllib.request.Request(url, data=data, method=method, headers=headers or {})
    with opener.open(req, timeout=timeout) as r:
        return r.read().decode("utf-8", errors="replace")
