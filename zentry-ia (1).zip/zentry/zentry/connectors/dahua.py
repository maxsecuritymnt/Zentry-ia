"""Dahua e Intelbras (controles de acesso com a API HTTP “CGI” da Dahua).

Consulta: GET /cgi-bin/recordFinder.cgi?action=find&name=AccessControlCardRec (Digest). A resposta é texto chave=valor.
Muitos controles/faciais Intelbras (linha SS/ MF/ Face) usam essa mesma API; confirme no manual do seu modelo.
Também aceita push genérico: /api/push/generic.
"""

import json
import re

from .base import Connector
from .common import parse_ts

LINE = re.compile(r"^(?:records|table\.\w+)\[(\d+)\]\.([\w.]+)=(.*)$")


def parse_records(text):
    recs = {}
    for line in (text or "").splitlines():
        m = LINE.match(line.strip())
        if m:
            recs.setdefault(int(m.group(1)), {})[m.group(2)] = m.group(3).strip()
    return [recs[i] for i in sorted(recs)]


def normalize(rec):
    ts = parse_ts(rec.get("CreateTime") or rec.get("Time"))
    if ts is None:
        return None
    status = str(rec.get("Status", "1"))
    kind = "grant" if status in ("1", "true", "True") else "deny"
    uid = rec.get("UserID") or rec.get("CardNo") or None
    return {"ts": ts, "kind": kind, "user_id": uid if uid not in ("", "0") else None, "user_name": rec.get("CardName") or None,
            "portal_id": rec.get("Door"), "code": int(rec["Method"]) if str(rec.get("Method", "")).isdigit() else None,
            "src_id": rec.get("RecNo")}


class DahuaConnector(Connector):
    name = "dahua"
    label = "Dahua (controle de acesso)"
    help = ("CONSULTA: marque “Consultar”, informe usuário e senha do equipamento (Digest). O Zentry lê os registros de acesso "
            "pelo CGI recordFinder e guarda o último RecNo. Se o seu modelo exigir filtros, coloque-os em “poll_params” "
            "(ex.: condition.StartTime=…). Também é possível enviar por push em /api/push/generic.")
    record_name = "AccessControlCardRec"

    def check(self, d):
        return self.request(d, "GET", "/cgi-bin/magicBox.cgi?action=getSystemInfo")

    def poll_device(self, cfg, store, client, device_id, d):
        key = f"cursor:{client}:{device_id}"
        last = int(store.meta_get(key, 0) or 0)
        extra = d.get("poll_params", "")
        text = self.request(d, "GET", f"/cgi-bin/recordFinder.cgi?action=find&name={self.record_name}&count=500"
                                      + (("&" + extra.lstrip("&")) if extra else ""))
        n, newest = 0, last
        for rec in parse_records(text):
            e = normalize(rec)
            recno = int(e["src_id"]) if e and str(e["src_id"] or "").isdigit() else None
            if not e or (recno is not None and recno <= last):
                continue
            n += int(store.add_event(client, device_id, e["ts"], e["kind"], e["user_id"], e["user_name"], e["portal_id"],
                                     e["code"], e["src_id"] or f"{e['ts']}-{e['user_id']}",
                                     json.dumps(rec, ensure_ascii=False), live=False, commit=False))
            if recno is not None:
                newest = max(newest, recno)
        store.commit()
        store.meta_set(key, newest)
        return n


class IntelbrasConnector(DahuaConnector):
    name = "intelbras"
    label = "Intelbras (controle de acesso / facial)"
