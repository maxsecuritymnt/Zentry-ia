# Instalação

## Windows (instalador)
Baixe `ZentryIA-Setup-x.y.z.exe` na página de *Releases*, execute e siga o assistente. Ele instala o programa, cria o banco em `C:\ProgramData\ZentryIA`, libera a porta no firewall (opcional) e inicia com o Windows (opcional). Ao terminar, o painel abre no navegador e o assistente de primeira configuração cria sua conta de administrador.
Atualizar: rode o instalador novo por cima — os dados são preservados. Desinstalar: os dados continuam na pasta de dados até você apagá-la.

## Qualquer sistema (código-fonte)
```
python -m zentry setup      # cria a pasta de dados, a configuração e o banco
python -m zentry run --open # abre o painel
```
Pasta de dados: `%ProgramData%\ZentryIA` (Windows), `~/.local/share/zentry` (Linux), `~/Library/Application Support/ZentryIA` (macOS). Mude com a variável `ZENTRY_HOME`.

## Equipamentos
No iDFace/catraca, configure o *Monitor* para o endereço do PC (porta 8000, padrão) e mantenha o modo autônomo. Cadastre os equipamentos em *Configurações → Clientes e equipamentos*.

## Gerar o instalador (mantenedores)
Veja `installer/build_windows.bat` e `.github/workflows/release.yml`.
