"""Entrada de dados: payloads do Monitor da Control iD, API de logs e CSV do iDSecure.

ATENÇÃO: os formatos abaixo seguem a documentação pública da Control iD, mas devem ser
validados em um equipamento real (use server.debug_dump=true para gravar o corpo bruto).
"""

import csv
import hashlib
import json
import re
import time
import unicodedata
from datetime import datetime
from .timeutil import get_tz

from .config import resolve_device


def _int(v, default=None):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return default


def anon_id(cfg, value):
    salt = cfg.get("anonymize", {}).get("salt", "")
    return "U-" + hashlib.sha256(f"{salt}{value}".encode()).hexdigest()[:6]


def _device_ref(cfg, payload, ip):
    did = payload.get("device_id") if isinstance(payload, dict) else None
    return resolve_device(cfg, did, ip)


def _device_ts(cfg, value, now):
    """Hora do evento vinda do equipamento Control iD (hora local gravada como UTC, salvo clock_utc=true)."""
    if value in (None, ""):
        return int(now)
    t = _int(value, int(now))
    if cfg.get("controlid_clock_utc"):
        return t
    from .timeutil import wall_epoch_to_utc
    return wall_epoch_to_utc(cfg, t)


def access_method(raw, device_type=None):
    """Como a pessoa se identificou: Cartão, Senha, QR Code, Biometria ou Facial. Melhor esforço a partir do que o equipamento
    informa; se ele não informa, usa o tipo do equipamento (facial). Retorna None se não houver como saber."""
    def has(*keys):
        return any(raw.get(k) not in (None, "", 0, "0", False) for k in keys)
    if has("card_value", "card", "card_number", "rfid"):
        return "Cartão"
    if has("qrcode", "qr_code", "qrcode_value"):
        return "QR Code"
    if has("pin", "password", "pin_code"):
        return "Senha"
    if has("fingerprint", "finger", "biometry"):
        return "Biometria"
    if has("face", "face_id", "face_mask", "mask"):
        return "Facial"
    return "Facial" if device_type == "face" else None


def ingest_access_log_values(store, cfg, client, device_id, v, now=None, live=True, commit=True):
    """Converte um registro de access_logs da Control iD em evento."""
    code = _int(v.get("event"))
    kind = cfg["event_map"].get(str(code), "other")
    ts = _device_ts(cfg, v.get("time"), now or time.time())
    uid = v.get("user_id")
    return store.add_event(
        client, device_id, ts, kind, user_id=uid, portal_id=v.get("portal_id"), code=code,
        src_id=v.get("id"), raw=json.dumps(v, ensure_ascii=False), live=live, now=now, commit=commit)


def handle_device_push(store, cfg, path, payload, ip, now=None):
    """Processa /api/notifications/<tipo> enviado pelo Monitor do equipamento. Retorna nº de eventos."""
    now = int(now if now is not None else time.time())
    client, device_id = _device_ref(cfg, payload, ip)
    store.heartbeat(client, device_id, now)
    kind_path = path.rstrip("/").rsplit("/", 1)[-1]
    n = 0
    if not isinstance(payload, dict):
        return 0
    if kind_path == "dao":
        for ch in payload.get("object_changes", []) or []:
            obj, typ, vals = ch.get("object"), ch.get("type"), ch.get("values") or {}
            if obj == "access_logs" and typ == "inserted":
                v = dict(vals)
                v.setdefault("device_id", device_id)
                n += int(ingest_access_log_values(store, cfg, client, device_id, v, now))
            elif obj == "users" and typ in ("inserted", "updated") and vals.get("id"):
                store.upsert_user(client, vals["id"], vals.get("name"))
            elif obj == "alarm_logs" and typ == "inserted":
                n += int(store.add_event(client, device_id, _device_ts(cfg, vals.get("time"), now), "alarm",
                                         code=_int(vals.get("event")), src_id=f"alarm{vals.get('id')}",
                                         raw=json.dumps(vals), now=now))
    elif kind_path == "door":
        opened = payload.get("open")
        if isinstance(opened, str):
            opened = opened.lower() in ("1", "true", "yes")
        n += int(store.add_event(client, device_id, now, "door_open" if opened else "door_close",
                                 portal_id=payload.get("id"), raw=json.dumps(payload), now=now))
    elif kind_path == "catra_event":
        code = _int(payload.get("event"))
        kind = cfg.get("turnstile_event_map", {}).get(str(code), "turn")
        n += int(store.add_event(client, device_id, _device_ts(cfg, payload.get("time"), now), kind, code=code,
                                 raw=json.dumps(payload), now=now))
    else:  # secbox e outros: guarda como "other" para análise futura
        n += int(store.add_event(client, device_id, now, "other", raw=json.dumps(payload), now=now))
    return n


def handle_generic_ingest(store, cfg, body, now=None):
    """Formato normalizado: {"client":"x","events":[{"device_id","ts","kind","user_id","user_name"}]}"""
    now = int(now if now is not None else time.time())
    client = body.get("client") or "default"
    n = 0
    for e in body.get("events", []):
        n += int(store.add_event(
            client, e["device_id"], e.get("ts", now), e.get("kind", "other"), user_id=e.get("user_id"),
            user_name=e.get("user_name"), portal_id=e.get("portal_id"), src_id=e.get("src_id"),
            live=bool(e.get("live", True)), now=now, commit=False))
    store.commit()
    return n


# ---------------------------------------------------------------- CSV do iDSecure
def _norm(s):
    s = unicodedata.normalize("NFKD", str(s or "")).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


COLUMN_HINTS = {
    "ts": ["data hora", "datahora", "data e hora", "horario", "timestamp", "data", "hora", "time"],
    "user": ["usuario", "pessoa", "nome", "user"],
    "user_id": ["id usuario", "matricula", "id pessoa", "user id", "id"],
    "device": ["equipamento", "dispositivo", "terminal", "leitora", "ponto de acesso", "device", "local"],
    "result": ["resultado", "status", "evento", "autorizacao", "tipo", "result"],
}

DATE_FORMATS = ["%d/%m/%Y %H:%M:%S", "%d/%m/%Y %H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S",
                "%d-%m-%Y %H:%M:%S", "%d/%m/%y %H:%M:%S"]


def detect_columns(header):
    norm = [_norm(h) for h in header]
    found = {}
    for field, hints in COLUMN_HINTS.items():
        for hint in hints:
            for i, h in enumerate(norm):
                if h == hint and i not in found.values():
                    found[field] = i
                    break
            if field in found:
                break
        if field not in found:
            for hint in hints:
                for i, h in enumerate(norm):
                    if hint in h and i not in found.values():
                        found[field] = i
                        break
                if field in found:
                    break
    return found


def classify_result(text):
    t = _norm(text)
    if any(w in t for w in ("negad", "nao autoriz", "nao liber", "bloquead", "recusad", "invalid", "expirad")):
        return "deny"
    if any(w in t for w in ("nao identific", "desconhecid")):
        return "not_identified"
    if any(w in t for w in ("autoriz", "liberad", "permitid", "sucesso", "acesso")):
        return "grant"
    return "other"


def parse_dt(text, tz):
    text = str(text).strip()
    for f in DATE_FORMATS:
        try:
            return int(datetime.strptime(text, f).replace(tzinfo=tz).timestamp())
        except ValueError:
            continue
    raise ValueError(f"data não reconhecida: {text!r}")


def import_csv(store, cfg, client, path, mapping=None, anonymize=False, dry_run=False, encoding=None):
    """Importa um relatório exportado do iDSecure (CSV). `mapping` força colunas: {"ts":"Data",...}."""
    tz = get_tz(cfg.get("timezone", "America/Sao_Paulo"))
    with open(path, "rb") as fh:
        raw = fh.read()
    text = None
    for enc in ([encoding] if encoding else ["utf-8-sig", "latin-1"]):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    sample = text[:4096]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=";,\t")
    except csv.Error:
        dialect = csv.excel
        dialect.delimiter = ";"
    rows = list(csv.reader(text.splitlines(), dialect))
    if not rows:
        return {"imported": 0, "skipped": 0, "columns": {}}
    header, body = rows[0], rows[1:]
    cols = detect_columns(header)
    for field, colname in (mapping or {}).items():
        if colname in header:
            cols[field] = header.index(colname)
    summary = {"columns": {k: header[v] for k, v in cols.items()}, "imported": 0, "skipped": 0,
               "errors": [], "preview": []}
    if "ts" not in cols:
        summary["errors"].append("Não achei a coluna de data/hora. Use --map ts=NomeDaColuna")
        return summary
    for line in body:
        try:
            ts = parse_dt(line[cols["ts"]], tz)
            kind = classify_result(line[cols["result"]]) if "result" in cols else "grant"
            dev_name = line[cols["device"]].strip() if "device" in cols else "importado"
            uname = line[cols["user"]].strip() if "user" in cols else None
            uid = line[cols["user_id"]].strip() if "user_id" in cols else (uname or None)
            if anonymize and uid:
                uid = anon_id(cfg, uid)
                uname = uid
            dev_id = re.sub(r"\W+", "_", _norm(dev_name)) or "importado"
            summary["preview"].append((ts, dev_id, kind, uid))
            if not dry_run:
                store.set_device_name(client, dev_id, dev_name, commit=False)
                added = store.add_event(client, dev_id, ts, kind, user_id=uid, user_name=uname,
                                        live=False, commit=False,
                                        src_id=hashlib.md5(",".join(line).encode()).hexdigest())
                summary["imported" if added else "skipped"] += 1
        except (ValueError, IndexError) as e:
            summary["skipped"] += 1
            if len(summary["errors"]) < 5:
                summary["errors"].append(str(e))
    summary["preview"] = summary["preview"][:3]
    if not dry_run:
        store.commit()
    return summary
