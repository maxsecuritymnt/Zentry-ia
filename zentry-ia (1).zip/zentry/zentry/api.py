"""Rotas da API (independentes do servidor HTTP, para poderem ser testadas sem rede).

Autenticação: cookie de sessão (pessoas) ou `Authorization: Bearer <chave>` (integrações = nível operador).
Cookie + método que altera dados exige o cabeçalho `X-Requested-With: zentry` (proteção CSRF).
"""

import collections
import secrets
import threading
import json
import logging
import re
import time
from datetime import datetime

from . import __version__, assistant, maintenance, report, settings, voice
from .auth import Auth, AuthError, ROLES, has_role
from .config import client_name, detector_cfg
from .connectors import REGISTRY, all_connectors, device_brand, get as get_connector
from .ingest import access_method, handle_device_push, handle_generic_ingest
from .timeutil import get_tz

log = logging.getLogger("zentry")
START = time.time()
COOKIE = "zentry_session"
PRO_MODE_PATHS = ("/new_user_identified.fcgi", "/new_card.fcgi", "/new_biometric_image.fcgi",
                  "/new_biometric_template.fcgi", "/new_qrcode.fcgi", "/new_uhf_tag.fcgi",
                  "/new_user_id_and_password.fcgi")


class Request:
    def __init__(self, method, path, qs=None, body=None, headers=None, ip="", raw=b""):
        self.method, self.path, self.qs = method, path, qs or {}
        self.body, self.headers, self.ip, self.raw = body or {}, headers or {}, ip, raw

    def q(self, key, default=None):
        v = self.qs.get(key)
        return v[0] if isinstance(v, list) and v else (v if v is not None else default)

    def header(self, name):
        for k, v in self.headers.items():
            if k.lower() == name.lower():
                return v
        return ""

    def cookie_token(self):
        for part in self.header("Cookie").split(";"):
            k, _, v = part.strip().partition("=")
            if k == COOKIE:
                return v
        return ""

    def bearer(self):
        h = self.header("Authorization")
        return h[7:] if h.startswith("Bearer ") else ""


class Response:
    def __init__(self, status=200, body=None, ctype="application/json", headers=None):
        self.status, self.body, self.ctype, self.headers = status, body, ctype, headers or {}


def J(body, status=200, headers=None):
    return Response(status, body, "application/json", headers)


def err(status, msg):
    return J({"error": msg}, status)


class Api:
    def __init__(self, app):
        self.app = app
        self.cfg = app.cfg
        self.store = app.store
        self.auth = Auth(app.store, app.cfg)
        self._cache = {}
        self.recent = collections.deque(maxlen=60)  # últimos envios dos equipamentos (inspetor)

    # ------------------------------------------------------------ roteamento
    def handle(self, r):
        try:
            return self._route(r)
        except PermissionError:
            return err(403, "sem permissão para esta ação")
        except AuthError as e:
            return err(400, str(e))
        except settings.SettingsError as e:
            return err(400, str(e))
        except ValueError as e:
            return err(400, str(e))
        except Exception:
            log.exception("Erro em %s %s", r.method, r.path)
            return err(500, "erro interno")

    def _device_ok(self, ip):
        allowed = self.cfg["server"].get("allowed_device_ips", [])
        return not allowed or ip in allowed

    def _principal(self, r):
        """Retorna (usuário|None, via) onde via é 'cookie', 'key' ou None."""
        if r.bearer() and self.auth.api_key_ok(r.bearer()):
            return {"username": "integração", "role": "operator", "display_name": "Integração"}, "key"
        if r.method == "GET" and r.q("token") and self.auth.api_key_ok(r.q("token")):
            return {"username": "integração", "role": "operator", "display_name": "Integração"}, "key"
        u = self.auth.session(r.cookie_token())
        return (u, "cookie") if u else (None, None)

    def _route(self, r):
        p = r.path.rstrip("/") or "/"
        m = r.method
        # ---- públicas
        if p == "/health":
            return J({"ok": True, "time": int(time.time()), "version": __version__})
        # ---- equipamentos (push do Monitor; protegido por allowed_device_ips)
        if p.startswith("/api/notifications/") and m == "POST":
            if not self._device_ok(r.ip):
                return err(403, "IP não autorizado")
            try:
                n = handle_device_push(self.store, self.cfg, p, r.body, r.ip)
            except Exception:
                log.exception("Falha ao processar push de %s", r.ip)
                return J({})
            self._note_push(r, p, "controlid", 200, n)
            return J({"accepted": n})
        if p in ("/device_is_alive.fcgi", "/session_is_valid.fcgi"):
            if self._device_ok(r.ip):
                from .config import resolve_device
                cid, did = resolve_device(self.cfg, None, r.ip)
                self.store.heartbeat(cid, did)
            return J({})
        push = self._push_route(p)
        if push is not None:
            return self._push(r, p, push)
        if p in PRO_MODE_PATHS:
            return err(501, "O Zentry só observa. Deixe o equipamento em modo autônomo (standalone).")
        if not p.startswith("/api/"):
            return err(404, "não encontrado")
        # ---- sessão / instalação
        if p == "/api/session" and m == "GET":
            u, _ = self._principal(r)
            return J({"setup_needed": self.auth.count_accounts() == 0, "version": __version__,
                      "user": {k: u[k] for k in ("username", "role", "display_name")} if u else None})
        if p == "/api/setup" and m == "POST":
            return self._setup(r)
        if p == "/api/login" and m == "POST":
            return self._login(r)
        user, via = self._principal(r)
        if not user:
            return err(401, "entre com usuário e senha")
        if via == "cookie" and m != "GET" and r.header("X-Requested-With").lower() != "zentry":
            return err(403, "requisição bloqueada (CSRF)")
        if p == "/api/logout" and m == "POST":
            self.auth.logout(r.cookie_token())
            return J({"ok": True}, headers={"Set-Cookie": self._cookie("", 0)})
        # ---- leitura (viewer)
        client = r.q("client") or next(iter(self.cfg["clients"]), "default")
        if m == "GET":
            h = {
                "/api/overview": lambda: self.overview(client),
                "/api/alerts": lambda: self.alerts(client, r),
                "/api/events": lambda: self.events(client, r),
                "/api/timeline": lambda: self.timeline(client),
                "/api/heatmap": lambda: self.heatmap(client),
                "/api/devices": lambda: self.devices(client),
                "/api/people": lambda: self.people(client, r),
                "/api/patterns": lambda: self.patterns(client),
                "/api/detectors": lambda: self.detectors(client),
                "/api/notes": lambda: {"notes": [dict(x) for x in self.store.rows(
                    "SELECT id,text,created_at FROM notes WHERE client=? ORDER BY id DESC LIMIT 100", (client,))]},
                "/api/diagnostics": lambda: self.diagnostics(),
                "/api/update": lambda: self.app.updater.status(),
            }.get(p)
            if h:
                return J(h())
            mm = re.fullmatch(r"/api/alerts/(\d+)", p)
            if mm:
                a = self.alert_detail(int(mm.group(1)))
                return J(a) if a else err(404, "alerta não encontrado")
            if p == "/api/report":
                fmt = r.q("format", "html")
                body = report.generate(self.store, self.cfg, client, days=float(r.q("days", "1")), fmt=fmt)
                # relatório é um documento isolado (mostrado em iframe sandbox): pode ter estilo embutido, nunca script
                return Response(200, body, "text/html" if fmt == "html" else "text/markdown",
                                {"Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; img-src data:"})
            if p.startswith(("/api/config", "/api/accounts", "/api/audit", "/api/backups", "/api/recent-pushes")):
                return self._admin_get(r, user, p, client)
            if p.startswith("/api/devices/"):
                return self._device_tools(r, user, p, client)
            return err(404, "não encontrado")
        # ---- escrita
        if p.startswith("/api/devices/"):
            return self._device_tools(r, user, p, client)
        if p == "/api/ingest":
            self._need(user, "operator")
            return J({"accepted": handle_generic_ingest(self.store, self.cfg, r.body)})
        if p == "/api/password" and m == "POST":
            return self._change_own_password(r, user)
        mm = re.fullmatch(r"/api/alerts/(\d+)/feedback", p)
        if mm and m == "POST":
            self._need(user, "operator")
            row = self.app.engine.feedback(int(mm.group(1)), r.body.get("status", ""))
            if row:
                self.auth.audit(user["username"], "alert.feedback", f"#{mm.group(1)} -> {r.body.get('status')}", r.ip)
            return J({"ok": bool(row)}, 200 if row else 404)
        if p == "/api/command" and m == "POST":
            self._need(user, "operator")
            c = r.body.get("client") or client
            res = assistant.answer(self.app, c, str(r.body.get("text", ""))[:2000],
                                   session=f"{user['username']}:{str(r.body.get('session') or '')[:40]}")
            return J(res)
        if p == "/api/notes" and m == "POST":
            self._need(user, "operator")
            text = str(r.body.get("text", "")).strip()[:1000]
            if not text:
                raise ValueError("Escreva a anotação.")
            self.store.conn().execute("INSERT INTO notes(client,text,created_at) VALUES(?,?,?)",
                                      (client, text, int(time.time())))
            self.store.commit()
            return J({"ok": True})
        mm = re.fullmatch(r"/api/notes/(\d+)", p)
        if mm and m == "DELETE":
            self._need(user, "operator")
            self.store.conn().execute("DELETE FROM notes WHERE id=?", (int(mm.group(1)),))
            self.store.commit()
            return J({"ok": True})
        return self._admin_write(r, user, p, client)

    # ------------------------------------------------------------ push de equipamentos (todas as marcas)
    def is_device_path(self, p):
        """Rotas que equipamentos usam (liberadas na porta HTTP simples quando o painel está em HTTPS)."""
        p = p.rstrip("/") or "/"
        return (self._push_route(p) is not None or p.startswith("/api/notifications/") or p.endswith(".fcgi")
                or p == "/health")

    def _push_route(self, p):
        table = {"/api/push/hikvision": "hikvision", "/api/push/axis": "axis", "/api/push/generic": "generic",
                 "/iclock/cdata": "zkteco", "/iclock/getrequest": "zkteco", "/iclock/registry": "zkteco"}
        return table.get(p)

    def _push(self, r, p, brand):
        key_ok = self.auth.api_key_ok(r.bearer()) or self.auth.api_key_ok(r.q("token") or "")
        if not (self._device_ok(r.ip) or key_ok):
            return err(403, "IP não autorizado")
        if brand == "generic" and not key_ok and not self.cfg["server"].get("allowed_device_ips"):
            pass  # sem lista de IPs, o push genérico fica aberto na rede local (como o Monitor da Control iD)
        conn = get_connector(brand=brand)
        try:
            code, text, n = conn.handle_push(self.cfg, self.store, p, r.qs, r.raw if r.raw else r.body, r.ip)
        except Exception:
            log.exception("Falha no push %s de %s", brand, r.ip)
            code, text, n = 200, "OK", 0
        self._note_push(r, p, brand, code, n)
        return Response(code, text, "text/plain")

    def _note_push(self, r, p, brand, code, n):
        raw = r.raw.decode("utf-8", errors="replace") if r.raw else json.dumps(r.qs, ensure_ascii=False)
        self.recent.appendleft({"ts": int(time.time()), "ip": r.ip, "path": p, "brand": brand, "status": code,
                                "events": n, "sample": raw[:700]})

    # ------------------------------------------------------------ auth helpers
    def _need(self, user, role):
        if not has_role(user["role"], role):
            raise PermissionError(role)

    def _cookie(self, token, max_age):
        secure = "; Secure" if self.cfg["server"].get("tls", {}).get("enabled") else ""
        return f"{COOKIE}={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={int(max_age)}{secure}"

    def _login(self, r):
        token, acc = self.auth.login(str(r.body.get("username", "")), str(r.body.get("password", "")), r.ip)
        self.auth.audit(acc["username"], "login", "", r.ip)
        hours = float(self.cfg["server"].get("session_hours", 12))
        return J({"ok": True, "user": {k: acc[k] for k in ("username", "role", "display_name")}},
                 headers={"Set-Cookie": self._cookie(token, hours * 3600)})

    def _setup(self, r):
        if self.auth.count_accounts() > 0:
            return err(403, "A instalação já foi concluída.")
        b = r.body
        acc = self.auth.create_account(str(b.get("username", "")), str(b.get("password", "")), "admin",
                                       b.get("display_name"))
        changes = {}
        if b.get("timezone"):
            changes["timezone"] = b["timezone"]
        if changes:
            settings.apply_changes(self.cfg, self.app.config_path, changes)
        client = str(b.get("client_name") or "").strip()
        if client:
            cid = re.sub(r"[^a-z0-9]+", "-", client.lower()).strip("-") or "cliente"
            settings.apply_clients(self.cfg, self.app.config_path, {cid: {"name": client, "devices": {}, "detectors": {}}})
        self.auth.audit(acc["username"], "setup", "primeira configuração", r.ip)
        return self._login(Request("POST", "/api/login", body={"username": b["username"], "password": b["password"]}, ip=r.ip))

    def _change_own_password(self, r, user):
        if user["username"] == "integração":
            raise ValueError("Use uma conta de pessoa.")
        if not self.auth.store.one("SELECT 1 FROM accounts WHERE username=?", (user["username"],)):
            raise ValueError("Conta não encontrada.")
        self.auth.login(user["username"], str(r.body.get("current", "")), r.ip + "|pw")  # confere a senha atual
        self.auth.set_password(user["username"], str(r.body.get("new", "")))
        self.auth.audit(user["username"], "password.change", "", r.ip)
        return J({"ok": True})

    # ------------------------------------------------------------ admin
    def _admin_get(self, r, user, p, client):
        self._need(user, "admin")
        if p == "/api/config":
            return J({"config": settings.public_view(self.cfg), "editable": sorted(".".join(k) for k in settings.EDITABLE),
                      "connectors": [c.info() for c in all_connectors()],
                      "home": self.cfg.get("_home")})
        if p == "/api/accounts":
            return J({"accounts": self.auth.list_accounts(), "roles": list(ROLES)})
        if p == "/api/audit":
            return J({"audit": self.auth.audit_list(300)})
        if p == "/api/recent-pushes":
            return J({"pushes": list(self.recent)})
        if p == "/api/backups":
            return J({"backups": maintenance.list_backups(self.cfg)})
        mm = re.fullmatch(r"/api/backups/(.+)", p)
        if mm:
            path = maintenance.backup_path(self.cfg, mm.group(1))
            if not path:
                return err(404, "backup não encontrado")
            with open(path, "rb") as f:
                return Response(200, f.read(), "application/octet-stream",
                                {"Content-Disposition": f'attachment; filename="{mm.group(1)}"'})
        return err(404, "não encontrado")

    def _device_tools(self, r, user, p, client):
        """Câmera (foto/RTSP) e interfone SIP do equipamento."""
        from . import camera
        mm = re.fullmatch(r"/api/devices/([^/]+)/(snapshot|camera|rtsp|sip|sip/status|sip/call|sip/hangup)", p)
        if not mm:
            return err(404, "não encontrado")
        did, what = mm.group(1), mm.group(2)
        d = (self.cfg["clients"].get(client, {}).get("devices") or {}).get(did)
        if not d:
            return err(404, "equipamento não encontrado")
        if device_brand(self.cfg, client, d) != "controlid":
            return err(400, "Câmera e SIP pelo painel estão disponíveis só para Control iD por enquanto.")
        write = r.method != "GET"
        try:
            if what == "snapshot" and not write:
                self._need(user, "operator")
                return Response(200, camera.snapshot(d, r.q("camera", "rgb")), "image/png")
            if what == "camera" and not write:
                self._need(user, "operator")
                return J(camera.rtsp_info(d))
            if what in ("rtsp", "sip") and write:
                self._need(user, "admin")
                out = camera.rtsp_set(d, bool(r.body.get("enabled"))) if what == "rtsp" else camera.sip_set(d, r.body)
                self.auth.audit(user["username"], f"device.{what}", f"{did}", r.ip)
                return J({"ok": True, **out})
            if what == "sip" and not write:
                self._need(user, "admin")
                return J({"sip": camera.sip_get(d)})
            if what == "sip/status" and not write:
                self._need(user, "operator")
                return J(camera.sip_status(d))
            if what == "sip/call" and write:
                self._need(user, "operator")
                out = camera.sip_call(d, r.body.get("target"))
                self.auth.audit(user["username"], "device.sip.call", f"{did} -> {str(r.body.get('target'))[:64]}", r.ip)
                return J({"ok": True, **(out if isinstance(out, dict) else {})})
            if what == "sip/hangup" and write:
                self._need(user, "operator")
                return J({"ok": True, **(camera.sip_hangup(d) or {})})
        except camera.DeviceError as e:
            return err(502, str(e))
        return err(405, "método não permitido")

    def _admin_write(self, r, user, p, client):
        m = r.method
        self._need(user, "admin")
        who, ip = user["username"], r.ip
        mm = re.fullmatch(r"/api/events/(\d+)", p)
        if mm and m == "DELETE":
            cur = self.store.conn().execute("DELETE FROM events WHERE client=? AND id=?", (client, int(mm.group(1))))
            self.store.commit()
            self.auth.audit(who, "event.delete", f"#{mm.group(1)}", ip)
            return J({"ok": cur.rowcount == 1}, 200 if cur.rowcount == 1 else 404)
        if p == "/api/events/clear" and m == "POST":
            if r.body.get("confirm") != "APAGAR":
                raise ValueError("Confirmação ausente.")
            cur = self.store.conn().execute("DELETE FROM events WHERE client=?", (client,))
            self.store.commit()
            self.auth.audit(who, "event.clear", f"{cur.rowcount} eventos de {client}", ip)
            return J({"ok": True, "deleted": cur.rowcount})
        if p == "/api/config" and m == "PUT":
            changed = settings.apply_changes(self.cfg, self.app.config_path, r.body)
            self.auth.audit(who, "config.update", ", ".join(changed), ip)
            return J({"ok": True, "changed": changed, "restart_needed": any(
                c in ("server.host", "server.port") for c in changed)})
        if p == "/api/clients" and m == "PUT":
            ids = settings.apply_clients(self.cfg, self.app.config_path, r.body)
            self.auth.audit(who, "clients.update", ", ".join(ids), ip)
            return J({"ok": True})
        if p == "/api/accounts" and m == "POST":
            a = self.auth.create_account(str(r.body.get("username", "")), str(r.body.get("password", "")),
                                         str(r.body.get("role", "operator")), r.body.get("display_name"))
            self.auth.audit(who, "account.create", f"{a['username']} ({a['role']})", ip)
            return J({"ok": True, "account": a})
        mm = re.fullmatch(r"/api/accounts/([\w.\-]+)", p)
        if mm and m == "PATCH":
            a = self.auth.update_account(mm.group(1), r.body.get("role"), r.body.get("disabled"), r.body.get("display_name"))
            if r.body.get("password"):
                self.auth.set_password(mm.group(1), str(r.body["password"]))
            self.auth.audit(who, "account.update", mm.group(1), ip)
            return J({"ok": True, "account": a})
        if mm and m == "DELETE":
            if mm.group(1) == who:
                raise ValueError("Você não pode apagar a si mesmo.")
            self.auth.delete_account(mm.group(1))
            self.auth.audit(who, "account.delete", mm.group(1), ip)
            return J({"ok": True})
        if p == "/api/backups" and m == "POST":
            path = maintenance.make_backup(self.app)
            self.auth.audit(who, "backup.create", path.rsplit("/", 1)[-1], ip)
            return J({"ok": True, "name": path.replace("\\", "/").rsplit("/", 1)[-1]})
        mm2 = re.fullmatch(r"/api/backups/(zentry-\d{8}-\d{6}(?:-pre)?\.db)/restore", p)
        if mm2 and m == "POST":
            maintenance.stage_restore(self.cfg, mm2.group(1))
            self.auth.audit(who, "backup.restore.staged", mm2.group(1), ip)
            return J({"ok": True, "restart_needed": True})
        if p == "/api/restart" and m == "POST":
            self.auth.audit(who, "restart", "", ip)
            if self._schedule_restart():
                return J({"ok": True, "detail": "Reiniciando… o painel volta em alguns segundos."})
            return J({"ok": False, "detail": "Feche e abra o Zentry para aplicar."})
        if p == "/api/update/check" and m == "POST":
            return J(self.app.updater.check(force=True))
        if p == "/api/update/install" and m == "POST":
            self.auth.audit(who, "update.install", str(self.app.updater.status().get("latest", {}).get("version")), ip)
            self.app.updater.start_install()
            return J({"ok": True})
        if p == "/api/test/notify" and m == "POST":
            return J({"results": self.app.notifier.test_channels()})
        if p == "/api/test/voice" and m == "POST":
            ok = voice.speak("Zentry IA ativado. Teste de voz do computador.", wait=True)
            return J({"ok": bool(ok), "detail": "Falou pelas caixas de som." if ok else "Sem sintetizador de voz neste PC."})
        if p == "/api/discover" and m == "POST":
            from . import discovery
            sub = [str(x) for x in (r.body.get("subnets") or [])] or None
            return J(discovery.scan(sub))
        if p == "/api/test/device" and m == "POST":
            c = str(r.body.get("client") or client)
            did = str(r.body.get("device_id", ""))
            d = (self.cfg["clients"].get(c, {}).get("devices") or {}).get(did, {})
            return J(get_connector(brand=device_brand(self.cfg, c, d)).test_device(self.cfg, c, did))
        return err(404, "não encontrado")

    # ------------------------------------------------------------ dados
    def _schedule_restart(self):
        hook = self.app.restart_hook
        if not hook:
            return False
        threading.Timer(1.0, hook).start()
        return True

    def _tz(self):
        return get_tz(self.cfg.get("timezone", "America/Sao_Paulo"))

    def overview(self, client):
        now = int(time.time())
        st = self.store
        stats = report.build_stats(st, self.cfg, client, days=1, now=now)
        k = stats["kinds"]
        grants, fails = k.get("grant", 0), k.get("deny", 0) + k.get("not_identified", 0)
        lim = self.cfg["engine"]["probe_interval_seconds"] * 10
        devs = self.devices(client)["devices"]
        score = (100 - min(60, 15 * stats["open_critical"]) - min(25, 2 * stats["open_attention"])
                 - min(15, 8 * sum(1 for d in devs if d["offline"])))
        return {
            "client": client, "clients": [{"id": c, "name": client_name(self.cfg, c)} for c in self.cfg["clients"]],
            "now": now, "grants_24h": grants, "fails_24h": fails, "turns_24h": k.get("turn", 0),
            "fail_rate": (fails / (grants + fails)) if grants + fails else 0.0,
            "open_critical": stats["open_critical"], "open_attention": stats["open_attention"],
            "open_total": st.scalar("SELECT COUNT(*) FROM alerts WHERE client=? AND status='new'", (client,)),
            "devices_total": len(devs), "devices_offline": sum(1 for d in devs if d["offline"]),
            "patterns_known": stats["patterns_total"], "patterns_new": stats["patterns_new"],
            "repeats_ignored": stats["repeats_ignored"], "health": max(0, min(100, score)),
            "top_alerts": [dict(a) for a in stats["open_alerts"][:6]], "analysis": [x for x in report.local_analysis(stats) if not x.startswith("Recomenda")][:7],
            "llm": bool(self.cfg["llm"].get("enabled")),
        }

    def alerts(self, client, r):
        status = r.q("status", "new")
        sev = r.q("severity")
        sql = ("SELECT id,detector,severity,title,detail,device_id,user_id,status,count,created_at,last_seen_at "
               "FROM alerts WHERE client=?")
        p = [client]
        if status != "all":
            sql += " AND status=?"
            p.append(status)
        if sev:
            sql += " AND severity=?"
            p.append(sev)
        sql += " ORDER BY id DESC LIMIT ?"
        p.append(min(int(r.q("limit", "200")), 500))
        order = {"critico": 0, "alto": 1, "atencao": 2, "info": 3}
        rows = sorted((dict(x) for x in self.store.rows(sql, p)), key=lambda a: (order.get(a["severity"], 9), -a["id"]))
        for a in rows:
            a["user_label"] = self._user_label(client, a.pop("user_id"))
            a["device_name"] = self._dev_name(client, a["device_id"])
        return {"alerts": rows}

    def alert_detail(self, aid):
        a = self.store.one("SELECT * FROM alerts WHERE id=?", (aid,))
        if not a:
            return None
        a = dict(a)
        try:
            a["evidence"] = json.loads(a.get("evidence") or "{}")
        except ValueError:
            a["evidence"] = {}
        a["user_label"] = self._user_label(a["client"], a.pop("user_id"))
        a["device_name"] = self._dev_name(a["client"], a["device_id"])
        a.pop("fingerprint", None)
        meta = next((d for d in self.app.detectors.values() if d.name == a["detector"]), None)
        a["detector_title"], a["detector_description"] = (meta.title, meta.description) if meta else (a["detector"], "")
        since = a["created_at"] - 1800
        a["events"] = [self._ev(dict(e), a["client"]) for e in self.store.rows(
            "SELECT * FROM events WHERE client=? AND ts BETWEEN ? AND ? AND (device_id=? OR ?) ORDER BY ts DESC LIMIT 40",
            (a["client"], since, a["created_at"] + 600, a["device_id"], a["device_id"] is None))]
        return a

    def _user_label(self, client, uid):
        if not uid:
            return None
        r = self.store.one("SELECT name FROM users WHERE client=? AND user_id=?", (client, uid))
        return (r["name"] if r and r["name"] else None) or f"ID {uid}"

    def _dev_name(self, client, did):
        if not did:
            return None
        from .config import device_cfg
        n = device_cfg(self.cfg, client, did).get("name")
        if not n:
            r = self.store.one("SELECT name FROM devices WHERE client=? AND device_id=?", (client, did))
            n = r["name"] if r and r["name"] else None
        return n or f"Equipamento {did}"

    def _ev(self, e, client, cache=None):
        cache = cache if cache is not None else {}
        did, uid = e["device_id"], e.get("user_id")
        name = e.get("user_name")
        if not name and uid:
            k = ("u", uid)
            if k not in cache:
                r = self.store.one("SELECT name FROM users WHERE client=? AND user_id=?", (client, uid))
                cache[k] = r["name"] if r else None
            name = cache[k]
        raw = {}
        try:
            raw = json.loads(e.get("raw") or "{}")
            raw = raw if isinstance(raw, dict) else {}
        except ValueError:
            pass
        dc = (self.cfg["clients"].get(client, {}).get("devices") or {}).get(did, {})
        sector = None
        if e.get("portal_id") is not None:
            k = ("s", did)
            if k not in cache:
                try:
                    cache[k] = json.loads(self.store.meta_get(f"sectors:{client}:{did}") or "{}")
                except ValueError:
                    cache[k] = {}
            sector = cache[k].get(str(e["portal_id"]))
        sector = sector or dc.get("zone")
        return {"id": e["id"], "ts": e["ts"], "kind": e["kind"], "device_id": did,
                "device_name": self._dev_name(client, did),
                "user": name or (f"ID {uid}" if uid else None), "user_id": uid, "user_name": name,
                "method": access_method(raw, dc.get("type")), "sector": sector}

    def events(self, client, r):
        after = int(r.q("after", "0"))
        sql = "SELECT * FROM events WHERE client=? AND id>?"
        p = [client, after]
        if r.q("kind"):
            sql += " AND kind=?"
            p.append(r.q("kind"))
        if r.q("device"):
            sql += " AND device_id=?"
            p.append(r.q("device"))
        sql += " ORDER BY id DESC LIMIT ?"
        p.append(min(int(r.q("limit", "80")), 300))
        cache = {}
        return {"events": [self._ev(dict(e), client, cache) for e in self.store.rows(sql, p)]}

    def timeline(self, client):
        now = int(time.time())
        tz = self._tz()
        start = now - 24 * 3600
        rows = self.store.rows("SELECT ts,kind FROM events WHERE client=? AND ts>=?", (client, start))
        hour0 = start - start % 3600
        buckets = collections.OrderedDict((hour0 + i * 3600, {"grant": 0, "fail": 0}) for i in range(25))
        for e in rows:
            b = e["ts"] - e["ts"] % 3600
            if b in buckets:
                if e["kind"] == "grant":
                    buckets[b]["grant"] += 1
                elif e["kind"] in ("deny", "not_identified"):
                    buckets[b]["fail"] += 1
        return {"points": [{"ts": t, "label": datetime.fromtimestamp(t, tz).strftime("%Hh"), **v}
                           for t, v in buckets.items()]}

    def heatmap(self, client):
        now = int(time.time())
        tz = self._tz()
        grid = [[0] * 24 for _ in range(7)]
        for e in self.store.rows("SELECT ts FROM events WHERE client=? AND kind='grant' AND ts>=?",
                                 (client, now - 28 * 86400)):
            d = datetime.fromtimestamp(e["ts"], tz)
            grid[d.weekday()][d.hour] += 1
        return {"grid": grid, "days": 28}

    def devices(self, client):
        stats = report.build_stats(self.store, self.cfg, client, days=1)
        lim = self.cfg["engine"]["probe_interval_seconds"] * 10
        cdev = (self.cfg["clients"].get(client, {}) or {}).get("devices", {})
        seen = {d["id"] for d in stats["devices"]}
        out = []
        for d in stats["devices"]:
            dc = cdev.get(d["id"], {})
            age = d["last_seen_age"]
            monitored = bool(dc.get("ip") or dc.get("heartbeat"))
            out.append({**d, "ip": dc.get("ip"), "zone": dc.get("zone"), "direction": dc.get("direction"),
                        "type": dc.get("type"), "monitored": monitored,
                        "offline": bool(monitored and age is not None and age > lim)})
        for did, dc in cdev.items():  # configurado mas nunca visto
            if did not in seen:
                out.append({"id": did, "name": dc.get("name") or f"Equipamento {did}", "attempts": 0, "grants": 0,
                            "fail": 0, "turns": 0, "fail_rate": 0.0, "last_seen_age": None, "ip": dc.get("ip"),
                            "zone": dc.get("zone"), "direction": dc.get("direction"), "type": dc.get("type"),
                            "monitored": bool(dc.get("ip")), "offline": bool(dc.get("ip"))})
        return {"devices": out}

    def people(self, client, r):
        q = (r.q("q") or "").strip().lower()
        now = int(time.time())
        rows = self.store.rows(
            "SELECT e.user_id uid, MAX(e.user_name) name, COUNT(*) n, MAX(e.ts) last, "
            "SUM(e.kind IN ('deny','not_identified')) fails FROM events e WHERE e.client=? AND e.ts>=? "
            "AND e.user_id IS NOT NULL GROUP BY e.user_id ORDER BY n DESC LIMIT 300", (client, now - 30 * 86400))
        out = [{"id": x["uid"], "name": x["name"] or f"ID {x['uid']}", "events_30d": x["n"], "fails_30d": x["fails"] or 0,
                "last": x["last"]} for x in rows]
        if q:
            out = [p for p in out if q in p["name"].lower() or q in str(p["id"]).lower()]
        return {"people": out[:100]}

    def patterns(self, client):
        rows = self.store.rows(
            "SELECT signature,detector,first_seen,last_seen,times,last_alert_id FROM known_patterns "
            "WHERE client=? ORDER BY last_seen DESC LIMIT 300", (client,))
        return {"patterns": [dict(x) for x in rows],
                "total": self.store.scalar("SELECT COUNT(*) FROM known_patterns WHERE client=?", (client,))}

    def detectors(self, client):
        out = []
        for d in sorted(self.app.detectors.values(), key=lambda x: x.name):
            cur = detector_cfg(self.cfg, client, d.name)
            out.append({"name": d.name, "title": d.title, "description": d.description,
                        "params": [{"key": k, "default": dflt, "label": lab, "unit": unit, "value": cur.get(k, dflt)}
                                   for k, dflt, lab, unit in d.params]})
        return {"detectors": out}

    def diagnostics(self):
        import platform
        import sys
        st = self.store
        now = int(time.time())
        from . import chat
        return {"version": __version__, "python": sys.version.split()[0], "os": platform.platform(),
                "uptime_s": int(now - START), "home": self.cfg.get("_home"),
                "db_events": st.scalar("SELECT COUNT(*) FROM events"), "db_alerts": st.scalar("SELECT COUNT(*) FROM alerts"),
                "last_event_age": (now - st.scalar("SELECT MAX(ts) FROM events")) if st.scalar("SELECT MAX(ts) FROM events") else None,
                "chat_ia": bool(chat.available(self.cfg)), "voice_pc": bool(voice.available()),
                "tz": self.cfg.get("timezone"), "detectors": len(self.app.detectors),
                "backups": len(maintenance.list_backups(self.cfg))}
