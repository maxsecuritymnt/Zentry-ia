"""Hikvision (ISAPI). Terminais faciais/controladoras: DS-K1T…, DS-K2…

Consulta: POST /ISAPI/AccessControl/AcsEvent?format=json (Digest) — confirmado na comunidade.
Push: o equipamento envia eventos para uma URL (“Network → Event Server / HTTP listening”): /api/push/hikvision.
Os códigos major/minor abaixo são os mais comuns; ajuste com `hikvision_event_map` na configuração se o seu modelo diferir.
"""

import json
import uuid
from datetime import datetime, timedelta, timezone

from .base import Connector
from .common import extract_json, parse_ts

# major 5 = eventos de controle de acesso. minor -> tipo do Zentry
DEFAULT_MINOR_MAP = {1: "grant", 38: "grant", 75: "grant", 39: "deny", 76: "deny", 9: "deny"}
MAJOR_ACCESS = 5


def minor_kind(cfg, major, minor):
    if major != MAJOR_ACCESS:
        return None
    custom = (cfg or {}).get("hikvision_event_map") or {}
    kind = custom.get(str(minor)) or DEFAULT_MINOR_MAP.get(minor)
    return kind or "other"


def normalize(cfg, rec, fallback_ts=None):
    """InfoList[i] (consulta) ou AccessControllerEvent (push) -> dict de evento, ou None se não for de acesso."""
    major = rec.get("major", rec.get("majorEventType"))
    minor = rec.get("minor", rec.get("subEventType"))
    try:
        major, minor = int(major), int(minor)
    except (TypeError, ValueError):
        return None
    kind = minor_kind(cfg, major, minor)
    if kind is None:
        return None
    uid = rec.get("employeeNoString") or rec.get("employeeNo") or rec.get("cardNo") or None
    ts = parse_ts(rec.get("time") or rec.get("dateTime")) or fallback_ts
    return {"ts": ts, "kind": kind, "user_id": str(uid) if uid not in (None, "", "0") else None,
            "user_name": rec.get("name") or None, "code": minor,
            "src_id": str(rec["serialNo"]) if rec.get("serialNo") is not None else None,
            "portal_id": rec.get("doorNo")}


class HikvisionConnector(Connector):
    name = "hikvision"
    label = "Hikvision (ISAPI)"
    push_path = "/api/push/hikvision"
    help = ("PUSH (recomendado): no equipamento, Configuração → Rede → Serviço de integração (ou “Event Server / HTTP Listening”), "
            "aponte para o IP deste computador, porta 8000, caminho /api/push/hikvision. "
            "CONSULTA: marque “Consultar”, informe usuário e senha do equipamento (Digest). "
            "Se os códigos não baterem com o seu modelo, ajuste hikvision_event_map no config.json.")

    def check(self, d):
        return self.request(d, "GET", "/ISAPI/System/deviceInfo")

    def poll_device(self, cfg, store, client, device_id, d):
        key = f"cursor:{client}:{device_id}"
        last = int(store.meta_get(key, 0) or 0)
        now = datetime.now(timezone.utc)
        start = datetime.fromtimestamp(max(last - 120, int(now.timestamp()) - 3 * 86400), timezone.utc)
        n, pos, newest = 0, 0, last
        for _ in range(40):
            body = json.dumps({"AcsEventCond": {
                "searchID": uuid.uuid4().hex, "searchResultPosition": pos, "maxResults": 30, "major": 0, "minor": 0,
                "startTime": start.strftime("%Y-%m-%dT%H:%M:%S+00:00"),
                "endTime": (now + timedelta(minutes=5)).strftime("%Y-%m-%dT%H:%M:%S+00:00")}})
            data = json.loads(self.request(d, "POST", "/ISAPI/AccessControl/AcsEvent?format=json", body,
                                           {"Content-Type": "application/json"}) or "{}")
            ev = data.get("AcsEvent", {})
            infos = ev.get("InfoList") or []
            for rec in infos:
                e = normalize(cfg, rec)
                if not e or not e["ts"]:
                    continue
                n += int(store.add_event(client, device_id, e["ts"], e["kind"], e["user_id"], e["user_name"],
                                         e["portal_id"], e["code"], e["src_id"] or f"{e['ts']}-{e['code']}-{e['user_id']}",
                                         json.dumps(rec, ensure_ascii=False), live=False, commit=False))
                newest = max(newest, e["ts"])
            pos += len(infos)
            if not infos or ev.get("responseStatusStrg") != "MORE":
                break
        store.commit()
        store.meta_set(key, newest)
        return n

    def handle_push(self, cfg, store, path, query, body, ip, now=None):
        from ..config import resolve_device
        import time
        now = int(now if now is not None else time.time())
        payload = extract_json(body)
        if not isinstance(payload, dict):
            return 400, "corpo não reconhecido", 0
        client, did = resolve_device(cfg, None, ip)
        if did == ip and payload.get("ipAddress"):  # veio por proxy/NAT: tenta o IP informado pelo equipamento
            client, did = resolve_device(cfg, None, payload["ipAddress"])
        store.heartbeat(client, did, now)
        rec = payload.get("AccessControllerEvent")
        if payload.get("eventType") == "heartbeat" or not isinstance(rec, dict):
            return 200, "OK", 0
        e = normalize(cfg, rec, fallback_ts=parse_ts(payload.get("dateTime")) or now)
        if not e:
            return 200, "OK", 0
        e["ts"] = e["ts"] or parse_ts(payload.get("dateTime")) or now
        ok = store.add_event(client, did, e["ts"], e["kind"], e["user_id"], e["user_name"], e["portal_id"], e["code"],
                             e["src_id"], json.dumps(payload, ensure_ascii=False), live=True, now=now)
        return 200, "OK", int(ok)
