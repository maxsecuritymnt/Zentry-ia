"""Onde ficam os arquivos do Zentry (configuração, banco, backups, logs).

Instalado como programa: a pasta de dados fica fora da pasta do programa, para que atualizar ou
desinstalar o software nunca apague o banco.
  Windows: %ProgramData%\\ZentryIA     macOS: ~/Library/Application Support/ZentryIA     Linux: ~/.local/share/zentry
Modo portátil/desenvolvimento: se existir um config.json na pasta atual, ela é usada.
`ZENTRY_HOME` sobrescreve tudo.
"""

import os
import platform
from pathlib import Path


def default_home():
    env = os.environ.get("ZENTRY_HOME")
    if env:
        return Path(env).expanduser()
    if (Path.cwd() / "config.json").exists():
        return Path.cwd()
    system = platform.system()
    if system == "Windows":
        base = os.environ.get("PROGRAMDATA") or os.environ.get("LOCALAPPDATA") or str(Path.home())
        return Path(base) / "ZentryIA"
    if system == "Darwin":
        return Path.home() / "Library" / "Application Support" / "ZentryIA"
    return Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share")) / "zentry"


def config_file(home=None):
    return Path(home or default_home()) / "config.json"


def home_path(cfg, rel):
    """Caminho absoluto de um item da configuração (relativo à pasta de dados)."""
    p = Path(rel)
    return str(p if p.is_absolute() else Path(cfg.get("_home", ".")) / p)
