"""Relatórios com análise crítica. Offline: modelo fixo com números. Online (opcional): LLM."""

import html
import json
import logging
import os
import time
import urllib.request
from collections import Counter
from datetime import datetime
from .timeutil import get_tz

from .config import SEVERITY_ORDER, client_name, device_cfg, llm_api_key
from .ingest import anon_id

log = logging.getLogger("zentry")

RECOMMENDATIONS = {
    "equipamento_offline": "Verificar alimentação, cabo e switch dos equipamentos sem comunicação e abrir chamado.",
    "relogio_desajustado": "Ajustar NTP/fuso horário dos equipamentos para manter a auditoria confiável.",
    "equipamento_silencioso": "Inspecionar leitoras sem movimento em horário normal (teste de leitura e de rede).",
    "degradacao_leitora": "Agendar manutenção preventiva (limpeza, posição, iluminação) nas leitoras com falhas crescentes.",
    "porta_aberta_tempo_excessivo": "Checar sensor/mola/fechadura das portas que ficam abertas e orientar os usuários.",
    "forca_bruta": "Revisar credenciais com muitas negações e verificar câmeras nos horários dos alertas.",
    "excesso_negacoes": "Revisar regras de horário, cadastros vencidos e a qualidade do cadastro facial.",
    "viagem_impossivel": "Investigar credenciais usadas em dois lugares ao mesmo tempo (clonagem ou empréstimo).",
    "horario_atipico": "Confirmar com os responsáveis os acessos fora do padrão e, se for o caso, ajustar permissões.",
    "anti_passback": "Reforçar a orientação contra carona e avaliar ativar anti-passback no equipamento.",
    "credenciais_inativas": "Bloquear/remover credenciais sem uso (ex-moradores, ex-funcionários).",
    "catraca_divergencia": "Testar sensores de giro e braços da catraca; revisar imagens de passagens sem liberação.",
}


def _local_hour(ts, tz):
    return datetime.fromtimestamp(ts, tz).hour


def build_stats(store, cfg, client, days=1, now=None):
    now = int(now if now is not None else time.time())
    t0 = now - int(days * 86400)
    tz = get_tz(cfg.get("timezone", "America/Sao_Paulo"))
    ev = store.rows("SELECT device_id, kind, user_id, ts FROM events WHERE client=? AND ts>=? AND ts<=?",
                    (client, t0, now))
    kinds = Counter(e["kind"] for e in ev)
    per_dev = {}
    for e in ev:
        d = per_dev.setdefault(e["device_id"], Counter())
        d[e["kind"]] += 1
    devices = []
    for r in store.rows("SELECT * FROM devices WHERE client=?", (client,)):
        c = per_dev.get(r["device_id"], Counter())
        attempts = c["grant"] + c["deny"] + c["not_identified"]
        name = device_cfg(cfg, client, r["device_id"]).get("name") or r["name"] or f"Equipamento {r['device_id']}"
        devices.append({
            "id": r["device_id"], "name": name, "attempts": attempts, "grants": c["grant"],
            "fail": c["deny"] + c["not_identified"], "turns": c["turn"],
            "fail_rate": ((c["deny"] + c["not_identified"]) / attempts) if attempts else 0.0,
            "last_seen_age": (now - r["last_seen"]) if r["last_seen"] else None,
        })
    hours = Counter(_local_hour(e["ts"], tz) for e in ev if e["kind"] == "grant")
    denied = Counter(e["user_id"] for e in ev if e["kind"] == "deny" and e["user_id"])
    alerts = store.rows(
        "SELECT detector, severity, COUNT(*) n, SUM(count) occurrences FROM alerts "
        "WHERE client=? AND created_at>=? GROUP BY detector, severity", (client, t0))
    open_alerts = store.rows(
        "SELECT id, detector, severity, title, detail, device_id, created_at, count FROM alerts "
        "WHERE client=? AND status='new' ORDER BY created_at DESC LIMIT 200", (client,))
    open_alerts = sorted(open_alerts, key=lambda a: (-SEVERITY_ORDER.get(a["severity"], 0), -a["created_at"]))
    return {
        "client": client, "client_name": client_name(cfg, client), "days": days, "now": now, "t0": t0,
        "total_events": len(ev), "kinds": dict(kinds), "devices": devices,
        "peak_hours": [h for h, _ in hours.most_common(3)],
        "top_denied": [(u, n) for u, n in denied.most_common(5)],
        "alerts_by_detector": [dict(r) for r in alerts],
        "open_alerts": [dict(a) for a in open_alerts[:15]],
        "open_critical": sum(1 for a in open_alerts if a["severity"] == "critico"),
        "open_attention": sum(1 for a in open_alerts if a["severity"] == "atencao"),
        "patterns_total": store.scalar("SELECT COUNT(*) FROM known_patterns WHERE client=?", (client,)),
        "patterns_new": store.scalar("SELECT COUNT(*) FROM known_patterns WHERE client=? AND first_seen>=?", (client, t0)),
        "repeats_ignored": store.scalar(
            "SELECT COALESCE(SUM(count-1),0) FROM alerts WHERE client=? AND last_seen_at>=?", (client, t0)),
    }


def local_analysis(stats):
    """Análise crítica sem IA externa: funciona offline."""
    out = []
    if stats["total_events"] == 0:
        return ["Nenhum evento no período. Verifique a coleta (Monitor/rede) antes de confiar nos números."]
    k = stats["kinds"]
    attempts = k.get("grant", 0) + k.get("deny", 0) + k.get("not_identified", 0)
    fails = k.get("deny", 0) + k.get("not_identified", 0)
    if attempts:
        out.append(f"{attempts} tentativas de acesso no período, {fails} negadas/não identificadas "
                   f"({fails / attempts:.0%}).")
    out.append(f"Aprendizado: {stats['patterns_new']} padrão(ões) novo(s) no período ({stats['patterns_total']} no total); "
               f"{stats['repeats_ignored']} repetição(ões) de alertas iguais foram ignoradas.")
    if stats["open_critical"]:
        out.append(f"{stats['open_critical']} alerta(s) CRÍTICO(S) em aberto: tratar primeiro.")
    elif stats["open_attention"]:
        out.append(f"{stats['open_attention']} alerta(s) de atenção em aberto, nenhum crítico.")
    else:
        out.append("Nenhum alerta em aberto no momento.")
    worst = sorted([d for d in stats["devices"] if d["attempts"] >= 20], key=lambda d: -d["fail_rate"])[:1]
    if worst and worst[0]["fail_rate"] >= 0.2:
        out.append(f"Equipamento com mais falhas: {worst[0]['name']} ({worst[0]['fail_rate']:.0%} de falhas).")
    seen = []
    for a in stats["alerts_by_detector"]:
        if a["detector"] not in seen and a["detector"] in RECOMMENDATIONS:
            seen.append(a["detector"])
    for d in seen:
        out.append("Recomendação: " + RECOMMENDATIONS[d])
    return out


def llm_analysis(cfg, stats):
    """Análise crítica com Claude (opcional). Envia apenas números e identificadores anonimizados."""
    lcfg = cfg.get("llm", {})
    key = llm_api_key(cfg)
    if not lcfg.get("enabled", True) or not key:
        return None
    payload = {
        "periodo_dias": stats["days"], "eventos": stats["kinds"],
        "equipamentos": [{k: d[k] for k in ("name", "attempts", "fail_rate", "turns")} for d in stats["devices"]],
        "alertas": [{"detector": a["detector"], "severidade": a["severity"], "ocorrencias": a["occurrences"]}
                    for a in stats["alerts_by_detector"]],
        "alertas_abertos": [{"detector": a["detector"], "severidade": a["severity"], "equipamento": a["device_id"]}
                            for a in stats["open_alerts"]],
        "mais_negados": [{"usuario": anon_id(cfg, u), "negacoes": n} for u, n in stats["top_denied"]],
    }
    prompt = ("Você é o Zentry IA, analista de segurança de controle de acesso de uma empresa de automação predial. "
              "Com os números abaixo (sem dados pessoais), escreva em português uma análise crítica curta: "
              "1) situação geral, 2) riscos prioritários, 3) ações recomendadas para a equipe de manutenção. "
              "Seja objetivo e não invente fatos.\n\n" + json.dumps(payload, ensure_ascii=False))
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=json.dumps({"model": lcfg.get("model", "claude-sonnet-5-5"), "max_tokens": 700,
                         "messages": [{"role": "user", "content": prompt}]}).encode(),
        headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
        method="POST")
    try:
        data = json.loads(urllib.request.urlopen(req, timeout=30).read().decode())
        return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text").strip() or None
    except Exception as e:
        log.warning("Análise por IA indisponível (%s). Usando análise local.", e)
        return None


def render_markdown(stats, analysis_lines, ai_text=None):
    tz_now = datetime.fromtimestamp(stats["now"]).strftime("%d/%m/%Y %H:%M")
    L = [f"# Zentry IA - Relatório de {stats['client_name']}",
         f"Período: últimos {stats['days']} dia(s), gerado em {tz_now}", "", "## Análise crítica"]
    L += [f"- {x}" for x in analysis_lines]
    if ai_text:
        L += ["", "### Parecer da IA", ai_text]
    L += ["", "## Equipamentos", "| Equipamento | Tentativas | Falhas | Taxa de falha | Giros |", "|---|---|---|---|---|"]
    for d in stats["devices"]:
        L.append(f"| {d['name']} | {d['attempts']} | {d['fail']} | {d['fail_rate']:.0%} | {d['turns']} |")
    L += ["", "## Alertas em aberto"]
    L += [f"- [{a['severity'].upper()}] {a['title']}" for a in stats["open_alerts"]] or ["- Nenhum"]
    return "\n".join(L)


def render_html(stats, analysis_lines, ai_text=None):
    e = html.escape
    tz_now = datetime.fromtimestamp(stats["now"]).strftime("%d/%m/%Y %H:%M")
    rows = "".join(
        f"<tr><td>{e(d['name'])}</td><td>{d['attempts']}</td><td>{d['fail']}</td>"
        f"<td>{d['fail_rate']:.0%}</td><td>{d['turns']}</td></tr>" for d in stats["devices"])
    alerts = "".join(f"<li class='{e(a['severity'])}'><b>{e(a['severity'].upper())}</b> {e(a['title'])}</li>"
                     for a in stats["open_alerts"]) or "<li>Nenhum</li>"
    ana = "".join(f"<li>{e(x)}</li>" for x in analysis_lines)
    ai = f"<h3>Parecer da IA</h3><p>{e(ai_text).replace(chr(10), '<br>')}</p>" if ai_text else ""
    return f"""<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Zentry IA - Relatório</title>
<style>body{{font:15px/1.5 system-ui,sans-serif;max-width:860px;margin:24px auto;padding:0 16px;color:#1b2430}}
table{{border-collapse:collapse;width:100%}}td,th{{border-bottom:1px solid #d9dee5;padding:6px 8px;text-align:left}}
li.critico b{{color:#b3261e}}li.atencao b{{color:#9a6700}}h1{{margin-bottom:0}}small{{color:#5b6573}}</style>
<h1>Zentry IA</h1><small>Relatório de {e(stats['client_name'])} · últimos {stats['days']} dia(s) · gerado em {tz_now}</small>
<h2>Análise crítica</h2><ul>{ana}</ul>{ai}
<h2>Equipamentos</h2><table><tr><th>Equipamento</th><th>Tentativas</th><th>Falhas</th><th>Taxa</th><th>Giros</th></tr>{rows}</table>
<h2>Alertas em aberto</h2><ul>{alerts}</ul></html>"""


def generate(store, cfg, client, days=1, now=None, fmt="html", use_llm=True):
    stats = build_stats(store, cfg, client, days, now)
    lines = local_analysis(stats)
    ai = llm_analysis(cfg, stats) if use_llm else None
    return (render_html if fmt == "html" else render_markdown)(stats, lines, ai)
