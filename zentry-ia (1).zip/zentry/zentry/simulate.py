"""Gera um cliente de demonstração com 20 dias de histórico + uma "noite problemática"
que dispara cada detector. Serve para testar o Zentry sem ter equipamento à mão."""

import copy
import random
from datetime import datetime, timedelta
from .timeutil import get_tz

DEMO_CLIENT = "demo"
TZ = get_tz("America/Sao_Paulo")
DEMO_NOW = int(datetime(2026, 10, 21, 22, 30, tzinfo=TZ).timestamp())  # quarta-feira, 22:30

DEMO_DEVICES = {
    "101": {"name": "Catraca Social - Entrada", "ip": "192.0.2.101", "direction": "in", "zone": "predio", "type": "turnstile"},
    "102": {"name": "Catraca Social - Saída", "ip": "192.0.2.102", "direction": "out", "zone": "predio", "type": "turnstile"},
    "201": {"name": "iDFace Garagem", "ip": "192.0.2.201", "direction": "in", "zone": "garagem", "type": "face"},
    "301": {"name": "iDFace Serviço", "ip": "192.0.2.50", "zone": "servico", "type": "face"},
}


def demo_config(cfg):
    c = copy.deepcopy(cfg)
    c["clients"] = {DEMO_CLIENT: {"name": "Condomínio Demo", "devices": copy.deepcopy(DEMO_DEVICES), "detectors": {}}}
    return c


def build_demo(store, cfg, now=None, seed=7, problems=True):
    """Popula o banco. `now=None` usa um instante fixo (testes); passe time.time() para a demo ao vivo.
    Com problems=False gera só uma operação saudável (usada para testar falsos positivos)."""
    shift = int((now if now is not None else DEMO_NOW) - DEMO_NOW)
    rnd = random.Random(seed)
    N = DEMO_NOW  # referência virtual; tudo é deslocado por `shift` ao gravar

    def at(k, h, m=0, s=0):
        d = (datetime.fromtimestamp(N, TZ) - timedelta(days=k)).date()
        return int(datetime(d.year, d.month, d.day, h, 0, 0, tzinfo=TZ).timestamp()) + m * 60 + s

    def ev(dev, ts, kind, uid=None, name=None, live=False, recv=None, portal=None):
        store.add_event(DEMO_CLIENT, dev, ts + shift, kind, user_id=uid, user_name=name, portal_id=portal,
                        live=live, now=(recv if recv is not None else ts + 1) + shift, commit=False)

    def grant_turn(dev, ts, uid, name, live=False):
        ev(dev, ts, "grant", uid, name, live)
        ev(dev, ts + 3, "turn", live=live)

    users = {str(1000 + i): f"Morador {i}" for i in range(40)}

    # ---------------- histórico normal (20 dias)
    for k in range(0, 21):
        weekday = (datetime.fromtimestamp(N, TZ) - timedelta(days=k)).weekday() < 5
        for i, (uid, name) in enumerate(users.items()):
            if not weekday and i >= 10:
                continue
            grant_turn("101", at(k, rnd.choice([7, 8, 8, 9]), rnd.randrange(60), rnd.randrange(60)), uid, name)
            grant_turn("102", at(k, rnd.choice([17, 18, 18, 19]), rnd.randrange(60), rnd.randrange(60)), uid, name)
            if i % 2 == 0:
                ev("201", at(k, 8, rnd.randrange(60)), "grant", uid, name)
                ev("201", at(k, 18, rnd.randrange(60)), "grant", uid, name)
        if k >= 1:
            for j in range(8):  # equipe de limpeza noturna no portão de serviço
                ev("301", at(k, 21, 35 + j * 6, rnd.randrange(60)), "grant", str(3001 + j % 3), f"Limpeza {j % 3 + 1}")

    if not problems:
        for j in range(8):  # a equipe de limpeza também trabalhou hoje
            ev("301", at(0, 21, 35 + j * 6, rnd.randrange(60)), "grant", str(3001 + j % 3), f"Limpeza {j % 3 + 1}")
        for dev, d in DEMO_DEVICES.items():
            store.heartbeat(DEMO_CLIENT, dev, N - 30 + shift, name=d["name"], commit=False)
        store.commit()
        return N + shift

    # degradação da leitora da garagem: semana anterior ~5% de falhas, última semana ~26%
    for k in range(8, 15):
        for j in range(2):
            ev("201", at(k, rnd.randrange(10, 15), rnd.randrange(60)), "deny", str(5000 + rnd.randrange(10)))
    for k in range(1, 8):
        for j in range(10):
            ev("201", at(k, rnd.randrange(10, 15), rnd.randrange(60)), "deny", str(5000 + rnd.randrange(10)))

    # credenciais ativas sem uso há 100+ dias
    for i in range(5):
        ev("101", N - (100 + i * 15) * 86400, "grant", str(2000 + i), f"Ex-morador {i + 1}")

    # excesso de negações no portão de serviço (14h de hoje)
    for j in range(12):
        ev("301", at(0, 14, j * 2), "grant", str(3001 + j % 3), f"Limpeza {j % 3 + 1}")
    for j in range(20):
        ev("301", at(0, 14, 10 + j), "deny", str(4000 + j))

    # ---------------- a "noite problemática": tudo dentro dos últimos 15 minutos
    def mins(m, s=0):
        return N - m * 60 + s

    # relógio atrasado + equipamento offline (102)
    for i in range(6):
        t = N - 2400 + i * 60
        ev("102", t, "grant", str(1001 + i), users[str(1001 + i)], live=True, recv=t + 420)
    # força bruta (1005, 7 negações) e faces desconhecidas na garagem
    for i in range(7):
        t = mins(8 - i)
        ev("201", t, "deny", "1005", users["1005"], live=True)
    for i in range(18):
        ev("201", mins(9) + i * 28, "not_identified", live=True)
    # viagem impossível (1010) e horário atípico (1020)
    grant_turn("101", mins(5), "1010", users["1010"], live=True)
    ev("201", mins(4), "grant", "1010", users["1010"], live=True)
    grant_turn("101", mins(3), "1020", users["1020"], live=True)
    # anti-passback: duas entradas seguidas (1030)
    grant_turn("101", mins(12), "1030", users["1030"], live=True)
    grant_turn("101", mins(6), "1030", users["1030"], live=True)
    # catraca: carona, 3 giros sem liberação e 5 liberações sem giro
    ev("101", mins(10), "grant", "1031", users["1031"], live=True)
    ev("101", mins(10, 3), "turn", live=True)
    ev("101", mins(10, 6), "turn", live=True)
    for m in (9, 8, 7):
        ev("101", mins(m), "turn", live=True)
    for j in range(5):
        ev("101", mins(14) + j * 20, "grant", str(1032 + j), users[str(1032 + j)], live=True)
    # porta da garagem aberta há 15 minutos
    ev("201", mins(15), "door_open", live=True, portal="1")

    # presença dos equipamentos (o 102 caiu há 25 min)
    for dev in ("101", "201", "301"):
        store.heartbeat(DEMO_CLIENT, dev, N - 30 + shift, name=DEMO_DEVICES[dev]["name"], commit=False)
    store.heartbeat(DEMO_CLIENT, "102", N - 25 * 60 + shift, name=DEMO_DEVICES["102"]["name"], commit=False)
    for dev, d in DEMO_DEVICES.items():
        store.set_device_name(DEMO_CLIENT, dev, d["name"], commit=False)
    store.commit()
    return N + shift
