"""Objeto central que junta configuração, banco, detectores e motor."""

from .db import Store
from .paths import config_file, home_path
from .detectors import discover
from .engine import Engine, Notifier


class App:
    def __init__(self, cfg, store=None, config_path=None):
        self.cfg = cfg
        self.config_path = str(config_path or config_file(cfg.get("_home")))
        if store is None:
            from .maintenance import apply_pending_restore
            apply_pending_restore(cfg)  # restauração agendada pelo painel acontece antes de abrir o banco
        self.restart_hook = None
        from .updater import Updater
        self.updater = Updater(self)
        self.store = store or Store(home_path(cfg, cfg["db_path"]))
        self.notifier = Notifier(cfg, self.store)
        self.detectors = discover(home_path(cfg, cfg["plugins_dir"]) if cfg.get("plugins_dir") else None)
        self.engine = Engine(cfg, self.store, self.notifier, self.detectors)
