import os, sys, json, tempfile, threading, time, unittest, urllib.request, urllib.error
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from zentry.api import Api, Request
from zentry.app import App
from zentry.config import init_config, load_config
from zentry.simulate import build_demo, demo_config
from zentry.server import make_handler
from http.server import ThreadingHTTPServer


def make():
    d = tempfile.mkdtemp()
    path = os.path.join(d, "config.json")
    init_config(path)
    cfg = demo_config(load_config(path))
    cfg["llm"]["enabled"] = False
    app = App(cfg, config_path=path)
    now = build_demo(app.store, cfg, now=time.time())
    app.engine.run_once(now=now, notify=False)
    return app, Api(app)


def call(api, method, path, body=None, cookie=None, csrf=True, ip="9.9.9.9", qs=None, bearer=None):
    h = {}
    if cookie:
        h["Cookie"] = "zentry_session=" + cookie
    if csrf:
        h["X-Requested-With"] = "zentry"
    if bearer:
        h["Authorization"] = "Bearer " + bearer
    return api.handle(Request(method, path, qs or {}, body or {}, h, ip))


def login(api, user="admin"):
    r = call(api, "POST", "/api/login", {"username": user, "password": "senha-forte-1"})
    assert r.status == 200, r.body
    return r.headers["Set-Cookie"].split(";")[0].split("=", 1)[1]


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.app, self.api = make()

    def test_setup_once_then_locked(self):
        s = call(self.api, "GET", "/api/session").body
        self.assertTrue(s["setup_needed"])
        r = call(self.api, "POST", "/api/setup", {"username": "admin", "password": "senha-forte-1",
                                                  "client_name": "Condomínio Teste", "timezone": "America/Sao_Paulo"})
        self.assertEqual(r.status, 200)
        self.assertIn("HttpOnly", r.headers["Set-Cookie"])
        self.assertIn("SameSite=Strict", r.headers["Set-Cookie"])
        again = call(self.api, "POST", "/api/setup", {"username": "x2", "password": "senha-forte-1"})
        self.assertEqual(again.status, 403)

    def test_auth_required_and_roles(self):
        self.assertEqual(call(self.api, "GET", "/api/overview").status, 401)
        self.api.auth.create_account("admin", "senha-forte-1", "admin")
        self.api.auth.create_account("viewer", "senha-forte-1", "viewer")
        self.api.auth.create_account("op", "senha-forte-1", "operator")
        v, o, a = login(self.api, "viewer"), login(self.api, "op"), login(self.api, "admin")
        client = "demo"
        self.assertEqual(call(self.api, "GET", "/api/overview", cookie=v, qs={"client": [client]}).status, 200)
        aid = self.app.store.scalar("SELECT id FROM alerts WHERE status='new' LIMIT 1")
        fb = f"/api/alerts/{aid}/feedback"
        self.assertEqual(call(self.api, "POST", fb, {"status": "resolved"}, cookie=v).status, 403)
        self.assertEqual(call(self.api, "POST", fb, {"status": "resolved"}, cookie=o, csrf=False).status, 403)  # CSRF
        self.assertEqual(call(self.api, "POST", fb, {"status": "resolved"}, cookie=o).status, 200)
        self.assertEqual(call(self.api, "GET", "/api/config", cookie=o).status, 403)
        self.assertEqual(call(self.api, "GET", "/api/config", cookie=a).status, 200)
        self.assertTrue(any(x["action"] == "alert.feedback" for x in self.api.auth.audit_list()))

    def test_api_key_is_operator_not_admin(self):
        key = self.app.cfg["server"]["token"]
        self.assertEqual(call(self.api, "POST", "/api/ingest", {"client": "demo", "events": []}, bearer=key, csrf=False).status, 200)
        self.assertEqual(call(self.api, "GET", "/api/config", bearer=key).status, 403)
        self.assertEqual(call(self.api, "GET", "/api/overview", bearer="errada").status, 401)

    def test_config_never_leaks_secrets(self):
        self.api.auth.create_account("admin", "senha-forte-1", "admin")
        a = login(self.api)
        self.app.cfg["llm"]["api_key"] = "sk-segredo-xyz"
        r = call(self.api, "GET", "/api/config", cookie=a)
        txt = json.dumps(r.body)
        self.assertNotIn("sk-segredo-xyz", txt)
        self.assertNotIn(self.app.cfg["server"]["token"], txt)
        self.assertNotIn(self.app.cfg["anonymize"]["salt"], txt)
        bad = call(self.api, "PUT", "/api/config", {"db_path": "x"}, cookie=a)
        self.assertEqual(bad.status, 400)
        ok = call(self.api, "PUT", "/api/config", {"engine": {"interval_seconds": 60}}, cookie=a)
        self.assertEqual(ok.body["changed"], ["engine.interval_seconds"])

    def test_data_endpoints_shape(self):
        self.api.auth.create_account("admin", "senha-forte-1", "admin")
        a = login(self.api)
        q = {"client": ["demo"]}
        ov = call(self.api, "GET", "/api/overview", cookie=a, qs=q).body
        self.assertGreater(ov["open_total"], 0)
        self.assertTrue(0 <= ov["health"] <= 100)
        al = call(self.api, "GET", "/api/alerts", cookie=a, qs=q).body["alerts"]
        self.assertTrue(al)
        d = call(self.api, "GET", f"/api/alerts/{al[0]['id']}", cookie=a).body
        self.assertIn("events", d)
        self.assertEqual(len(call(self.api, "GET", "/api/timeline", cookie=a, qs=q).body["points"]), 25)
        hm = call(self.api, "GET", "/api/heatmap", cookie=a, qs=q).body["grid"]
        self.assertEqual((len(hm), len(hm[0])), (7, 24))
        self.assertTrue(call(self.api, "GET", "/api/devices", cookie=a, qs=q).body["devices"])
        self.assertTrue(call(self.api, "GET", "/api/people", cookie=a, qs=q).body["people"])
        self.assertTrue(call(self.api, "GET", "/api/patterns", cookie=a, qs=q).body["patterns"])
        dets = call(self.api, "GET", "/api/detectors", cookie=a, qs=q).body["detectors"]
        self.assertEqual(len(dets), 12)
        self.assertTrue(all(x["params"] for x in dets))
        self.assertIn("version", call(self.api, "GET", "/api/diagnostics", cookie=a).body)

    def test_accounts_admin_flow_and_backup(self):
        self.api.auth.create_account("admin", "senha-forte-1", "admin")
        a = login(self.api)
        r = call(self.api, "POST", "/api/accounts", {"username": "maria", "password": "outra-senha-1", "role": "operator"}, cookie=a)
        self.assertEqual(r.status, 200)
        self.assertEqual(call(self.api, "DELETE", "/api/accounts/admin", cookie=a).status, 400)
        b = call(self.api, "POST", "/api/backups", cookie=a).body["name"]
        dl = call(self.api, "GET", "/api/backups/" + b, cookie=a)
        self.assertEqual(dl.status, 200)
        self.assertTrue(dl.body.startswith(b"SQLite format 3"))
        self.assertEqual(call(self.api, "GET", "/api/backups/..%2Fconfig.json", cookie=a).status, 404)

    def test_logout_invalidates(self):
        self.api.auth.create_account("admin", "senha-forte-1", "admin")
        a = login(self.api)
        call(self.api, "POST", "/api/logout", cookie=a)
        self.assertEqual(call(self.api, "GET", "/api/overview", cookie=a).status, 401)


class HttpTests(unittest.TestCase):
    def test_real_http_static_and_headers(self):
        app, api = make()
        srv = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(app, api))
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        base = f"http://127.0.0.1:{srv.server_address[1]}"
        try:
            r = urllib.request.urlopen(base + "/")
            self.assertEqual(r.status, 200)
            self.assertIn("default-src 'self'", r.headers["Content-Security-Policy"])
            self.assertEqual(r.headers["X-Content-Type-Options"], "nosniff")
            self.assertEqual(json.load(urllib.request.urlopen(base + "/health"))["ok"], True)
            for bad in ("/..%2f..%2fconfig.json", "/%2e%2e/config.json", "/nao-existe.js"):
                with self.assertRaises(urllib.error.HTTPError) as cm:
                    urllib.request.urlopen(base + bad)
                self.assertIn(cm.exception.code, (404,))
            with self.assertRaises(urllib.error.HTTPError) as cm:
                urllib.request.urlopen(base + "/api/overview")
            self.assertEqual(cm.exception.code, 401)
            req = urllib.request.Request(base + "/api/notifications/door", json.dumps({"id": 1, "open": True}).encode(), method="POST")
            self.assertEqual(urllib.request.urlopen(req).status, 200)
        finally:
            srv.shutdown()


if __name__ == "__main__":
    unittest.main()


class DiscoveryTest(unittest.TestCase):
    def test_scan_finds_local_listener(self):
        import socket
        from zentry import discovery
        srv = socket.socket(); srv.bind(("127.0.0.1", 0)); srv.listen(5)
        port = srv.getsockname()[1]
        try:
            self.assertTrue(discovery._open("127.0.0.1", port, 0.5))
            self.assertFalse(discovery._open("127.0.0.1", 1, 0.2))
            self.assertIsInstance(discovery.local_subnets(), list)
        finally:
            srv.close()


class ClockTest(unittest.TestCase):
    def test_wall_clock_to_utc(self):
        from zentry.timeutil import wall_epoch_to_utc
        # 12:00 "local gravado como UTC" em São Paulo (UTC-3) = 15:00 UTC reais
        wall = 1_800_000_000 - 1_800_000_000 % 86400 + 12 * 3600
        self.assertEqual(wall_epoch_to_utc({"timezone": "America/Sao_Paulo"}, wall) - wall, 3 * 3600)


class MethodTest(unittest.TestCase):
    def test_access_method(self):
        from zentry.ingest import access_method
        self.assertEqual(access_method({"card_value": 99}, "face"), "Cartão")
        self.assertEqual(access_method({"user_id": 3}, "face"), "Facial")
        self.assertEqual(access_method({"pin": "1"}), "Senha")
        self.assertIsNone(access_method({}))


class EventDeleteTest(unittest.TestCase):
    def test_delete_and_clear_events(self):
        app, api = make()
        api.auth.create_account("adm", "senha-forte-1", "admin")
        ck = login(api, "adm")
        cid = list(app.cfg["clients"])[0]
        r = call(api, "GET", "/api/events", cookie=ck, qs={"client": [cid], "limit": ["5"]})
        rows = r.body["events"]
        self.assertTrue(rows and "method" in rows[0] and "sector" in rows[0])
        eid = rows[0]["id"]
        self.assertEqual(call(api, "DELETE", f"/api/events/{eid}", cookie=ck, qs={"client": [cid]}).status, 200)
        self.assertEqual(call(api, "DELETE", f"/api/events/{eid}", cookie=ck, qs={"client": [cid]}).status, 404)
        self.assertEqual(call(api, "POST", "/api/events/clear", {}, cookie=ck, qs={"client": [cid]}).status, 400)
        ok = call(api, "POST", "/api/events/clear", {"confirm": "APAGAR"}, cookie=ck, qs={"client": [cid]})
        self.assertTrue(ok.body["deleted"] > 0)


class CameraSipTest(unittest.TestCase):
    def test_snapshot_rtsp_sip_against_fake_device(self):
        from http.server import BaseHTTPRequestHandler
        calls = []
        PNG = b"\x89PNG\r\n\x1a\nfake"

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def do_POST(self):
                n = int(self.headers.get("Content-Length") or 0)
                body = json.loads(self.rfile.read(n) or b"{}")
                path = self.path.split("?")[0]
                calls.append((path, body))
                if path == "/login.fcgi":
                    out = json.dumps({"session": "S1"}).encode()
                elif path == "/save_screenshot.fcgi":
                    out = PNG
                elif path == "/get_configuration.fcgi":
                    out = json.dumps({"onvif": {"rtsp_enabled": "1", "rtsp_port": "554"},
                                      "pjsip": {"enabled": "1", "server_ip": "10.0.0.5", "login": "100"}}).encode()
                else:
                    out = b"{}"
                self.send_response(200); self.send_header("Content-Length", str(len(out))); self.end_headers(); self.wfile.write(out)
        srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        try:
            app, api = make()
            cid = list(app.cfg["clients"])[0]
            app.cfg["clients"][cid]["devices"]["cam1"] = {"name": "Facial", "ip": "127.0.0.1", "port": srv.server_address[1],
                                                           "brand": "controlid", "user": "admin", "password": "x"}
            api.auth.create_account("adm", "senha-forte-1", "admin")
            ck = login(api, "adm")
            qs = {"client": [cid]}
            r = call(api, "GET", "/api/devices/cam1/snapshot", cookie=ck, qs=qs)
            self.assertEqual((r.status, r.body, r.ctype), (200, PNG, "image/png"))
            self.assertIn(("/save_screenshot.fcgi", {"frame_type": "camera", "camera": "rgb"}), calls)
            info = call(api, "GET", "/api/devices/cam1/camera", cookie=ck, qs=qs).body
            self.assertTrue(info["enabled"]); self.assertEqual(info["url"], "rtsp://127.0.0.1:554/main_stream")
            sip = call(api, "GET", "/api/devices/cam1/sip", cookie=ck, qs=qs).body["sip"]
            self.assertEqual(sip["password"], "********")
            self.assertEqual(call(api, "POST", "/api/devices/cam1/sip", {"server_ip": "10.0.0.9", "password": "********"}, cookie=ck, qs=qs).status, 200)
            self.assertIn(("/set_configuration.fcgi", {"pjsip": {"server_ip": "10.0.0.9"}}), calls)
            self.assertEqual(call(api, "POST", "/api/devices/cam1/sip", {"password": "x" * 17}, cookie=ck, qs=qs).status, 502)
            self.assertEqual(call(api, "POST", "/api/devices/cam1/sip/call", {"target": "200"}, cookie=ck, qs=qs).status, 200)
            self.assertIn(("/make_sip_call.fcgi", {"target": "200"}), calls)
            self.assertEqual(call(api, "GET", "/api/devices/nope/snapshot", cookie=ck, qs=qs).status, 404)
        finally:
            srv.shutdown()
