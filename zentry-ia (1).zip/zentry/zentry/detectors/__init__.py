"""Descoberta de detectores (embutidos + plugins do usuário)."""

import importlib.util
import os

from .base import Alert, Ctx, Detector  # noqa: F401
from . import equipment, security, turnstile  # noqa: F401  (registram as classes)


def _all_subclasses(cls):
    for sub in cls.__subclasses__():
        yield sub
        yield from _all_subclasses(sub)


def load_plugins(plugins_dir):
    """Importa todo .py da pasta de plugins; cada subclasse de Detector vira um detector."""
    if not plugins_dir or not os.path.isdir(plugins_dir):
        return
    for fn in sorted(os.listdir(plugins_dir)):
        if not fn.endswith(".py") or fn.startswith("_"):
            continue
        path = os.path.join(plugins_dir, fn)
        spec = importlib.util.spec_from_file_location(f"zentry_plugin_{fn[:-3]}", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)


def discover(plugins_dir=None):
    load_plugins(plugins_dir)
    found = {}
    for cls in _all_subclasses(Detector):
        if cls.name:
            found[cls.name] = cls()
    return found
