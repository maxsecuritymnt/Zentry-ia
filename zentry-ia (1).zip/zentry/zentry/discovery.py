"""Procura equipamentos de controle de acesso/câmeras na rede local (varredura TCP simples, sem bibliotecas externas)."""

import ipaddress
import socket
import urllib.request
from concurrent.futures import ThreadPoolExecutor

PORTS = (80, 443, 8000, 554, 37777, 8080)
HINTS = (  # (trecho em minúsculas no cabeçalho/corpo, marca, rótulo)
    ("control id", "controlid", "Control iD"), ("controlid", "controlid", "Control iD"), ("idface", "controlid", "Control iD iDFace"),
    ("idflex", "controlid", "Control iD iDFlex"), ("idblock", "controlid", "Control iD iDBlock"), ("idaccess", "controlid", "Control iD iDAccess"),
    ("hikvision", "hikvision", "Hikvision"), ("dnvrs-webs", "hikvision", "Hikvision"), ("app-webs", "hikvision", "Hikvision"),
    ("intelbras", "intelbras", "Intelbras"), ("dahua", "dahua", "Dahua"), ("axis", "axis", "Axis"), ("zkteco", "zkteco", "ZKTeco"),
)


def local_subnets():
    """Faixas /24 das placas de rede deste PC (inclui o Wi-Fi)."""
    ips = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    nets = []
    for ip in sorted(ips):
        if ip.startswith(("127.", "169.254.")):
            continue
        n = str(ipaddress.ip_network(ip + "/24", strict=False))
        if n not in nets:
            nets.append(n)
    return nets


def _open(ip, port, timeout):
    try:
        with socket.create_connection((ip, port), timeout=timeout):
            return True
    except OSError:
        return False


def _identify(ip, ports):
    text = ""
    for port in ports:
        if port in (80, 8000, 8080):
            try:
                req = urllib.request.Request(f"http://{ip}:{port}/", headers={"User-Agent": "Zentry"})
                with urllib.request.urlopen(req, timeout=2) as r:
                    text += (str(r.headers) + r.read(4000).decode("utf-8", "replace")).lower()
            except Exception as e:  # 401 etc. também traz cabeçalhos úteis
                hdrs = getattr(e, "headers", None)
                if hdrs:
                    text += str(hdrs).lower()
            if text:
                break
    for frag, brand, label in HINTS:
        if frag in text:
            return brand, label
    if 37777 in ports:
        return "dahua", "Dahua/Intelbras (porta 37777)"
    if 554 in ports and not text:
        return "", "Câmera/gravador (RTSP 554)"
    return "", ""


def scan(subnets=None, timeout=0.4, workers=128):
    """Retorna lista de {ip, ports, brand, label, known} dos equipamentos achados."""
    subnets = subnets or local_subnets()
    hosts = [str(h) for n in subnets for h in ipaddress.ip_network(n).hosts()]
    jobs = [(ip, p) for ip in hosts for p in PORTS]
    found = {}
    with ThreadPoolExecutor(max_workers=workers) as ex:
        for (ip, p), ok in zip(jobs, ex.map(lambda j: _open(j[0], j[1], timeout), jobs)):
            if ok:
                found.setdefault(ip, []).append(p)
    out = []
    with ThreadPoolExecutor(max_workers=16) as ex:
        for ip, brand_label in zip(found, ex.map(lambda ip: _identify(ip, found[ip]), found)):
            out.append({"ip": ip, "ports": found[ip], "brand": brand_label[0], "label": brand_label[1]})
    out.sort(key=lambda d: (not d["label"], tuple(int(x) for x in d["ip"].split("."))))
    return {"subnets": subnets, "devices": out}
