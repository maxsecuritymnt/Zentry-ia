"""Atualizações: consulta as versões publicadas (GitHub Releases), avisa no painel e instala.

Segurança:
- só baixa por HTTPS de github.com / githubusercontent.com do repositório configurado;
- só instala se houver a soma SHA-256 oficial da versão (campo `digest` do GitHub ou arquivo .sha256 da release) e ela conferir;
- antes de instalar, faz um backup do banco; os dados ficam fora da pasta do programa e são preservados.
"""

import hashlib
import json
import logging
import os
import re
import subprocess
import sys
import threading
import time
import urllib.request
from urllib.parse import urlparse

from . import __version__

log = logging.getLogger("zentry")
API = "https://api.github.com/repos/{repo}/releases/latest"
ALLOWED_HOSTS = ("github.com", "api.github.com", "objects.githubusercontent.com", "github-releases.githubusercontent.com",
                 "release-assets.githubusercontent.com")
REPO_RE = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")


def parse_version(v):
    nums = re.findall(r"\d+", str(v).split("-")[0])
    return tuple(int(n) for n in nums[:4]) or (0,)


def is_newer(latest, current=__version__):
    a, b = parse_version(latest), parse_version(current)
    n = max(len(a), len(b))
    return a + (0,) * (n - len(a)) > b + (0,) * (n - len(b))


def _get_json(url, timeout=15):
    req = urllib.request.Request(url, headers={"User-Agent": f"ZentryIA/{__version__}", "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def frozen():
    return bool(getattr(sys, "frozen", False))


def _pick_asset(assets, source=None):
    """Instalador do Windows (ZentryIA-Setup-*.exe) ou, em instalação por pasta, o zip (zentry-ia-*.zip) + soma SHA-256."""
    source = (not frozen()) if source is None else source
    rx = r"(?i)^zentry-?ia[-_].*\.zip$" if source else r"(?i)^ZentryIA-Setup-.*\.exe$"
    exe = next((a for a in assets if re.match(rx, a.get("name", ""))), None)
    if not exe:
        return None, None
    sha = None
    d = exe.get("digest") or ""
    if d.startswith("sha256:"):
        sha = d.split(":", 1)[1].lower()
    return exe, sha


def _sha_from_sidecar(assets, exe, fetch_text):
    for a in assets:
        n = a.get("name", "").lower()
        if n in (exe["name"].lower() + ".sha256", "sha256sums.txt", "sha256sums"):
            text = fetch_text(a["browser_download_url"])
            m = re.search(r"([a-fA-F0-9]{64})\s+\*?" + re.escape(exe["name"]), text) or re.match(r"\s*([a-fA-F0-9]{64})", text)
            if m:
                return m.group(1).lower()
    return None


class Updater:
    def __init__(self, app, fetch_json=None, fetch_text=None, opener=None, launcher=None):
        self.app = app
        self.cfg = app.cfg
        self._fetch_json = fetch_json or _get_json
        self._fetch_text = fetch_text or self._default_text
        self._open = opener or self._default_open
        self._launch = launcher or self._default_launch
        self.state = {"phase": "idle", "progress": 0, "error": None}
        self._lock = threading.Lock()

    # ------------------------------------------------------------ consulta
    def settings(self):
        return self.cfg.get("update", {})

    def status(self):
        u = self.settings()
        latest = self.app.store.meta_get("update_latest")
        info = json.loads(latest) if latest else None
        available = bool(info and is_newer(info["version"]))
        return {"enabled": bool(u.get("enabled", True)), "repo": u.get("repo", ""), "current": __version__,
                "available": available, "latest": info if available else (info and {"version": info["version"]}),
                "checked_at": int(self.app.store.meta_get("update_checked_at", 0) or 0),
                "can_install": bool(available and info and info.get("asset_url") and info.get("sha256")
                                    and (sys.platform == "win32" or not frozen())),
                "platform_note": None if (sys.platform == "win32" or not frozen()) else
                "Instalação automática do .exe só no Windows. Baixe a nova versão pela página da release.",
                "state": dict(self.state), "error": self.app.store.meta_get("update_error") or None}

    def check(self, force=False, now=None):
        u = self.settings()
        now = int(now if now is not None else time.time())
        if not u.get("enabled", True):
            return self.status()
        repo = u.get("repo", "")
        if not REPO_RE.match(repo or ""):
            self.app.store.meta_set("update_error", "Informe o repositório de atualizações (dono/nome) em Configurações → Atualizações.")
            return self.status()
        last = int(self.app.store.meta_get("update_checked_at", 0) or 0)
        if not force and now - last < float(u.get("check_hours", 12)) * 3600:
            return self.status()
        try:
            rel = self._fetch_json(API.format(repo=repo))
            ver = str(rel.get("tag_name", "")).lstrip("vV")
            assets = rel.get("assets") or []
            exe, sha = _pick_asset(assets)
            if exe and not sha:
                try:
                    sha = _sha_from_sidecar(assets, exe, self._fetch_text)
                except Exception:
                    sha = None
            info = {"version": ver, "name": rel.get("name") or ver, "notes": (rel.get("body") or "")[:4000],
                    "url": rel.get("html_url"), "published_at": rel.get("published_at"),
                    "asset_name": exe and exe["name"], "asset_url": exe and exe["browser_download_url"],
                    "asset_size": exe and exe.get("size"), "sha256": sha}
            self.app.store.meta_set("update_latest", json.dumps(info, ensure_ascii=False))
            self.app.store.meta_set("update_error", "")
        except Exception as e:
            log.info("Não foi possível verificar atualizações: %s", e)
            self.app.store.meta_set("update_error", "Não foi possível verificar agora (sem internet ou repositório inválido).")
        self.app.store.meta_set("update_checked_at", now)
        return self.status()

    # ------------------------------------------------------------ instalação
    def _default_text(self, url):
        self._guard(url)
        req = urllib.request.Request(url, headers={"User-Agent": f"ZentryIA/{__version__}"})
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.read().decode("utf-8", errors="replace")

    def _default_open(self, url):
        self._guard(url)
        req = urllib.request.Request(url, headers={"User-Agent": f"ZentryIA/{__version__}"})
        return urllib.request.urlopen(req, timeout=30)

    def _guard(self, url):
        p = urlparse(url)
        host = p.hostname or ""
        if p.scheme != "https" or not any(host == h or host.endswith("." + h) for h in ALLOWED_HOSTS):
            raise ValueError("Endereço de download não permitido.")

    def _default_launch(self, path):
        flags = 0x00000008 | 0x00000200 if sys.platform == "win32" else 0  # DETACHED_PROCESS | NEW_PROCESS_GROUP
        subprocess.Popen([path, "/SILENT", "/SUPPRESSMSGBOXES", "/NORESTART", "/CLOSEAPPLICATIONS"],
                         creationflags=flags, close_fds=True)

    def start_install(self):
        """Baixa em segundo plano; quando termina e confere, instala e encerra o Zentry."""
        st = self.status()
        if not st["available"]:
            raise ValueError("Você já está na versão mais recente.")
        if not st["can_install"]:
            raise ValueError(st["platform_note"] or "Esta versão não traz instalador verificável (SHA-256). Baixe pela página da versão.")
        with self._lock:
            if self.state["phase"] in ("downloading", "verifying", "installing"):
                raise ValueError("Atualização já em andamento.")
            self.state = {"phase": "downloading", "progress": 0, "error": None}
        threading.Thread(target=self._run_install, args=(st["latest"],), daemon=True, name="updater").start()

    def _run_install(self, info):
        try:
            from .maintenance import make_backup
            from .paths import home_path
            d = home_path(self.cfg, "updates")
            os.makedirs(d, exist_ok=True)
            dest = os.path.join(d, os.path.basename(info["asset_name"]))
            h = hashlib.sha256()
            total = int(info.get("asset_size") or 0)
            got = 0
            with self._open(info["asset_url"]) as r, open(dest, "wb") as f:
                total = total or int(getattr(r, "length", 0) or 0)
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
                    h.update(chunk)
                    got += len(chunk)
                    self.state["progress"] = int(got * 100 / total) if total else 0
            self.state.update(phase="verifying", progress=100)
            if h.hexdigest().lower() != info["sha256"].lower():
                os.unlink(dest)
                raise ValueError("O arquivo baixado não confere com a soma de verificação oficial. Atualização cancelada.")
            make_backup(self.app)
            self.state["phase"] = "installing"
            log.warning("Instalando a versão %s…", info["version"])
            if dest.lower().endswith(".zip"):
                apply_zip(dest, program_dir())
                self.state = {"phase": "restarting", "progress": 100, "error": None}
                time.sleep(1)
                if self.app.restart_hook is not None:
                    self.app.restart_hook()
                return
            self._launch(dest)
            time.sleep(2)
            if self.app.restart_hook is not None:
                os._exit(0)  # o instalador reabre o Zentry ao terminar
        except Exception as e:
            log.exception("Falha na atualização")
            self.state = {"phase": "error", "progress": 0, "error": str(e)}


def program_dir():
    """Pasta que contém o pacote `zentry/` (raiz da instalação por pasta)."""
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def apply_zip(zip_path, dest_dir):
    """Extrai a nova versão por cima da pasta do programa. Nunca toca em dados (config.json, banco, logs, backups)."""
    import zipfile
    keep = {"config.json", "plugins"}
    dest_real = os.path.realpath(dest_dir)
    with zipfile.ZipFile(zip_path) as z:
        names = [n for n in z.namelist() if not n.endswith("/")]
        top = {n.split("/", 1)[0] for n in names if "/" in n}
        strip = (next(iter(top)) + "/") if len(top) == 1 and not any("/" not in n for n in names) else ""
        if not any(n[len(strip):].startswith("zentry/__init__.py") for n in names):
            raise ValueError("O pacote baixado não parece ser do Zentry. Atualização cancelada.")
        for n in names:
            rel = n[len(strip):]
            if not rel or rel.split("/")[0] in keep or ".." in rel.split("/") or rel.startswith("/") or ":" in rel.split("/")[0]:
                continue
            out = os.path.realpath(os.path.join(dest_dir, rel))
            if not out.startswith(dest_real + os.sep):
                raise ValueError("Pacote com caminho inseguro. Atualização cancelada.")
            os.makedirs(os.path.dirname(out), exist_ok=True)
            with z.open(n) as src, open(out + ".new", "wb") as dst:
                dst.write(src.read())
            os.replace(out + ".new", out)


def loop(app, updater, stop):
    """Verifica a cada poucas horas (sem internet, apenas tenta de novo depois)."""
    while not stop.is_set():
        try:
            updater.check()
        except Exception:
            log.exception("Falha ao verificar atualizações")
        stop.wait(1800)
