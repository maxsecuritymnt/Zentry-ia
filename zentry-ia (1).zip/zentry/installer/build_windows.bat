@echo off
rem Gera o instalador do Zentry IA (executar no Windows, na raiz do projeto).
rem Requisitos: Python 3.9+, Inno Setup 6 (iscc no PATH)
python -m pip install --upgrade pyinstaller tzdata || exit /b 1
cd packaging
python -m PyInstaller --noconfirm --distpath ..\dist --workpath ..\build zentry.spec || exit /b 1
cd ..
iscc /DAppVersion=0.5.0 installer\zentry.iss || exit /b 1
echo Pronto: installer\Output\ZentryIA-Setup-0.5.0.exe
