# Conectores (marcas)

Cada equipamento tem uma **marca** (`brand`); se não tiver, vale o `connector` do cliente (padrão `controlid`).
Os eventos chegam de duas formas: **push** (o equipamento envia) ou **consulta** (`"poll": true` + `ip`, `user`, `password`).

| Marca | Como chega | Base da implementação | Situação |
|---|---|---|---|
| Control iD | Monitor (push) e `load_objects.fcgi` | documentação pública | não validada em equipamento real |
| Hikvision | push `/api/push/hikvision` e `POST /ISAPI/AccessControl/AcsEvent?format=json` (Digest) | endpoint confirmado em fóruns técnicos; códigos major/minor mais comuns (1, 38, 75 = liberado; 9, 39, 76 = negado) | não validada; ajuste `hikvision_event_map` |
| Intelbras / Dahua | consulta `recordFinder.cgi?action=find&name=AccessControlCardRec` (Digest) | API CGI da Dahua; resposta `records[i].Campo=valor` | não validada; use `poll_params` se o modelo exigir filtros |
| Axis | push (regra de ação → notificação HTTP) para `/api/push/generic` ou `/api/push/axis` | estrutura de eventos do serviço de log da Axis (topic0 = AccessControl, topic1 = AccessGranted/Denied) | não validada |
| ZKTeco | push ADMS em `/iclock/cdata` (`table=rtlog` e `ATTLOG`) | protocolo PUSH conhecido; códigos de evento por convenção (0 liberado, 100+ alarme) | não validada |
| Genérico | `/api/push/generic` (JSON ou parâmetros na URL) | formato próprio | testado |

Para validar uma marca: cadastre o equipamento, faça uma passagem e veja **Diagnóstico → Últimos envios dos equipamentos**. “Eventos = 0” significa que o formato ou o código não foi reconhecido; envie a amostra para ajustarmos o conector.

## Criar um conector
```python
from zentry.connectors.base import Connector

class MinhaMarca(Connector):
    name = "minhamarca"; label = "Minha Marca"; push_path = "/api/push/minhamarca"
    def poll_device(self, cfg, store, client, device_id, d): ...   # consulta (opcional)
    def handle_push(self, cfg, store, path, query, body, ip, now=None): ...  # push (opcional)
```
Registre em `zentry/connectors/__init__.py` (`_CLASSES`) e, se for push, adicione a rota em `Api._push_route`. Use `store.add_event(...)`: o Zentry cuida do resto.
