"""Configuração: padrões, leitura/gravação do config.json e resolução de equipamentos."""

import copy
import json
import os
import secrets
from pathlib import Path

SEVERITY_ORDER = {"info": 0, "atencao": 1, "critico": 2}
SEVERITY_LABEL = {"info": "INFO", "atencao": "ATENCAO", "critico": "CRITICO"}

DEFAULTS = {
    "timezone": "America/Sao_Paulo",
    "controlid_clock_utc": False,  # True se o seu equipamento Control iD grava a hora em UTC verdadeiro
    "db_path": "zentry.db",
    "plugins_dir": "plugins",
    "reports_dir": "reports",
    "backups_dir": "backups",
    # Atualizações: o Zentry olha as versões publicadas neste repositório do GitHub ("dono/nome") e avisa no painel.
    "update": {"enabled": True, "repo": "", "check_hours": 12},
    "logs_dir": "logs",
    "maintenance": {
        "backup_enabled": True,     # cópia diária do banco
        "backup_keep": 14,          # quantas cópias manter
        "backup_hour": 3,           # hora local do backup
        "events_retention_days": 400,
        "audit_retention_days": 730,
    },
    "server": {
        "host": "0.0.0.0",
        "port": 8000,
        "session_hours": 12,
        "tls": {"enabled": False, "cert_file": "tls/zentry.crt", "key_file": "tls/zentry.key"},
        "device_port": 8001,   # com HTTPS ligado, os equipamentos continuam enviando em HTTP simples por esta porta (só rotas de envio)
        # Chave para integrações (POST /api/ingest etc.). Pessoas entram com usuário e senha.
        "token": "",
        # Se preenchido, só estes IPs podem enviar eventos como equipamento.
        "allowed_device_ips": [],
        # Grava o corpo bruto de tudo que os equipamentos enviam (para validar formatos).
        "debug_dump": False,
    },
    "engine": {
        "interval_seconds": 30,
        # Alerta com as mesmas características de um já conhecido é ignorado (só conta). Se você marcou o
        # anterior como "resolvido" e o problema volta, o Zentry avisa de novo (reincidência).
        "reopen_resolved": True,
        "episode_gap_minutes": 60,   # sumiu por mais que isso e voltou = novo episódio
        "recurrence_milestones": [5, 10, 25, 50, 100, 250, 500, 1000],  # avisa "isto já aconteceu N vezes"
        "probe_interval_seconds": 60,
        "poll_interval_seconds": 60,
    },
    "notify": {
        "console": True,
        "min_severity": "atencao",
        # Lista de URLs que recebem POST JSON {"text": ..., "severity": ..., ...}
        # (serve para gateway de WhatsApp, n8n, Slack, Teams, etc.)
        "webhooks": [],
        # {"host":..., "port":587, "user":..., "password_env":"SMTP_PASSWORD", "from":..., "to":[...]}
        "smtp": {},
        # Telegram: crie um bot com o @BotFather, mande uma mensagem para ele e use o chat_id (ou de um grupo)
        "telegram": {"enabled": False, "bot_token": "", "chat_id": ""},
        # ntfy (app gratuito de notificação no celular): https://ntfy.sh — escolha um nome de tópico difícil de adivinhar
        "ntfy": {"enabled": False, "server": "https://ntfy.sh", "topic": "", "token": ""},
        # Fala o alerta pelas caixas de som do PC (Windows/macOS/Linux), mesmo com o painel fechado.
        "voice": {"enabled": True, "min_severity": "critico", "rate": 0},
    },
    "anonymize": {"salt": ""},
    # Conversa e análise por IA (Claude). Precisa de internet e de uma chave de API; sem isso o Zentry
    # responde por regras locais. Por padrão o modelo só vê pseudônimos no lugar dos nomes das pessoas.
    "llm": {"enabled": True, "model": "claude-sonnet-5-5", "api_key_env": "ANTHROPIC_API_KEY",
            "api_key": "", "send_real_names": False},
    # Código "event" do access_logs da Control iD -> tipo interno. VALIDAR no equipamento real.
    "hikvision_event_map": {},   # minor -> grant|deny|other (ajuste fino por modelo)
    "event_map": {"3": "not_identified", "4": "deny", "7": "grant"},
    # Código do evento de catraca -> tipo interno (padrão: tudo vira "turn"). VALIDAR.
    "turnstile_event_map": {},
    "detectors": {},
    "clients": {"default": {"name": "Cliente padrão", "devices": {}, "detectors": {}}},
}


def deep_merge(base, over):
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def load_config(path):
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Arquivo de configuração '{path}' não encontrado. Rode: python -m zentry setup"
        )
    with open(path, "r", encoding="utf-8") as f:
        user = json.load(f)
    cfg = deep_merge(DEFAULTS, user)
    cfg["_home"] = str(Path(path).resolve().parent)  # chave interna: nunca é gravada no arquivo
    return cfg


def init_config(path, force=False):
    if os.path.exists(path) and not force:
        raise FileExistsError(f"'{path}' já existe (use --force para sobrescrever).")
    cfg = copy.deepcopy(DEFAULTS)
    cfg["server"]["token"] = secrets.token_urlsafe(24)
    cfg["anonymize"]["salt"] = secrets.token_hex(8)
    cfg["clients"] = {"default": {"name": "Meu primeiro cliente", "devices": {}, "detectors": {}}}
    Path(path).resolve().parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    return cfg


def llm_api_key(cfg):
    lcfg = cfg.get("llm", {})
    return os.environ.get(lcfg.get("api_key_env", "ANTHROPIC_API_KEY"), "") or lcfg.get("api_key", "")


def client_cfg(cfg, client):
    return cfg["clients"].get(client, {})


def client_name(cfg, client):
    return client_cfg(cfg, client).get("name") or client


def detector_cfg(cfg, client, name):
    merged = dict(cfg.get("detectors", {}).get(name, {}))
    merged.update(client_cfg(cfg, client).get("detectors", {}).get(name, {}))
    return merged


def device_cfg(cfg, client, device_id):
    return client_cfg(cfg, client).get("devices", {}).get(str(device_id), {})


def resolve_device(cfg, device_id=None, ip=None):
    """Descobre (cliente, device_id) a partir do id informado pelo equipamento e/ou do IP."""
    for cid, c in cfg["clients"].items():
        devs = c.get("devices", {})
        if device_id is not None and str(device_id) in devs:
            return cid, str(device_id)
    if ip:
        for cid, c in cfg["clients"].items():
            for did, d in c.get("devices", {}).items():
                if d.get("ip") == ip:
                    return cid, did
    return "default", str(device_id if device_id is not None else (ip or "desconhecido"))
