"""Banco local (SQLite). Funciona 100% offline; uma conexão por thread."""

import os
import sqlite3
import threading
import time

SCHEMA = """
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  client TEXT NOT NULL,
  device_id TEXT NOT NULL,
  ts INTEGER NOT NULL,
  received_at INTEGER,
  kind TEXT NOT NULL,
  user_id TEXT,
  user_name TEXT,
  portal_id TEXT,
  code INTEGER,
  src_id TEXT,
  raw TEXT,
  UNIQUE(client, device_id, src_id)
);
CREATE INDEX IF NOT EXISTS ix_events_c_ts ON events(client, ts);
CREATE INDEX IF NOT EXISTS ix_events_d_ts ON events(client, device_id, ts);
CREATE INDEX IF NOT EXISTS ix_events_u_ts ON events(client, user_id, ts);

CREATE TABLE IF NOT EXISTS devices(
  client TEXT NOT NULL,
  device_id TEXT NOT NULL,
  name TEXT,
  last_seen INTEGER,
  last_event_ts INTEGER,
  PRIMARY KEY(client, device_id)
);

CREATE TABLE IF NOT EXISTS users(
  client TEXT NOT NULL,
  user_id TEXT NOT NULL,
  name TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  first_seen INTEGER,
  last_access_ts INTEGER,
  PRIMARY KEY(client, user_id)
);

CREATE TABLE IF NOT EXISTS alerts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  client TEXT NOT NULL,
  detector TEXT NOT NULL,
  severity TEXT NOT NULL,
  title TEXT NOT NULL,
  detail TEXT,
  device_id TEXT,
  user_id TEXT,
  fingerprint TEXT NOT NULL,
  evidence TEXT,
  status TEXT NOT NULL DEFAULT 'new',
  count INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL,
  last_seen_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_alerts_fp ON alerts(fingerprint, id);
CREATE INDEX IF NOT EXISTS ix_alerts_c ON alerts(client, created_at);

CREATE TABLE IF NOT EXISTS tuning(
  client TEXT NOT NULL,
  detector TEXT NOT NULL,
  multiplier REAL NOT NULL DEFAULT 1.0,
  useful INTEGER NOT NULL DEFAULT 0,
  false_positive INTEGER NOT NULL DEFAULT 0,
  updated_at INTEGER,
  PRIMARY KEY(client, detector)
);

CREATE TABLE IF NOT EXISTS known_patterns(
  client TEXT NOT NULL,
  signature TEXT NOT NULL,
  detector TEXT NOT NULL,
  first_seen INTEGER NOT NULL,
  last_seen INTEGER NOT NULL,
  times INTEGER NOT NULL DEFAULT 1,
  last_alert_id INTEGER,
  PRIMARY KEY(client, signature)
);

CREATE TABLE IF NOT EXISTS notes(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  client TEXT NOT NULL,
  text TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS accounts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  pw_hash TEXT NOT NULL,
  role TEXT NOT NULL,
  display_name TEXT,
  created_at INTEGER NOT NULL,
  last_login INTEGER,
  disabled INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS sessions(
  token_hash TEXT PRIMARY KEY,
  account_id INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  ip TEXT
);

CREATE TABLE IF NOT EXISTS audit(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts INTEGER NOT NULL,
  username TEXT,
  action TEXT NOT NULL,
  detail TEXT,
  ip TEXT
);
CREATE INDEX IF NOT EXISTS ix_audit_ts ON audit(ts);

CREATE TABLE IF NOT EXISTS outbox(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at INTEGER NOT NULL,
  channel TEXT NOT NULL,
  target TEXT,
  payload TEXT NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS meta(
  key TEXT PRIMARY KEY,
  value TEXT
);
"""


SCHEMA_VERSION = 4  # 1: base, 2: padrões/notas, 3: contas/sessões/auditoria. Migrações futuras entram aqui.


class Store:
    def __init__(self, path):
        self.path = path
        self._local = threading.local()
        d = os.path.dirname(os.path.abspath(path))
        os.makedirs(d, exist_ok=True)
        c = self.conn()
        c.executescript(SCHEMA)  # idempotente: cria o que falta, não mexe no que existe
        cols = {r[1] for r in c.execute("PRAGMA table_info(known_patterns)")}
        if "episodes" not in cols:  # migração 3 -> 4: contagem de episódios (ocorrências separadas no tempo)
            c.execute("ALTER TABLE known_patterns ADD COLUMN episodes INTEGER NOT NULL DEFAULT 1")
        c.execute(f"PRAGMA user_version={SCHEMA_VERSION}")
        c.commit()

    def conn(self):
        c = getattr(self._local, "c", None)
        if c is None:
            c = sqlite3.connect(self.path, timeout=30)
            c.row_factory = sqlite3.Row
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA synchronous=NORMAL")
            self._local.c = c
        return c

    # ---------- utilitários ----------
    def rows(self, sql, params=()):
        return self.conn().execute(sql, params).fetchall()

    def one(self, sql, params=()):
        return self.conn().execute(sql, params).fetchone()

    def scalar(self, sql, params=()):
        r = self.one(sql, params)
        return r[0] if r else None

    def commit(self):
        self.conn().commit()

    def meta_get(self, key, default=None):
        r = self.one("SELECT value FROM meta WHERE key=?", (key,))
        return r[0] if r else default

    def meta_set(self, key, value):
        self.conn().execute(
            "INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, str(value)),
        )
        self.conn().commit()

    # ---------- eventos ----------
    def add_event(self, client, device_id, ts, kind, user_id=None, user_name=None,
                  portal_id=None, code=None, src_id=None, raw=None, live=True,
                  now=None, commit=True):
        """Grava um evento. `live=True` marca o horário de recebimento (usado para
        detectar equipamento offline e relógio desajustado). Retorna True se inseriu."""
        now = int(now if now is not None else time.time())
        ts = int(ts)
        device_id = str(device_id)
        user_id = str(user_id) if user_id not in (None, "", "0") else None
        c = self.conn()
        cur = c.execute(
            "INSERT OR IGNORE INTO events(client,device_id,ts,received_at,kind,user_id,user_name,"
            "portal_id,code,src_id,raw) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (client, device_id, ts, now if live else None, kind, user_id, user_name,
             None if portal_id is None else str(portal_id), code,
             None if src_id is None else str(src_id), raw),
        )
        inserted = cur.rowcount == 1
        if inserted:
            c.execute(
                "INSERT INTO devices(client,device_id,last_seen,last_event_ts) VALUES(?,?,?,?) "
                "ON CONFLICT(client,device_id) DO UPDATE SET "
                "last_event_ts=MAX(COALESCE(last_event_ts,0),excluded.last_event_ts), "
                "last_seen=CASE WHEN excluded.last_seen IS NULL THEN last_seen "
                "WHEN last_seen IS NULL THEN excluded.last_seen "
                "ELSE MAX(last_seen,excluded.last_seen) END",
                (client, device_id, now if live else None, ts),
            )
            if user_id:
                c.execute(
                    "INSERT INTO users(client,user_id,name,first_seen,last_access_ts) VALUES(?,?,?,?,?) "
                    "ON CONFLICT(client,user_id) DO UPDATE SET "
                    "name=COALESCE(excluded.name,name), "
                    "first_seen=MIN(COALESCE(first_seen,excluded.first_seen),excluded.first_seen), "
                    "last_access_ts=CASE WHEN excluded.last_access_ts IS NULL THEN last_access_ts "
                    "WHEN last_access_ts IS NULL THEN excluded.last_access_ts "
                    "ELSE MAX(last_access_ts,excluded.last_access_ts) END",
                    (client, user_id, user_name, ts, ts if kind == "grant" else None),
                )
        if commit:
            c.commit()
        return inserted

    def heartbeat(self, client, device_id, now=None, name=None, commit=True):
        now = int(now if now is not None else time.time())
        self.conn().execute(
            "INSERT INTO devices(client,device_id,name,last_seen) VALUES(?,?,?,?) "
            "ON CONFLICT(client,device_id) DO UPDATE SET "
            "last_seen=CASE WHEN last_seen IS NULL THEN excluded.last_seen "
            "ELSE MAX(last_seen,excluded.last_seen) END, "
            "name=COALESCE(excluded.name,name)",
            (client, str(device_id), name, now),
        )
        if commit:
            self.conn().commit()

    def set_device_name(self, client, device_id, name, commit=True):
        self.conn().execute(
            "INSERT INTO devices(client,device_id,name) VALUES(?,?,?) "
            "ON CONFLICT(client,device_id) DO UPDATE SET name=excluded.name",
            (client, str(device_id), name),
        )
        if commit:
            self.conn().commit()

    def upsert_user(self, client, user_id, name=None, active=None, commit=True):
        self.conn().execute(
            "INSERT INTO users(client,user_id,name,active) VALUES(?,?,?,?) "
            "ON CONFLICT(client,user_id) DO UPDATE SET name=COALESCE(excluded.name,name), "
            "active=COALESCE(?,active)",
            (client, str(user_id), name, 1 if active is None else int(active),
             None if active is None else int(active)),
        )
        if commit:
            self.conn().commit()

    # ---------- aprendizado (feedback) ----------
    def get_tuning(self, client):
        return {r["detector"]: r["multiplier"]
                for r in self.rows("SELECT detector,multiplier FROM tuning WHERE client=?", (client,))}
