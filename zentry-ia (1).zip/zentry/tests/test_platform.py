import os as _o, sys as _s
_s.path.insert(0, _o.path.dirname(_o.path.dirname(_o.path.abspath(__file__))))
import os, tempfile, time, unittest
from zentry.app import App
from zentry.auth import Auth, AuthError, has_role, verify_password, hash_password
from zentry.config import DEFAULTS, deep_merge, init_config, load_config
from zentry import settings, maintenance


def make_app():
    d = tempfile.mkdtemp()
    path = os.path.join(d, "config.json")
    init_config(path)
    cfg = load_config(path)
    return App(cfg, config_path=path), d


class PlatformTests(unittest.TestCase):
    def test_home_and_db_created_in_data_dir(self):
        app, d = make_app()
        self.assertTrue(os.path.exists(os.path.join(d, "zentry.db")))
        self.assertEqual(app.cfg["_home"], os.path.realpath(d))

    def test_password_and_roles(self):
        h = hash_password("segredo123")
        self.assertTrue(verify_password("segredo123", h))
        self.assertFalse(verify_password("errada", h))
        self.assertTrue(has_role("admin", "operator"))
        self.assertFalse(has_role("viewer", "operator"))

    def test_login_session_and_lockout(self):
        app, _ = make_app()
        au = Auth(app.store, app.cfg)
        au.create_account("Vini", "senha-forte-1", "admin")
        with self.assertRaises(AuthError):
            au.create_account("x", "curta")
        tok, acc = au.login("vini", "senha-forte-1", ip="1.1.1.1", now=1000)
        self.assertEqual(au.session(tok, now=1001)["role"], "admin")
        self.assertIsNone(au.session(tok, now=1000 + 13 * 3600))
        au.logout(tok)
        self.assertIsNone(au.session(tok, now=1001))
        for _ in range(5):
            with self.assertRaises(AuthError):
                au.login("vini", "errada", ip="2.2.2.2", now=2000)
        with self.assertRaises(AuthError) as cm:  # bloqueado até com a senha certa
            au.login("vini", "senha-forte-1", ip="2.2.2.2", now=2001)
        self.assertIn("tentativas", str(cm.exception))
        au.login("vini", "senha-forte-1", ip="2.2.2.2", now=2000 + 400)

    def test_last_admin_protected(self):
        app, _ = make_app()
        au = Auth(app.store, app.cfg)
        au.create_account("admin", "senha-forte-1", "admin")
        for fn in (lambda: au.update_account("admin", role="viewer"),
                   lambda: au.update_account("admin", disabled=True),
                   lambda: au.delete_account("admin")):
            with self.assertRaises(AuthError):
                fn()

    def test_api_key(self):
        app, _ = make_app()
        au = Auth(app.store, app.cfg)
        self.assertTrue(au.api_key_ok(app.cfg["server"]["token"]))
        self.assertFalse(au.api_key_ok("outra"))
        self.assertFalse(au.api_key_ok(""))

    def test_settings_validate_mask_save(self):
        app, d = make_app()
        app.cfg["llm"]["api_key"] = "sk-secreta"
        pub = settings.public_view(app.cfg)
        self.assertEqual(pub["llm"]["api_key"], settings.MASK)
        self.assertEqual(pub["server"]["token"], settings.MASK)
        self.assertNotIn("_home", pub)
        with self.assertRaises(settings.SettingsError):
            settings.apply_changes(app.cfg, app.config_path, {"engine": {"interval_seconds": 0}})
        with self.assertRaises(settings.SettingsError):
            settings.apply_changes(app.cfg, app.config_path, {"db_path": "/etc/x"})
        with self.assertRaises(settings.SettingsError):
            settings.apply_changes(app.cfg, app.config_path, {"timezone": "Marte/Olimpo"})
        ch = settings.apply_changes(app.cfg, app.config_path,
                                    {"engine": {"interval_seconds": 45}, "llm": {"api_key": settings.MASK}})
        self.assertEqual(ch, ["engine.interval_seconds"])
        self.assertEqual(app.cfg["llm"]["api_key"], "sk-secreta")  # máscara não sobrescreve
        again = load_config(app.config_path)
        self.assertEqual(again["engine"]["interval_seconds"], 45)
        self.assertNotIn("_home", open(app.config_path).read())

    def test_backup_and_purge(self):
        app, d = make_app()
        now = time.time()
        app.store.add_event("default", "1", int(now - 500 * 86400), "grant", user_id="1", now=now)
        app.store.add_event("default", "1", int(now - 10), "grant", user_id="1", now=now)
        res = maintenance.purge(app, now)
        self.assertEqual(res["events"], 1)
        path = maintenance.make_backup(app, now)
        self.assertTrue(os.path.getsize(path) > 0)
        self.assertIsNone(maintenance.backup_path(app.cfg, "../config.json"))
        self.assertEqual(len(maintenance.list_backups(app.cfg)), 1)
        self.assertIsNotNone(maintenance.run_daily(app, now + 86400 * 1) or True)

if __name__ == "__main__":
    unittest.main()


class DetectorMetaTests(unittest.TestCase):
    def test_params_metadata_matches_code(self):
        import re, inspect
        from zentry.detectors import discover
        for d in discover(None).values():
            if not type(d).__module__.startswith('zentry.detectors'):
                continue  # plugins de terceiros não são checados aqui
            src = inspect.getsource(type(d))
            used = set(re.findall(r'ctx\.param\(self\.name, "(\w+)"', src))
            declared = {p[0] for p in d.params}
            self.assertEqual(used, declared, d.name)
