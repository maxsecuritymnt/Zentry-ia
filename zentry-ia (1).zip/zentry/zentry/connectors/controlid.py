from .. import devices
from ..config import device_cfg
from .base import Connector


class ControlIdConnector(Connector):
    name = "controlid"
    label = "Control iD (iDFace / iDBlock / iDFlex)"
    default_port = 80
    push_path = "/api/notifications/…"
    help = ("No equipamento, configure o Monitor para o endereço deste computador (porta 8000). Mantenha o modo autônomo. "
            "Para consulta direta, marque “Consultar”, informe usuário e senha do equipamento.")

    def poll_all(self, cfg, store):
        total = 0
        for cid, did, d in self.devices(cfg):
            if d.get("poll") and d.get("ip"):
                try:
                    total += devices.poll_device(cfg, store, cid, did, d)
                except Exception as e:
                    import logging
                    logging.getLogger("zentry").warning("Falha ao coletar de %s/%s: %s", cid, did, e)
        return total

    def check(self, d):
        return devices._post(f"http://{d['ip']}:{d.get('port', 80)}/login.fcgi",
                             {"login": d.get("user", "admin"), "password": devices.os.environ.get(d.get("password_env", ""), d.get("password", ""))})
