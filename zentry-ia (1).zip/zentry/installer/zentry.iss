; Inno Setup 6 — gera ZentryIA-Setup-<versão>.exe
; Compile com:  iscc /DAppVersion=0.3.0 installer\zentry.iss   (depois do PyInstaller)
#ifndef AppVersion
  #define AppVersion "0.5.0"
#endif

[Setup]
AppId={{6E1F6C3A-2B7D-4E58-9C1B-5A7D2F0E9A11}
AppName=Zentry IA
AppVersion={#AppVersion}
AppPublisher=Zentry IA
DefaultDirName={autopf}\Zentry IA
DefaultGroupName=Zentry IA
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=Output
OutputBaseFilename=ZentryIA-Setup-{#AppVersion}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayName=Zentry IA
CloseApplications=yes

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "Criar atalho na área de trabalho"; Flags: unchecked
Name: "autostart"; Description: "Iniciar o Zentry IA junto com o Windows"
Name: "firewall"; Description: "Permitir que os equipamentos da rede enviem eventos (libera as portas 8000 e 8001 no firewall)"

[Dirs]
; dados ficam FORA da pasta do programa: atualizar/desinstalar não apaga o banco
Name: "{commonappdata}\ZentryIA"; Permissions: users-modify
Name: "{commonappdata}\ZentryIA\plugins"; Permissions: users-modify

[Files]
Source: "..\dist\zentry\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion
Source: "..\LICENSE"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Zentry IA"; Filename: "{app}\zentry-bg.exe"; Parameters: "run --open"
Name: "{group}\Pasta de dados"; Filename: "{commonappdata}\ZentryIA"
Name: "{group}\Desinstalar"; Filename: "{uninstallexe}"
Name: "{autodesktop}\Zentry IA"; Filename: "{app}\zentry-bg.exe"; Parameters: "run --open"; Tasks: desktopicon

[Registry]
Root: HKLM; Subkey: "SOFTWARE\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "ZentryIA"; ValueData: """{app}\zentry-bg.exe"" run"; Tasks: autostart; Flags: uninsdeletevalue

[Run]
; cria configuração e banco de dados
Filename: "{app}\zentry.exe"; Parameters: "setup --silent"; Flags: runhidden waituntilterminated; StatusMsg: "Criando o banco de dados…"
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall add rule name=""Zentry IA"" dir=in action=allow protocol=TCP localport=8000,8001 profile=private"; Flags: runhidden; Tasks: firewall
; atualização silenciosa: reabre o Zentry sozinho
Filename: "{app}\zentry-bg.exe"; Parameters: "run"; Flags: nowait runhidden; Check: WizardSilent
Filename: "{app}\zentry-bg.exe"; Parameters: "run --open"; Description: "Abrir o Zentry IA agora"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""Zentry IA"""; Flags: runhidden; RunOnceId: "DelFirewall"
Filename: "{sys}\taskkill.exe"; Parameters: "/F /IM zentry-bg.exe"; Flags: runhidden; RunOnceId: "KillBg"
