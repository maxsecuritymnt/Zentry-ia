"""Rotinas de manutenção: backup do banco (API de backup do SQLite) e limpeza por retenção."""

import os
import re
import sqlite3
import time
from datetime import datetime

from .paths import home_path
from .timeutil import get_tz

NAME_RE = re.compile(r"^zentry-\d{8}-\d{6}(-pre)?\.db$")  # -pre = cópia de segurança feita antes de uma restauração


def backups_dir(cfg):
    d = home_path(cfg, cfg.get("backups_dir", "backups"))
    os.makedirs(d, exist_ok=True)
    return d


def make_backup(app, now=None):
    """Cópia consistente do banco (segura mesmo com o sistema rodando)."""
    cfg = app.cfg
    now = now if now is not None else time.time()
    stamp = datetime.fromtimestamp(now, get_tz(cfg.get("timezone"))).strftime("%Y%m%d-%H%M%S")
    dest = os.path.join(backups_dir(cfg), f"zentry-{stamp}.db")
    dst = sqlite3.connect(dest)
    try:
        app.store.conn().backup(dst)
    finally:
        dst.close()
    prune_backups(cfg)
    return dest


def list_backups(cfg):
    d = backups_dir(cfg)
    out = []
    for n in sorted(os.listdir(d), reverse=True):
        if NAME_RE.match(n):
            out.append({"name": n, "size": os.path.getsize(os.path.join(d, n)),
                        "mtime": int(os.path.getmtime(os.path.join(d, n)))})
    return out


def backup_path(cfg, name):
    if not NAME_RE.match(name or ""):
        return None
    p = os.path.join(backups_dir(cfg), name)
    return p if os.path.isfile(p) else None


def _marker(cfg):
    return os.path.join(cfg.get("_home", "."), "restore.pending")


def stage_restore(cfg, name):
    """Valida o backup e agenda a restauração para o próximo início (não é seguro trocar o banco com o sistema em uso)."""
    path = backup_path(cfg, name)
    if not path:
        raise ValueError("Backup não encontrado.")
    try:
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            ok = con.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
            has = con.execute("SELECT 1 FROM sqlite_master WHERE name='events'").fetchone()
        finally:
            con.close()
    except sqlite3.Error:
        ok, has = False, None
    if not ok or not has:
        raise ValueError("Esse arquivo de backup está corrompido ou não é um banco do Zentry.")
    with open(_marker(cfg), "w", encoding="utf-8") as f:
        f.write(name)
    return name


def apply_pending_restore(cfg):
    """Chamado ANTES de abrir o banco. Guarda uma cópia do banco atual e coloca o backup no lugar."""
    import shutil
    mk = _marker(cfg)
    if not os.path.exists(mk):
        return None
    name = open(mk, encoding="utf-8").read().strip()
    src = backup_path(cfg, name)
    db = home_path(cfg, cfg["db_path"])
    try:
        if src:
            if os.path.exists(db):
                stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
                shutil.copy2(db, os.path.join(backups_dir(cfg), f"zentry-{stamp}-pre.db"))  # cópia de segurança
            for ext in ("-wal", "-shm"):
                if os.path.exists(db + ext):
                    os.unlink(db + ext)
            shutil.copy2(src, db)
        return name if src else None
    finally:
        os.unlink(mk)


def prune_backups(cfg):
    keep = int(cfg.get("maintenance", {}).get("backup_keep", 14))
    for b in list_backups(cfg)[keep:]:
        try:
            os.unlink(os.path.join(backups_dir(cfg), b["name"]))
        except OSError:
            pass


def purge(app, now=None):
    """Apaga eventos e auditoria antigos conforme a retenção configurada."""
    m = app.cfg.get("maintenance", {})
    now = int(now if now is not None else time.time())
    c = app.store.conn()
    ev = c.execute("DELETE FROM events WHERE ts<?", (now - int(m.get("events_retention_days", 400)) * 86400,)).rowcount
    au = c.execute("DELETE FROM audit WHERE ts<?", (now - int(m.get("audit_retention_days", 730)) * 86400,)).rowcount
    c.execute("DELETE FROM sessions WHERE expires_at<?", (now,))
    app.store.commit()
    return {"events": ev, "audit": au}


def run_daily(app, now=None):
    """Chamada pelo laço do servidor; faz no máximo um backup por dia, na hora configurada."""
    cfg, st = app.cfg, app.store
    m = cfg.get("maintenance", {})
    now = now if now is not None else time.time()
    local = datetime.fromtimestamp(now, get_tz(cfg.get("timezone")))
    day = local.strftime("%Y-%m-%d")
    if st.meta_get("maintenance_day") == day or local.hour < int(m.get("backup_hour", 3)):
        return None
    st.meta_set("maintenance_day", day)
    res = {"purged": purge(app, now)}
    if m.get("backup_enabled", True):
        res["backup"] = os.path.basename(make_backup(app, now))
    return res
