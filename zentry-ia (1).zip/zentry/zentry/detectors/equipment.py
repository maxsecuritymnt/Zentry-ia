"""Detectores de saúde dos equipamentos."""

import statistics
from collections import defaultdict

from .base import Alert, Detector, fmt_dur

ATTEMPT_KINDS = ("grant", "deny", "not_identified")


class DeviceOffline(Detector):
    name = "equipamento_offline"
    title = "Equipamento offline"
    description = "Equipamento (com IP ou heartbeat configurado) sem comunicação há mais que o limite."
    params = [('minutes', 10, 'Minutos sem comunicação para considerar offline', 'min')]
    severity = "critico"

    def run(self, ctx):
        limit = ctx.param(self.name, "minutes", 10, scale=True) * 60
        out = []
        for d in ctx.devices():
            dc = ctx.dev_cfg(d["device_id"])
            if not (dc.get("ip") or dc.get("heartbeat")) or d["last_seen"] is None:
                continue
            gap = ctx.now - d["last_seen"]
            if gap > limit:
                nm = ctx.device_name(d["device_id"])
                out.append(Alert(
                    self.name, self.severity, f"{nm}: sem comunicação há {fmt_dur(gap)}",
                    "O equipamento parou de responder. Verifique alimentação, rede/switch e cabo. "
                    "Em modo autônomo ele continua liberando acessos, mas os eventos ficam retidos nele.",
                    device_id=d["device_id"], key="offline", evidence={"gap_s": gap}))
        return out


class ClockDrift(Detector):
    name = "relogio_desajustado"
    title = "Relógio do equipamento desajustado"
    description = "Diferença entre a hora do evento e a hora em que chegou ao servidor."
    params = [('seconds', 120, 'Diferença de relógio tolerada', 's')]
    severity = "atencao"

    def run(self, ctx):
        thr = ctx.param(self.name, "seconds", 120, scale=True)
        rows = ctx.store.rows(
            "SELECT device_id, received_at-ts AS d FROM events "
            "WHERE client=? AND received_at IS NOT NULL AND received_at>=?",
            (ctx.client, ctx.now - 45 * 60))
        by = defaultdict(list)
        for r in rows:
            by[r["device_id"]].append(r["d"])
        out = []
        for dev, ds in by.items():
            if len(ds) < 3:
                continue
            med = statistics.median(ds)
            if abs(med) > thr:
                hint = ""
                if abs(med) >= 1800 and min(abs(med) % 3600, 3600 - abs(med) % 3600) < 300:
                    hint = " Diferença próxima de horas inteiras: provável fuso horário errado."
                out.append(Alert(
                    self.name, self.severity,
                    f"{ctx.device_name(dev)}: relógio {'atrasado' if med > 0 else 'adiantado'} ~{fmt_dur(abs(med))}",
                    "Relógio fora do horário atrapalha relatórios e auditoria." + hint +
                    " Ajuste NTP/fuso no equipamento.",
                    device_id=dev, key="drift", evidence={"median_s": med}))
        return out


class SilentDevice(Detector):
    name = "equipamento_silencioso"
    title = "Equipamento sem movimento no horário habitual"
    description = "Sem eventos na última hora em horário que historicamente tem movimento."
    params = [('min_expected', 6, 'Eventos mínimos esperados na última hora', 'eventos')]
    severity = "atencao"

    def run(self, ctx):
        min_expected = ctx.param(self.name, "min_expected", 6, scale=True)
        days = 14
        weekend_now = ctx.local(ctx.now).weekday() >= 5
        out = []
        for d in ctx.devices():
            dev = d["device_id"]
            dc = ctx.dev_cfg(dev)
            if dc.get("ip") and d["last_seen"] is not None and ctx.now - d["last_seen"] > 900:
                continue  # já coberto pelo detector de offline
            evs = ctx.store.rows(
                "SELECT ts FROM events WHERE client=? AND device_id=? AND ts>=? AND ts<=? "
                "AND kind IN ('grant','deny','not_identified','turn')",
                (ctx.client, dev, ctx.now - (days + 1) * 86400, ctx.now))
            if not evs or ctx.now - min(e["ts"] for e in evs) < 7 * 86400:
                continue
            counts = defaultdict(int)
            cur = 0
            for e in evs:
                age = ctx.now - e["ts"]
                k, off = divmod(age, 86400)
                if off >= 3600:
                    continue
                if k == 0:
                    cur += 1
                elif k <= days:
                    counts[k] += 1
            elig = [k for k in range(1, days + 1)
                    if (ctx.local(ctx.now - k * 86400).weekday() >= 5) == weekend_now]
            if len(elig) < 3:
                continue
            avg = sum(counts.get(k, 0) for k in elig) / len(elig)
            if avg >= min_expected and cur == 0:
                out.append(Alert(
                    self.name, self.severity,
                    f"{ctx.device_name(dev)}: sem eventos na última hora (normal: ~{avg:.0f})",
                    "Nesse horário o equipamento costuma registrar movimento. Pode ser falha de leitura, "
                    "porta bloqueada, queda de rede ou ausência real de pessoas.",
                    device_id=dev, key="silent", evidence={"avg": avg}))
        return out


class ReaderDegradation(Detector):
    name = "degradacao_leitora"
    title = "Taxa de falha da leitora subindo"
    description = "Compara a taxa de negações/falhas dos últimos 7 dias com os 7 anteriores."
    params = [('increase', 0.1, 'Aumento da taxa de falha que dispara o alerta (0.10 = 10 pontos)', ''), ('min_attempts', 30, 'Tentativas mínimas para avaliar', 'tentativas')]
    severity = "atencao"

    def run(self, ctx):
        jump = ctx.param(self.name, "increase", 0.10, scale=True)
        min_attempts = int(ctx.param(self.name, "min_attempts", 30))
        out = []
        for d in ctx.devices():
            dev = d["device_id"]

            def rate(t0, t1):
                rows = ctx.store.rows(
                    "SELECT kind, COUNT(*) n FROM events WHERE client=? AND device_id=? AND ts>=? AND ts<? "
                    "AND kind IN ('grant','deny','not_identified') GROUP BY kind",
                    (ctx.client, dev, t0, t1))
                tot = sum(r["n"] for r in rows)
                bad = sum(r["n"] for r in rows if r["kind"] != "grant")
                return (bad / tot if tot else 0.0), tot

            now_r, now_n = rate(ctx.now - 7 * 86400, ctx.now + 1)
            prev_r, prev_n = rate(ctx.now - 14 * 86400, ctx.now - 7 * 86400)
            if now_n >= min_attempts and prev_n >= min_attempts and now_r - prev_r >= jump:
                out.append(Alert(
                    self.name, self.severity,
                    f"{ctx.device_name(dev)}: falhas subiram de {prev_r:.0%} para {now_r:.0%}",
                    "Tendência de piora na leitura. Verifique limpeza/posição da leitora, iluminação (facial), "
                    "base de cadastro e conexão.",
                    device_id=dev, key="degradation",
                    evidence={"prev": prev_r, "now": now_r}))
        return out


class DoorHeldOpen(Detector):
    name = "porta_aberta_tempo_excessivo"
    title = "Porta aberta por tempo excessivo"
    description = "Último evento da porta foi 'aberta' e continua assim além do limite."
    params = [('seconds', 120, 'Segundos aberta até alertar', 's'), ('critical_seconds', 600, 'Segundos aberta até ficar crítico', 's')]
    severity = "atencao"

    def run(self, ctx):
        limit = ctx.param(self.name, "seconds", 120, scale=True)
        crit = ctx.param(self.name, "critical_seconds", 600)
        rows = ctx.store.rows(
            "SELECT device_id, portal_id, kind, ts FROM events WHERE client=? AND ts>=? "
            "AND kind IN ('door_open','door_close') ORDER BY ts, id", (ctx.client, ctx.now - 86400))
        last = {}
        for r in rows:
            last[(r["device_id"], r["portal_id"])] = r
        out = []
        for (dev, portal), r in last.items():
            gap = ctx.now - r["ts"]
            if r["kind"] == "door_open" and gap > limit:
                sev = "critico" if gap > crit else "atencao"
                out.append(Alert(
                    self.name, sev, f"{ctx.device_name(dev)}: porta aberta há {fmt_dur(gap)}",
                    "Porta mantida aberta ou sensor travado. Risco de acesso indevido.",
                    device_id=dev, key="porta", traits=f"portal{portal}", evidence={"gap_s": gap}))
        return out
