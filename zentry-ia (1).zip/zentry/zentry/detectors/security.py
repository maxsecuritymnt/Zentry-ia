"""Detectores de segurança: comportamento de pessoas e credenciais."""

import hashlib
from collections import Counter, defaultdict

from .base import Alert, Detector, fmt_dur


class BruteForce(Detector):
    name = "forca_bruta"
    title = "Tentativas negadas em sequência"
    description = "Muitas negações da mesma credencial, tentativas em várias portas ou muitas faces desconhecidas."
    params = [('window_minutes', 10, 'Janela de análise', 'min'), ('attempts_per_user', 5, 'Negações da mesma credencial', 'tentativas'), ('unknown_attempts', 15, 'Faces desconhecidas na janela', 'tentativas'), ('distinct_devices', 3, 'Portas diferentes tentadas', 'portas')]
    severity = "atencao"

    def run(self, ctx):
        win = ctx.param(self.name, "window_minutes", 10) * 60
        n_user = int(ctx.param(self.name, "attempts_per_user", 5, scale=True))
        n_unknown = int(ctx.param(self.name, "unknown_attempts", 15, scale=True))
        n_doors = int(ctx.param(self.name, "distinct_devices", 3))
        rows = ctx.events(ctx.now - win, ctx.now, kinds=("deny", "not_identified"))
        by_user = defaultdict(list)
        unknown = Counter()
        for r in rows:
            if r["user_id"]:
                by_user[(r["device_id"], r["user_id"])].append(r)
            else:
                unknown[r["device_id"]] += 1
        out = []
        for (dev, uid), lst in by_user.items():
            if len(lst) >= n_user:
                out.append(Alert(
                    self.name, "atencao",
                    f"{len(lst)} negações de {ctx.user_label(uid)} em {ctx.device_name(dev)}",
                    f"Em {win // 60} min. Pode ser credencial bloqueada/expirada, cadastro errado ou tentativa de invasão.",
                    device_id=dev, user_id=uid, key=f"user:{uid}", evidence={"n": len(lst)}))
        doors = defaultdict(set)
        denies = Counter()
        for (dev, uid), lst in by_user.items():
            doors[uid].add(dev)
            denies[uid] += len(lst)
        for uid, ds in doors.items():
            if len(ds) >= n_doors and denies[uid] >= n_doors:
                out.append(Alert(
                    self.name, "critico",
                    f"{ctx.user_label(uid)} tentou {len(ds)} portas diferentes e foi negado",
                    "Padrão de varredura de portas: credencial tentando áreas que não são dela.",
                    user_id=uid, key=f"scan:{uid}", evidence={"devices": sorted(ds)}))
        for dev, n in unknown.items():
            if n >= n_unknown:
                out.append(Alert(
                    self.name, "atencao",
                    f"{n} tentativas não identificadas em {ctx.device_name(dev)}",
                    f"Em {win // 60} min. Muitas faces/cartões desconhecidos: possível tentativa de acesso "
                    "indevido ou leitora com problema.",
                    device_id=dev, key="unknown", evidence={"n": n}))
        return out


class ExcessDenials(Detector):
    name = "excesso_negacoes"
    title = "Taxa de negações alta no equipamento"
    description = "Proporção de negações/falhas nas últimas 24 h acima do limite."
    params = [('ratio', 0.35, 'Proporção de negações (0.35 = 35%)', ''), ('min_attempts', 30, 'Tentativas mínimas em 24 h', 'tentativas')]
    severity = "atencao"

    def run(self, ctx):
        ratio = ctx.param(self.name, "ratio", 0.35, scale=True)
        min_attempts = int(ctx.param(self.name, "min_attempts", 30))
        rows = ctx.store.rows(
            "SELECT device_id, kind, COUNT(*) n FROM events WHERE client=? AND ts>=? AND ts<=? "
            "AND kind IN ('grant','deny','not_identified') GROUP BY device_id, kind",
            (ctx.client, ctx.now - 86400, ctx.now))
        tot, bad = Counter(), Counter()
        for r in rows:
            tot[r["device_id"]] += r["n"]
            if r["kind"] != "grant":
                bad[r["device_id"]] += r["n"]
        out = []
        for dev, t in tot.items():
            if t >= min_attempts and bad[dev] / t >= ratio:
                out.append(Alert(
                    self.name, "atencao",
                    f"{ctx.device_name(dev)}: {bad[dev] / t:.0%} de negações nas últimas 24 h",
                    f"{bad[dev]} de {t} tentativas. Revise regras de horário, cadastros vencidos e a leitora.",
                    device_id=dev, key="ratio24h",
                    evidence={"bad": bad[dev], "total": t}))
        return out


class ImpossibleTravel(Detector):
    name = "viagem_impossivel"
    title = "Mesma credencial em dois lugares ao mesmo tempo"
    description = "Acessos liberados em zonas diferentes em intervalo curto demais (possível clonagem/empréstimo)."
    params = [('min_travel_seconds', 120, 'Tempo mínimo plausível entre zonas', 's'), ('window_minutes', 30, 'Janela de análise', 'min')]
    severity = "critico"

    def run(self, ctx):
        gap = ctx.param(self.name, "min_travel_seconds", 120)
        win = ctx.param(self.name, "window_minutes", 30) * 60
        rows = ctx.events(ctx.now - win, ctx.now, kinds=("grant",))
        by_user = defaultdict(list)
        for r in rows:
            if r["user_id"]:
                by_user[r["user_id"]].append(r)
        out = []
        for uid, lst in by_user.items():
            for a, b in zip(lst, lst[1:]):
                za = ctx.dev_cfg(a["device_id"]).get("zone")
                zb = ctx.dev_cfg(b["device_id"]).get("zone")
                if za and zb and za != zb and b["ts"] - a["ts"] < gap:
                    out.append(Alert(
                        self.name, self.severity,
                        f"{ctx.user_label(uid)} em {ctx.device_name(a['device_id'])} e "
                        f"{ctx.device_name(b['device_id'])} com {b['ts'] - a['ts']}s de diferença",
                        "Tempo insuficiente para ir de uma zona à outra: credencial compartilhada, clonada "
                        "ou carona de outra pessoa.",
                        device_id=b["device_id"], user_id=uid, key="viagem",
                        traits=f"origem{a['device_id']}"))
        return out


class OffHours(Detector):
    name = "horario_atipico"
    title = "Acesso em horário atípico para a pessoa"
    description = "Aprende o padrão de horário de cada usuário e alerta quando foge muito dele."
    params = [('window_minutes', 20, 'Janela de análise', 'min'), ('lookback_days', 60, 'Dias de histórico aprendidos', 'dias'), ('min_samples', 20, 'Acessos mínimos para ter padrão', 'acessos'), ('max_share', 0.02, "Fatia máxima do horário para ser 'atípico' (0.02 = 2%)", '')]
    severity = "atencao"

    def run(self, ctx):
        win = ctx.param(self.name, "window_minutes", 20) * 60
        lookback = int(ctx.param(self.name, "lookback_days", 60))
        min_samples = int(ctx.param(self.name, "min_samples", 20))
        max_share = ctx.param(self.name, "max_share", 0.02) / ctx.mult(self.name)
        t0 = ctx.now - win
        recent = ctx.events(t0, ctx.now, kinds=("grant",))
        hist_cache, out = {}, []
        for e in recent:
            uid = e["user_id"]
            if not uid:
                continue
            if uid not in hist_cache:
                hs = ctx.store.rows(
                    "SELECT ts FROM events WHERE client=? AND user_id=? AND kind='grant' AND ts<? AND ts>=?",
                    (ctx.client, uid, t0, ctx.now - lookback * 86400))
                hist_cache[uid] = Counter(ctx.local(h["ts"]).hour for h in hs), len(hs)
            hours, n = hist_cache[uid]
            if n < min_samples:
                continue
            h = ctx.local(e["ts"]).hour
            share = (hours[h] + 0.5 * hours[(h - 1) % 24] + 0.5 * hours[(h + 1) % 24]) / n
            if share < max_share:
                out.append(Alert(
                    self.name, self.severity,
                    f"{ctx.user_label(uid)} acessou {ctx.device_name(e['device_id'])} "
                    f"às {ctx.local(e['ts']):%H:%M}, fora do padrão",
                    f"Em {n} acessos anteriores, esse horário praticamente nunca aparece.",
                    device_id=e["device_id"], user_id=uid, key="offhours", traits=f"h{h}",
                    evidence={"share": share, "samples": n}))
        return out


class AntiPassback(Detector):
    name = "anti_passback"
    title = "Entrada sem saída anterior (ou o inverso)"
    description = "Duas entradas (ou duas saídas) seguidas da mesma pessoa na mesma zona."
    params = [('window_minutes', 20, 'Janela de análise', 'min'), ('min_gap_seconds', 30, 'Intervalo mínimo entre as duas passagens', 's')]
    severity = "atencao"

    def run(self, ctx):
        win = ctx.param(self.name, "window_minutes", 20) * 60
        min_gap = ctx.param(self.name, "min_gap_seconds", 30)
        dirs = {}
        for d in ctx.devices():
            dr = ctx.dev_cfg(d["device_id"]).get("direction")
            if dr in ("in", "out"):
                dirs[d["device_id"]] = dr
        zone_dirs = defaultdict(set)
        for dev, dr in dirs.items():
            zone_dirs[ctx.dev_cfg(dev).get("zone") or "default"].add(dr)
        dirs = {dev: dr for dev, dr in dirs.items()
                if zone_dirs[ctx.dev_cfg(dev).get("zone") or "default"] == {"in", "out"}}
        if not dirs:
            return []
        t0 = ctx.now - win
        rows = ctx.events(ctx.now - 86400, ctx.now, kinds=("grant",))
        seq = defaultdict(list)
        for r in rows:
            if r["user_id"] and r["device_id"] in dirs:
                zone = ctx.dev_cfg(r["device_id"]).get("zone") or "default"
                seq[(r["user_id"], zone)].append(r)
        out = []
        for (uid, zone), lst in seq.items():
            for a, b in zip(lst, lst[1:]):
                if b["ts"] >= t0 and dirs[a["device_id"]] == dirs[b["device_id"]] \
                        and b["ts"] - a["ts"] >= min_gap:
                    what = "Duas entradas" if dirs[b["device_id"]] == "in" else "Duas saídas"
                    out.append(Alert(
                        self.name, self.severity,
                        f"{what} seguidas de {ctx.user_label(uid)} ({zone})",
                        f"Intervalo de {fmt_dur(b['ts'] - a['ts'])} sem o movimento contrário. Indica carona, "
                        "passagem sem leitura ou credencial usada por outra pessoa.",
                        device_id=b["device_id"], user_id=uid, key="passback",
                        traits=dirs[b["device_id"]]))
        return out


class DormantCredentials(Detector):
    name = "credenciais_inativas"
    title = "Credenciais ativas sem uso"
    description = "Usuários ativos que não acessam há muitos dias (candidatos a revisão/bloqueio)."
    params = [('days', 90, 'Dias sem uso', 'dias')]
    severity = "info"

    def run(self, ctx):
        days = int(ctx.param(self.name, "days", 90))
        first = ctx.store.scalar("SELECT MIN(ts) FROM events WHERE client=?", (ctx.client,))
        if first is None or ctx.now - first < days * 86400:
            return []  # histórico insuficiente para afirmar
        rows = ctx.store.rows(
            "SELECT user_id, name, last_access_ts FROM users WHERE client=? AND active=1 "
            "AND last_access_ts IS NOT NULL AND last_access_ts<? ORDER BY last_access_ts",
            (ctx.client, ctx.now - days * 86400))
        if not rows:
            return []
        names = [f"{r['name'] or 'usuário'} (#{r['user_id']}, {(ctx.now - r['last_access_ts']) // 86400}d)"
                 for r in rows[:15]]
        extra = f" e mais {len(rows) - 15}" if len(rows) > 15 else ""
        return [Alert(
            self.name, self.severity,
            f"{len(rows)} credencial(is) ativa(s) sem uso há mais de {days} dias",
            "Revise e bloqueie quem saiu da empresa/condomínio: " + "; ".join(names) + extra,
            key="dormant",
            traits=hashlib.md5(",".join(sorted(str(r["user_id"]) for r in rows)).encode()).hexdigest()[:8],
            evidence={"n": len(rows)})]
