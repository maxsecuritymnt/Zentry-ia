"""Linha de comando do Zentry IA:  python3 -m zentry <comando>"""

import argparse
import logging
import os
import sys
import time

from . import report
from .app import App
from .config import init_config, load_config
from .paths import config_file
from .db import Store
from .ingest import import_csv
from .simulate import build_demo, demo_config
from .server import serve


def main(argv=None):
    p = argparse.ArgumentParser(prog="zentry", description="Zentry IA - controle de acesso inteligente")
    p.add_argument("-c", "--config", default=None, help="caminho do config.json (padrão: pasta de dados do Zentry)")
    p.add_argument("-v", "--verbose", action="store_true")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("setup", help="prepara pasta de dados, configuração e banco (usado pelo instalador)")
    s.add_argument("--silent", action="store_true")
    s = sub.add_parser("backup", help="faz uma cópia do banco agora")
    s = sub.add_parser("users", help="gerencia contas do painel")
    s.add_argument("action", choices=["list", "add", "reset-password"])
    s.add_argument("username", nargs="?")
    s.add_argument("--role", default="admin", choices=["viewer", "operator", "admin"])
    s.add_argument("--password", help="se omitido, será pedida")
    s = sub.add_parser("init", help="cria o config.json com token de acesso")
    s.add_argument("--force", action="store_true")
    s = sub.add_parser("run", help="sobe o servidor, o painel e a análise contínua")
    s.add_argument("--open", action="store_true", help="abre o painel no navegador")
    sub.add_parser("open", help="abre o painel no navegador")
    sub.add_parser("run-once", help="roda os detectores uma vez e mostra os alertas")
    s = sub.add_parser("report", help="gera um relatório")
    s.add_argument("--client", required=True)
    s.add_argument("--days", type=float, default=1)
    s.add_argument("--format", choices=["html", "md"], default="html")
    s.add_argument("--out")
    s.add_argument("--no-llm", action="store_true")
    s = sub.add_parser("import-csv", help="importa relatório CSV exportado do iDSecure")
    s.add_argument("--client", required=True)
    s.add_argument("file")
    s.add_argument("--map", action="append", default=[], help="campo=Coluna (ts, user, user_id, device, result)")
    s.add_argument("--anonymize", action="store_true")
    s.add_argument("--dry-run", action="store_true")
    s = sub.add_parser("simulate", help="cria um banco de demonstração (demo.db) e roda os detectores")
    s.add_argument("--serve", action="store_true", help="depois sobe o painel com os dados da demo")
    s.add_argument("--db", default="demo.db")
    s = sub.add_parser("falar", help="testa a voz do PC (caixas de som)")
    s.add_argument("text", nargs="*", default=["Zentry IA ativado. Estou monitorando o controle de acesso."])
    s = sub.add_parser("chat", help="conversa no terminal com o Zentry (IA, se houver chave de API)")
    s.add_argument("--client", required=True)
    s = sub.add_parser("ask", help="pergunta ao assistente (mesmo motor da voz)")
    s.add_argument("--client", required=True)
    s.add_argument("text", nargs="+")
    args = p.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")
    args.config = args.config or str(config_file())

    if args.cmd == "setup":
        created = not os.path.exists(args.config)
        if created:
            init_config(args.config)
        cfg = load_config(args.config)
        App(cfg, config_path=args.config)  # cria/atualiza o banco
        for sub_dir in (cfg.get('plugins_dir', 'plugins'), cfg.get('backups_dir', 'backups'), cfg.get('logs_dir', 'logs')):
            os.makedirs(os.path.join(cfg['_home'], sub_dir), exist_ok=True)
        print(f"Zentry pronto. Pasta de dados: {cfg['_home']}" + (" (configuração criada)" if created else ""))
        return 0

    if args.cmd == "init":
        cfg = init_config(args.config, args.force)
        print(f"Criado {args.config}. Token do painel: {cfg['server']['token']}")
        print("Edite os clientes/equipamentos e rode: python3 -m zentry run")
        return 0

    if args.cmd == "simulate":
        base = load_config(args.config) if os.path.exists(args.config) else load_config_defaults()
        cfg = demo_config(base)
        cfg["db_path"] = args.db
        for ext in ("", "-wal", "-shm"):
            if os.path.exists(args.db + ext):
                os.remove(args.db + ext)
        if not cfg["server"].get("token"):
            cfg["server"]["token"] = "demo"
        app = App(cfg)
        now = build_demo(app.store, cfg, now=time.time())
        created = app.engine.run_once(now=now, notify=False)
        print(f"Demo criada em {args.db}: {len(created)} alertas gerados.\n")
        for a in sorted(created, key=lambda r: (r["severity"] != "critico", r["id"])):
            print(f"  #{a['id']:<3} [{a['severity'].upper():<7}] {a['title']}")
        if args.serve:
            from .auth import Auth
            Auth(app.store, cfg).create_account("demo", "zentry-demo", "admin", "Demo")
            print(f"\nPainel: http://127.0.0.1:{cfg['server']['port']}/   usuário: demo   senha: zentry-demo")
            serve(app, open_browser=True)
        return 0

    if args.cmd == "falar":
        from . import voice
        ok = voice.speak(" ".join(args.text), wait=True)
        print("Falou pelas caixas de som." if ok else "Não consegui falar: sem sintetizador de voz neste PC.")
        return 0 if ok else 1

    cfg = load_config(args.config)
    app = App(cfg, config_path=args.config)

    if args.cmd == "backup":
        from .maintenance import make_backup
        print("Backup criado:", make_backup(app))
    elif args.cmd == "users":
        import getpass
        from .auth import Auth, AuthError
        au = Auth(app.store, cfg)
        try:
            if args.action == "list":
                for a in au.list_accounts():
                    print(f"{a['username']:<20} {a['role']:<9}{' (desativado)' if a['disabled'] else ''}")
            else:
                if not args.username:
                    print("Informe o nome do usuário.")
                    return 2
                pw = args.password or getpass.getpass("Senha: ")
                if args.action == "add":
                    au.create_account(args.username, pw, args.role)
                else:
                    au.set_password(args.username, pw)
                au.audit("cli", f"users.{args.action}", args.username)
                print("OK.")
        except AuthError as e:
            print("Erro:", e)
            return 1
    elif args.cmd == "run":
        serve(app, open_browser=args.open)
    elif args.cmd == "open":
        import webbrowser
        webbrowser.open(f"http://127.0.0.1:{cfg['server']['port']}/")
    elif args.cmd == "run-once":
        for a in app.engine.run_once():
            print(f"#{a['id']} [{a['severity'].upper()}] {a['title']}")
    elif args.cmd == "report":
        out = report.generate(app.store, cfg, args.client, args.days, fmt=args.format, use_llm=not args.no_llm)
        if args.out:
            with open(args.out, "w", encoding="utf-8") as f:
                f.write(out)
            print(f"Relatório salvo em {args.out}")
        else:
            print(out)
    elif args.cmd == "import-csv":
        mapping = dict(m.split("=", 1) for m in args.map)
        r = import_csv(app.store, cfg, args.client, args.file, mapping, args.anonymize, args.dry_run)
        print(r)
    elif args.cmd == "chat":
        from . import assistant
        print("Zentry IA — converse em português. Digite 'sair' para encerrar.")
        while True:
            try:
                q = input("\nvocê> ").strip()
            except (EOFError, KeyboardInterrupt):
                break
            if q.lower() in ("sair", "exit", "quit"):
                break
            if q:
                r = assistant.answer(app, args.client, q, session="cli")
                print("zentry>", r["text"], "" if r.get("mode") != "regras" else "\n(modo offline: regras locais)")
    elif args.cmd == "ask":
        from . import assistant
        print(assistant.answer(app, args.client, " ".join(args.text))["text"])
    return 0


def load_config_defaults():
    from .config import DEFAULTS, deep_merge
    return deep_merge(DEFAULTS, {})


if __name__ == "__main__":
    sys.exit(main())
