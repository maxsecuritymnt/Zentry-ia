/* Zentry IA — painel. Sem bibliotecas externas; todo conteúdo dinâmico entra por textContent. */
(function () {
'use strict';

const Z = window.Z = { pages: {}, state: { user: null, client: null, clients: [], overview: null }, timers: [] };
const NS = 'http://www.w3.org/2000/svg';

/* ---------------------------------------------------------------- DOM helpers */
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'value') el.value = v;
    else if (k === 'checked' || k === 'disabled' || k === 'selected') el[k] = !!v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  add(el, kids);
  return el;
}
function add(el, kids) {
  for (const k of [].concat(kids).flat(Infinity)) {
    if (k == null || k === false) continue;
    el.append(k.nodeType ? k : document.createTextNode(String(k)));
  }
  return el;
}
function s(tag, attrs, ...kids) {
  const el = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs || {})) el.setAttribute(k, v);
  for (const k of [].concat(kids).flat(Infinity)) if (k != null) el.append(k.nodeType ? k : document.createTextNode(String(k)));
  return el;
}
const $ = (sel, root) => (root || document).querySelector(sel);
function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }
Z.h = h; Z.s = s; Z.$ = $; Z.clear = clear;

const ICONS = {
  command: 'M3 12a9 9 0 1 0 18 0 9 9 0 0 0-18 0M12 7v5l3 2',
  alert: 'M12 3l10 18H2zM12 10v5M12 18h.01',
  device: 'M4 4h16v12H4zM8 20h8M12 16v4',
  people: 'M16 19v-1a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v1M9.5 10a3 3 0 1 0 0-6 3 3 0 0 0 0 6M21 19v-1a4 4 0 0 0-3-3.8M16 4.2a3 3 0 0 1 0 5.6',
  live: 'M3 12h4l3-8 4 16 3-8h4',
  brain: 'M9 4a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 2 5 3 3 0 0 0 6 1V4a3 3 0 0 0-3 0M15 4a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-2 5 3 3 0 0 1-6 1',
  report: 'M6 3h9l4 4v14H6zM14 3v5h5M9 13h6M9 17h6',
  chat: 'M4 5h16v11H9l-5 4zM8 9h8M8 12h5',
  gear: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6M19 12l2-1-2-4-2 .5-1.5-1 .2-2.2-4-1-1 2h-2l-1-2-4 1 .2 2.2-1.5 1L3 7l-2 4 2 1v2l-2 1 2 4 2-.5 1.5 1-.2 2.2 4 1 1-2h2l1 2 4-1-.2-2.2 1.5-1 2 .5 2-4-2-1z',
  pulse: 'M4 13h4l2-6 4 12 2-6h4',
  face: 'M5 8V6a1 1 0 0 1 1-1h2M16 5h2a1 1 0 0 1 1 1v2M19 16v2a1 1 0 0 1-1 1h-2M8 19H6a1 1 0 0 1-1-1v-2M9 10v1M15 10v1M9.5 15a3.5 3 0 0 0 5 0',
  turnstile: 'M12 3v18M5 8l14 8M19 8L5 16',
};
function icon(name) { return s('svg', { viewBox: '0 0 24 24', 'aria-hidden': 'true' }, s('path', { d: ICONS[name] || ICONS.command })); }
Z.icon = icon;

/* ---------------------------------------------------------------- utilidades */
const SEV = { critico: 'Crítico', alto: 'Alto', atencao: 'Atenção', info: 'Info' };
const KIND = { grant: 'Liberado', deny: 'Negado', not_identified: 'Não identificado', turn: 'Giro', door_open: 'Porta aberta', door_close: 'Porta fechada', alarm: 'Alarme', other: 'Outro' };
const KIND_CLS = { grant: 'c-green', deny: 'c-red', not_identified: 'c-amber', turn: 'c-cyan', door_open: 'c-amber', door_close: 'dim', alarm: 'c-mag' };
const fmt = {
  n: v => new Intl.NumberFormat('pt-BR').format(v ?? 0),
  pct: v => ((v || 0) * 100).toFixed(1).replace('.', ',') + '%',
  dt: ts => ts ? new Date(ts * 1000).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) : '—',
  tm: ts => ts ? new Date(ts * 1000).toLocaleTimeString('pt-BR') : '—',
  ago: sec => {
    if (sec == null) return 'nunca';
    if (sec < 90) return Math.round(sec) + ' s';
    if (sec < 5400) return Math.round(sec / 60) + ' min';
    if (sec < 172800) return (sec / 3600).toFixed(1).replace('.', ',') + ' h';
    return Math.round(sec / 86400) + ' dias';
  },
};
Z.fmt = fmt; Z.SEV = SEV; Z.KIND = KIND;
const sevBadge = sev => h('span', { class: 'badge b-' + sev }, SEV[sev] || sev);
Z.sevBadge = sevBadge;
const store = {
  get(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } },
  set(k, v) { try { sessionStorage.setItem(k, v); } catch (e) { /* sem armazenamento: segue sem lembrar */ } },
};
Z.store = store;

async function api(method, path, body) {
  const opt = { method, headers: { 'X-Requested-With': 'zentry' }, credentials: 'same-origin' };
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  let res;
  try { res = await fetch(path, opt); } catch (e) { throw new Error('Sem conexão com o servidor Zentry. Verifique se a janela preta (iniciar_zentry.bat) continua aberta; se ela fechou, abra o arquivo de novo e recarregue esta página.'); }
  const ct = res.headers.get('content-type') || '';
  const data = ct.includes('json') ? await res.json() : await res.text();
  if (res.status === 401 && path !== '/api/login' && path !== '/api/session') { Z.state.user = null; route(); }
  if (!res.ok) throw new Error((data && data.error) || ('Erro ' + res.status));
  return data;
}
const q = (path, extra) => path + (path.includes('?') ? '&' : '?') + 'client=' + encodeURIComponent(Z.state.client || '') + (extra || '');
Z.api = api; Z.q = q;

function toast(text, sev, ms) {
  const t = h('div', { class: 'toast ' + (sev || ''), role: 'status' }, text);
  $('#toasts').append(t);
  setTimeout(() => t.remove(), ms || 5000);
}
Z.toast = toast;

function isAdmin() { return Z.state.user && Z.state.user.role === 'admin'; }
function canAct() { return Z.state.user && Z.state.user.role !== 'viewer'; }
Z.isAdmin = isAdmin; Z.canAct = canAct;

/* ---------------------------------------------------------------- voz */
const Voice = Z.voice = {
  SR: window.SpeechRecognition || window.webkitSpeechRecognition,
  listening: false, speakOn: store.get('z.speak') !== '0', wake: store.get('z.wake') !== '0', rec: null, awaiting: false, onState: null, onCommand: null,
  state(s_) { this.status = s_; if (this.onState) this.onState(s_); },
  speak(text) {
    if (!this.speakOn || !('speechSynthesis' in window) || !text) return;
    try {
      const u = new SpeechSynthesisUtterance(String(text).slice(0, 600));
      u.lang = 'pt-BR';
      const v = speechSynthesis.getVoices().find(x => x.lang && x.lang.toLowerCase().startsWith('pt'));
      if (v) u.voice = v;
      const was = this.listening;
      if (was) this.stop(true);
      u.onstart = () => this.state('speaking');
      u.onend = u.onerror = () => { this.state(this.listening ? 'listening' : 'idle'); if (was) this.start(); };
      speechSynthesis.cancel(); speechSynthesis.speak(u);
    } catch (e) { /* voz do navegador indisponível */ }
  },
  start() {
    if (!this.SR) { toast('Este navegador não tem reconhecimento de voz. Use o Chrome ou o Edge.', 'atencao'); return false; }
    if (this.rec) return true;
    const r = this.rec = new this.SR();
    r.lang = 'pt-BR'; r.continuous = true; r.interimResults = false;
    r.onresult = ev => {
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        if (!ev.results[i].isFinal) continue;
        this.heard(ev.results[i][0].transcript.trim());
      }
    };
    r.onerror = e => { if (e.error === 'not-allowed') { toast('Permita o uso do microfone para falar com o Zentry.', 'atencao'); this.stop(); } };
    r.onend = () => { this.rec = null; if (this.listening) { try { this.start(); } catch (e) { /* tenta de novo no próximo clique */ } } };
    this.listening = true;
    try { r.start(); } catch (e) { return false; }
    this.state('listening');
    return true;
  },
  stop(keepFlag) {
    if (!keepFlag) this.listening = false;
    if (this.rec) { try { this.rec.stop(); } catch (e) { /* já parado */ } this.rec = null; }
    if (!keepFlag) this.state('idle');
  },
  heard(text) {
    if (!text) return;
    let cmd = text;
    if (this.wake) {
      const m = text.toLowerCase().match(/(zentry|zentri|centri|sentri)\b[\s,.:!-]*/);
      if (m) { cmd = text.slice(m.index + m[0].length).trim(); if (!cmd) { this.awaiting = true; this.speak('Pois não?'); return; } }
      else if (this.awaiting) this.awaiting = false;
      else return;
    }
    this.awaiting = false;
    if (this.onCommand) this.onCommand(cmd, true);
  },
};

/* ---------------------------------------------------------------- gráficos SVG */
function areaChart(points) {
  const W = 720, H = 220, P = { l: 34, r: 10, t: 10, b: 24 };
  const max = Math.max(5, ...points.map(p => p.grant + p.fail));
  const x = i => P.l + i * (W - P.l - P.r) / Math.max(1, points.length - 1);
  const y = v => H - P.b - v * (H - P.t - P.b) / max;
  const line = key => points.map((p, i) => (i ? 'L' : 'M') + x(i).toFixed(1) + ' ' + y(p[key]).toFixed(1)).join(' ');
  const area = key => line(key) + ` L${x(points.length - 1).toFixed(1)} ${y(0)} L${x(0)} ${y(0)}Z`;
  const svg = s('svg', { class: 'chart', viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': 'Passagens por hora nas últimas 24 horas' });
  svg.append(s('defs', {},
    s('linearGradient', { id: 'gC', x1: 0, y1: 0, x2: 0, y2: 1 }, s('stop', { offset: '0', 'stop-color': '#22e4ff', 'stop-opacity': '.55' }), s('stop', { offset: '1', 'stop-color': '#22e4ff', 'stop-opacity': '0' })),
    s('linearGradient', { id: 'gM', x1: 0, y1: 0, x2: 0, y2: 1 }, s('stop', { offset: '0', 'stop-color': '#ff3d81', 'stop-opacity': '.5' }), s('stop', { offset: '1', 'stop-color': '#ff3d81', 'stop-opacity': '0' }))));
  for (let k = 0; k <= 4; k++) {
    const v = Math.round(max * k / 4), yy = y(v);
    svg.append(s('line', { x1: P.l, x2: W - P.r, y1: yy, y2: yy, stroke: 'rgba(120,170,255,.1)' }), s('text', { x: P.l - 6, y: yy + 3, 'text-anchor': 'end' }, v));
  }
  points.forEach((p, i) => { if (i % 4 === 0) svg.append(s('text', { x: x(i), y: H - 6, 'text-anchor': 'middle' }, p.label)); });
  svg.append(s('path', { d: area('grant'), fill: 'url(#gC)' }), s('path', { d: line('grant'), fill: 'none', stroke: '#22e4ff', 'stroke-width': 2 }),
    s('path', { d: area('fail'), fill: 'url(#gM)' }), s('path', { d: line('fail'), fill: 'none', stroke: '#ff3d81', 'stroke-width': 2 }));
  points.forEach((p, i) => svg.append(s('circle', { cx: x(i), cy: y(p.grant), r: 6, fill: 'transparent' }, s('title', {}, `${p.label}: ${p.grant} liberados, ${p.fail} falhas`))));
  return svg;
}
function heatmap(grid) {
  const days = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
  const W = 720, cw = (W - 36) / 24, ch = 22, H = 7 * ch + 22;
  const max = Math.max(1, ...grid.flat());
  const svg = s('svg', { class: 'chart', viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': 'Mapa de calor de acessos por dia da semana e hora' });
  grid.forEach((row, d) => {
    svg.append(s('text', { x: 0, y: d * ch + 15 }, days[d]));
    row.forEach((v, hr) => svg.append(s('rect', { x: 36 + hr * cw, y: d * ch, width: cw - 2, height: ch - 2, rx: 4,
      fill: '#22e4ff', 'fill-opacity': v ? (0.1 + 0.9 * v / max).toFixed(2) : 0.04 }, s('title', {}, `${days[d]} ${hr}h: ${v} acessos`))));
  });
  for (let hr = 0; hr < 24; hr += 3) svg.append(s('text', { x: 36 + hr * cw, y: H - 4 }, hr + 'h'));
  return svg;
}
function ring(value) {
  const R = 62, C = 2 * Math.PI * R, col = value >= 80 ? '#2cff9a' : value >= 50 ? '#ffb020' : '#ff4d5e';
  return h('div', { class: 'ring', role: 'img', 'aria-label': 'Saúde da operação ' + value + ' de 100' },
    s('svg', { viewBox: '0 0 150 150' }, s('circle', { cx: 75, cy: 75, r: R, fill: 'none', stroke: 'rgba(120,170,255,.14)', 'stroke-width': 10 }),
      s('circle', { cx: 75, cy: 75, r: R, fill: 'none', stroke: col, 'stroke-width': 10, 'stroke-linecap': 'round', 'stroke-dasharray': `${C * value / 100} ${C}`, style: `filter:drop-shadow(0 0 8px ${col})` })),
    h('div', { class: 'n' }, h('div', {}, String(value), h('small', {}, 'SAÚDE'))));
}
Z.areaChart = areaChart; Z.heatmap = heatmap;

/* ---------------------------------------------------------------- alerta (gaveta) */
async function openAlert(id) {
  const scrim = h('div', { class: 'scrim', onclick: close });
  const box = h('aside', { class: 'drawer', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Detalhe do alerta' }, h('div', { class: 'dim' }, 'Carregando…'));
  document.body.append(scrim, box);
  function close() { scrim.remove(); box.remove(); document.removeEventListener('keydown', esc); }
  function esc(e) { if (e.key === 'Escape') close(); }
  document.addEventListener('keydown', esc);
  try {
    const a = await api('GET', '/api/alerts/' + id);
    clear(box);
    add(box, [
      h('div', { class: 'row' }, sevBadge(a.severity), h('span', { class: 'badge b-' + (a.status === 'new' ? 'info' : 'ok') }, a.status === 'new' ? 'Aberto' : 'Resolvido'), h('span', { class: 'sp' }), h('button', { class: 'btn sm', onclick: close }, 'Fechar')),
      h('h3', {}, a.title),
      h('p', { class: 'muted' }, a.detail || ''),
      h('dl', { class: 'kv' },
        h('dt', {}, 'Detector'), h('dd', {}, a.detector_title), h('dt', {}, 'O que faz'), h('dd', { class: 'muted' }, a.detector_description),
        h('dt', {}, 'Equipamento'), h('dd', {}, a.device_name || '—'), h('dt', {}, 'Pessoa'), h('dd', {}, a.user_label || '—'),
        h('dt', {}, 'Primeira vez'), h('dd', {}, fmt.dt(a.created_at)), h('dt', {}, 'Última vez'), h('dd', {}, fmt.dt(a.last_seen_at)),
        h('dt', {}, 'Ocorrências'), h('dd', {}, String(a.count))),
      canAct() ? h('div', { class: 'row' }, a.status === 'new'
        ? h('button', { class: 'btn pri', onclick: () => act('resolved') }, 'Marcar como resolvido')
        : h('button', { class: 'btn', onclick: () => act('new') }, 'Reabrir'),
        h('button', { class: 'btn', onclick: () => { close(); location.hash = '#/chat?ask=' + encodeURIComponent('Explique o alerta ' + a.id); } }, 'Perguntar ao Zentry')) : null,
      h('div', { class: 'hr' }),
      h('h2', { class: 'muted', style: 'font-size:12px;letter-spacing:.14em;text-transform:uppercase' }, 'Eventos próximos'),
      a.events.length ? h('table', {}, h('tbody', {}, a.events.map(e => h('tr', {}, h('td', { class: 'mono dim' }, fmt.tm(e.ts)), h('td', { class: KIND_CLS[e.kind] || '' }, KIND[e.kind] || e.kind), h('td', {}, e.device_name || ''), h('td', { class: 'muted' }, e.user || ''))))) : h('div', { class: 'empty' }, 'Sem eventos próximos.'),
    ]);
    async function act(status) {
      try { await api('POST', `/api/alerts/${id}/feedback`, { status }); toast(status === 'resolved' ? 'Alerta resolvido.' : 'Alerta reaberto.'); close(); refreshPage(); } catch (e) { toast(e.message, 'critico'); }
    }
  } catch (e) { clear(box); add(box, [h('div', { class: 'err' }, e.message), h('button', { class: 'btn', onclick: close }, 'Fechar')]); }
}
Z.openAlert = openAlert;

function alertItem(a) {
  return h('button', { class: 'aitem s-' + a.severity, onclick: () => openAlert(a.id) },
    sevBadge(a.severity),
    h('div', { style: 'flex:1;min-width:0' }, h('div', { class: 't' }, a.title), h('div', { class: 'd' }, [a.device_name, a.detail].filter(Boolean).join(' — ').slice(0, 160))),
    h('span', { class: 'dim mono', style: 'font-size:12px' }, fmt.dt(a.created_at)));
}
Z.alertItem = alertItem;

/* ---------------------------------------------------------------- páginas */
function kpi(label, value, sub, cls) { return h('div', { class: 'card kpi' }, h('div', { class: 'l' }, label), h('div', { class: 'v ' + (cls || '') }, value), sub ? h('div', { class: 's' }, sub) : null); }
let currentRender = null;
function refreshPage() { if (currentRender) currentRender(true); }

Z.pages.command = async function (soft, root) {
  const [ov, tl, hm, dv] = await Promise.all([api('GET', q('/api/overview')), api('GET', q('/api/timeline')), api('GET', q('/api/heatmap')), api('GET', q('/api/devices'))]);
  Z.state.overview = ov; updateBadges();
  clear(root);
  add(root, [
    h('div', { class: 'grid g4' },
      h('div', { class: 'card', style: 'display:flex;align-items:center;gap:16px' }, ring(ov.health), h('div', {}, h('div', { class: 'muted' }, 'Operação'), h('div', { class: 'mono', style: 'font-size:15px' }, ov.health >= 80 ? 'Estável' : ov.health >= 50 ? 'Em atenção' : 'Crítica'))),
      kpi('Passagens liberadas · 24 h', fmt.n(ov.grants_24h), `${fmt.n(ov.turns_24h)} giros de catraca`, 'c-cyan'),
      kpi('Falhas · 24 h', fmt.n(ov.fails_24h), `taxa de ${fmt.pct(ov.fail_rate)}`, ov.fail_rate > 0.3 ? 'c-red' : 'c-mag'),
      kpi('Alertas abertos', fmt.n(ov.open_total), `${ov.open_critical} críticos · ${ov.open_attention} de atenção`, ov.open_critical ? 'c-red' : ov.open_total ? 'c-amber' : 'c-green')),
    h('div', { class: 'grid g21', style: 'margin-top:16px' },
      h('div', { class: 'card' }, h('h2', {}, 'Fluxo das últimas 24 horas'), areaChart(tl.points),
        h('div', { class: 'legend' }, h('span', {}, h('i', { style: 'background:#22e4ff' }), 'Liberados'), h('span', {}, h('i', { style: 'background:#ff3d81' }), 'Falhas'))),
      h('div', { class: 'card' }, h('h2', {}, 'Análise do Zentry', ov.llm ? h('span', { class: 'badge b-info' }, 'IA ativa') : h('span', { class: 'badge b-ok' }, 'offline')),
        ov.analysis.length ? ov.analysis.map(t => h('div', { class: 'insight' }, t)) : h('div', { class: 'empty' }, 'Sem dados ainda.'))),
    h('div', { class: 'grid g21', style: 'margin-top:16px' },
      h('div', { class: 'card' }, h('h2', {}, 'Alertas que pedem atenção', h('span', { class: 'sp' }), h('a', { href: '#/alerts' }, 'ver todos')),
        ov.top_alerts.length ? h('div', { class: 'alist' }, ov.top_alerts.map(a => alertItem({ ...a, device_name: null }))) : h('div', { class: 'empty' }, 'Nenhum alerta aberto. Tudo certo por aqui.')),
      h('div', { class: 'card' }, h('h2', {}, 'Aprendizado'),
        h('div', { class: 'kpi' }, h('div', { class: 'v c-vio' }, fmt.n(ov.patterns_known)), h('div', { class: 'l' }, 'padrões conhecidos')),
        h('div', { class: 'insight' }, `${fmt.n(ov.patterns_new)} novos nas últimas 24 h`), h('div', { class: 'insight' }, `${fmt.n(ov.repeats_ignored)} repetições iguais ignoradas`),
        h('div', { class: 'note', style: 'margin-top:12px' }, 'Alerta igual a um já conhecido não se repete; qualquer coisa nova o Zentry aprende e avisa.'))),
    h('div', { class: 'grid g2', style: 'margin-top:16px' },
      h('div', { class: 'card' }, h('h2', {}, 'Mapa de calor · 4 semanas'), heatmap(hm.grid)),
      h('div', { class: 'card' }, h('h2', {}, 'Equipamentos', h('span', { class: 'sp' }), h('a', { href: '#/devices' }, 'detalhes')),
        dv.devices.length ? h('div', { class: 'grid', style: 'gap:10px' }, dv.devices.slice(0, 6).map(deviceCard)) : h('div', { class: 'empty' }, 'Nenhum equipamento ainda. Cadastre em Configurações → Clientes.'))),
  ]);
};

function deviceCard(d) {
  return h('div', { class: 'dev' + (d.offline ? ' off' : '') },
    h('div', { class: 'ic' }, icon(d.type === 'turnstile' ? 'turnstile' : 'face')),
    h('div', { style: 'flex:1;min-width:0' }, h('div', { style: 'font-weight:600' }, d.name),
      h('div', { class: 'dim', style: 'font-size:12px' }, [d.ip, d.zone, d.direction === 'in' ? 'entrada' : d.direction === 'out' ? 'saída' : null].filter(Boolean).join(' · ') || 'sem IP (recebe push)'),
      h('div', { class: 'bar', style: 'margin-top:8px' }, h('i', { style: `width:${Math.min(100, Math.round(d.fail_rate * 100))}%;background:linear-gradient(90deg,var(--magenta),var(--red))` }))),
    h('div', { style: 'text-align:right' }, h('span', { class: 'dot ' + (d.offline ? 'bad pulse' : d.monitored ? '' : 'warn') }),
      h('div', { class: 'dim', style: 'font-size:11px;margin-top:4px' }, d.offline ? 'offline' : fmt.ago(d.last_seen_age)),
      h('div', { class: 'mono', style: 'font-size:12px' }, fmt.n(d.attempts) + ' tent.'),
      d.ip ? h('div', { style: 'margin-top:8px' }, h('button', { class: 'btn sm', onclick: () => openDeviceTools(d) }, '📷 Câmera / SIP')) : null));
}

function openDeviceTools(d) {
  const base = '/api/devices/' + encodeURIComponent(d.id);
  const scrim = h('div', { class: 'scrim', onclick: close });
  const img = h('img', { alt: 'Câmera do equipamento', style: 'width:100%;max-height:60vh;object-fit:contain;background:#000;border-radius:10px;min-height:120px' });
  const camMsg = h('div', { class: 'muted', style: 'margin-top:6px' }, 'Carregando imagem…');
  let cam = 'rgb', timer = null, busy = false, closed = false;
  const grab = () => {
    if (busy || closed) return; busy = true;
    img.onload = () => { busy = false; camMsg.textContent = 'Ao vivo (atualiza sozinho) · ' + new Date().toLocaleTimeString('pt-BR'); };
    img.onerror = () => { busy = false; camMsg.textContent = 'Não foi possível obter a imagem (confira IP, usuário e senha do equipamento).'; };
    img.src = q(base + '/snapshot', '&camera=' + cam + '&t=' + Date.now());
  };
  timer = setInterval(grab, 1500); grab();
  const rtsp = h('div', { class: 'muted' }, 'Carregando…');
  async function loadRtsp() {
    try {
      const r = await api('GET', q(base + '/camera'));
      rtsp.replaceChildren(h('div', {}, r.enabled ? 'Vídeo RTSP ligado.' : 'Vídeo RTSP desligado.'),
        h('div', { class: 'mono', style: 'word-break:break-all;margin:6px 0' }, r.url), h('div', { class: 'dim' }, 'Abra no VLC (Mídia → Abrir fluxo de rede). Codec: ' + (r.codec || 'mjpeg') + (r.has_login ? ' · exige usuário/senha' : '')),
        isAdmin() ? h('button', { class: 'btn sm', style: 'margin-top:8px', onclick: async () => {
          try { await api('POST', q(base + '/rtsp'), { enabled: !r.enabled }); toast('Salvo. Reinicie o equipamento para valer.'); loadRtsp(); } catch (e) { toast(e.message, 'critico'); } } }, r.enabled ? 'Desligar RTSP' : 'Ligar RTSP (exige reiniciar o facial)') : null);
    } catch (e) { rtsp.textContent = e.message; }
  }
  loadRtsp();
  const sipBox = h('div', {});
  const target = h('input', { class: 'input', placeholder: 'Ramal ou número para ligar' });
  const callMsg = h('div', { class: 'muted' });
  const call = async (path, body) => { try { const r = await api('POST', q(base + path), body || {}); callMsg.textContent = 'OK'; return r; } catch (e) { callMsg.textContent = e.message; } };
  async function loadSip() {
    if (!isAdmin()) { sipBox.append(h('div', { class: 'muted' }, 'Configurar o SIP exige administrador.')); return; }
    try {
      const { sip } = await api('GET', q(base + '/sip'));
      const f = {};
      const inp = (k, label, type) => h('label', { class: 'f' }, h('span', {}, label), f[k] = h('input', { class: 'input', type: type || 'text', value: sip[k] ?? '', autocomplete: 'off' }));
      const chk = (k, label) => h('label', { class: 'chk' }, f[k] = h('input', { type: 'checkbox', checked: String(sip[k]) === '1' }), label);
      sipBox.replaceChildren(h('div', { class: 'grid g2' }, chk('enabled', 'SIP ligado'), chk('video_enabled', 'Vídeo na chamada (reiniciar o facial)'),
        inp('server_ip', 'Servidor SIP (IP)'), inp('server_port', 'Porta'), inp('login', 'Usuário SIP'), inp('password', 'Senha SIP (máx. 16)', 'password'), inp('branch', 'Ramal deste facial'),
        chk('open_door_enabled', 'Abrir porta por tecla durante a chamada'), inp('open_door_command', 'Comando de abertura (ex.: #1)'), chk('auto_answer_enabled', 'Atender automaticamente')),
        h('button', { class: 'btn', style: 'margin-top:10px', onclick: async () => {
          const body = {}; for (const [k, el] of Object.entries(f)) body[k] = el.type === 'checkbox' ? el.checked : el.value.trim();
          try { const r = await api('POST', q(base + '/sip'), body); toast('SIP salvo.' + (r.restart_needed ? ' Reinicie o facial para o vídeo.' : '')); } catch (e) { toast(e.message, 'critico'); } } }, 'Salvar SIP'));
    } catch (e) { sipBox.replaceChildren(h('div', { class: 'muted' }, e.message)); }
  }
  loadSip();
  const box = h('aside', { class: 'drawer', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Câmera e SIP' },
    h('div', { class: 'row' }, h('strong', {}, d.name), h('span', { class: 'sp' }), h('button', { class: 'btn sm', onclick: close }, 'Fechar')),
    h('h3', {}, 'Câmera'), img, camMsg,
    h('div', { class: 'row', style: 'margin-top:8px' }, h('button', { class: 'btn sm', onclick: () => { cam = cam === 'rgb' ? 'ir' : 'rgb'; grab(); toast(cam === 'ir' ? 'Câmera infravermelha' : 'Câmera colorida'); } }, 'Alternar colorida / infravermelho')),
    h('h3', {}, 'Vídeo contínuo (RTSP)'), rtsp,
    h('h3', {}, 'Interfone SIP'), h('div', { class: 'dim' }, 'Exige a licença PRO do iDFace e um servidor/PABX SIP.'), sipBox,
    h('div', { class: 'row', style: 'margin-top:12px' }, target, h('button', { class: 'btn', onclick: () => call('/sip/call', { target: target.value.trim() }) }, 'Ligar'), h('button', { class: 'btn danger', onclick: () => call('/sip/hangup') }, 'Encerrar')), callMsg);
  document.body.append(scrim, box);
  function close() { closed = true; clearInterval(timer); scrim.remove(); box.remove(); }
}

Z.pages.alerts = async function (soft, root) {
  const filter = Z.state.alertFilter || { status: 'new', severity: '' };
  Z.state.alertFilter = filter;
  const r = await api('GET', q('/api/alerts', `&status=${filter.status}${filter.severity ? '&severity=' + filter.severity : ''}`));
  clear(root);
  const sel = (key, opts) => h('select', { style: 'width:auto', onchange: e => { filter[key] = e.target.value; refreshPage(); } },
    opts.map(([v, l]) => h('option', { value: v, selected: filter[key] === v }, l)));
  add(root, h('div', { class: 'card' },
    h('div', { class: 'row', style: 'margin-bottom:14px' }, sel('status', [['new', 'Abertos'], ['resolved', 'Resolvidos'], ['all', 'Todos']]),
      sel('severity', [['', 'Todas as severidades'], ['critico', 'Crítico'], ['alto', 'Alto'], ['atencao', 'Atenção'], ['info', 'Info']]),
      h('span', { class: 'sp' }), h('span', { class: 'dim' }, r.alerts.length + ' alerta(s)')),
    r.alerts.length ? h('div', { class: 'alist' }, r.alerts.map(a => h('div', { style: 'position:relative' }, alertItem(a),
      a.count > 1 ? h('span', { class: 'badge b-info', style: 'position:absolute;right:12px;bottom:8px' }, a.count + '×') : null))) : h('div', { class: 'empty' }, 'Nada por aqui.')));
};

Z.pages.devices = async function (soft, root) {
  const r = await api('GET', q('/api/devices'));
  clear(root);
  add(root, r.devices.length ? h('div', { class: 'grid g2' }, r.devices.map(deviceCard)) : h('div', { class: 'card empty' }, 'Nenhum equipamento. Cadastre em Configurações → Clientes e equipamentos.'));
};

Z.pages.people = async function (soft, root) {
  const term = Z.state.peopleQ || '';
  const r = await api('GET', q('/api/people', '&q=' + encodeURIComponent(term)));
  clear(root);
  const input = h('input', { class: 'input', placeholder: 'Buscar por nome ou ID…', value: term, style: 'max-width:340px' });
  input.addEventListener('keydown', e => { if (e.key === 'Enter') { Z.state.peopleQ = input.value; refreshPage(); } });
  add(root, h('div', { class: 'card' }, h('div', { class: 'row', style: 'margin-bottom:12px' }, input, h('span', { class: 'dim' }, 'Últimos 30 dias · pressione Enter')),
    r.people.length ? h('div', { class: 'tablewrap' }, h('table', {}, h('thead', {}, h('tr', {}, ['Pessoa', 'ID', 'Acessos', 'Falhas', 'Último acesso'].map(x => h('th', {}, x)))),
      h('tbody', {}, r.people.map(p => h('tr', { class: 'click', onclick: () => { location.hash = '#/chat?ask=' + encodeURIComponent('Histórico de ' + p.name); } },
        h('td', {}, p.name), h('td', { class: 'mono dim' }, p.id), h('td', { class: 'mono' }, p.events_30d), h('td', { class: 'mono ' + (p.fails_30d ? 'c-amber' : 'dim') }, p.fails_30d), h('td', { class: 'dim' }, fmt.dt(p.last))))))) : h('div', { class: 'empty' }, 'Ninguém encontrado.')));
};

Z.pages.live = async function (soft, root, token) {
  clear(root);
  const feed = h('div', { class: 'feed', 'aria-live': 'off' });
  const state = { last: 0, paused: false };
  const pause = h('button', { class: 'btn sm', onclick: () => { state.paused = !state.paused; pause.textContent = state.paused ? 'Retomar' : 'Pausar'; } }, 'Pausar');
  add(root, h('div', { class: 'card' }, h('h2', {}, h('span', { class: 'dot pulse' }), 'Eventos em tempo real', h('span', { class: 'sp' }), pause,
    isAdmin() ? h('button', { class: 'btn sm danger', style: 'margin-left:8px', onclick: async () => {
      if (prompt('Isso apaga TODOS os eventos deste cliente (alertas e padrões aprendidos ficam). Digite APAGAR para confirmar:') !== 'APAGAR') return;
      try { const r = await api('POST', q('/api/events/clear'), { confirm: 'APAGAR' }); feed.replaceChildren(); toast(r.deleted + ' eventos apagados.'); } catch (er) { toast(er.message, 'critico'); } } }, 'Apagar todos') : null), feed));
  async function tick(first) {
    if (state.paused || token.dead) return;
    try {
      const r = await api('GET', q('/api/events', `&after=${state.last}&limit=${first ? 60 : 100}`));
      const evs = r.events.slice().reverse();
      for (const e of evs) {
        if (e.id > state.last) state.last = e.id;
        const row = h('div', { class: 'ev' + (first ? '' : ' new') }, h('span', { class: 'dim' }, fmt.tm(e.ts)), h('span', { class: KIND_CLS[e.kind] || '' }, KIND[e.kind] || e.kind), h('span', { class: 'who' }, e.user_name || (e.user_id ? 'Sem nome' : '—')), h('span', { class: 'dim mono' }, e.user_id ? 'ID ' + e.user_id : ''), h('span', { class: 'muted' }, e.method || ''), h('span', { class: 'muted' }, e.sector || ''), h('span', { class: 'dim' }, e.device_name || ''),
          isAdmin() ? h('button', { class: 'btn sm danger', 'aria-label': 'Excluir evento', title: 'Excluir este evento', onclick: async ev => {
            if (!confirm('Excluir este evento? Isso não pode ser desfeito.')) return;
            try { await api('DELETE', q('/api/events/' + e.id)); row.remove(); } catch (er) { toast(er.message, 'critico'); } } }, '✕') : null);
        feed.prepend(row);
      }
      while (feed.children.length > 300) feed.lastChild.remove();
      if (first && !evs.length) feed.append(h('div', { class: 'empty' }, 'Aguardando eventos dos equipamentos…'));
      else if (evs.length) { const em = $('.empty', feed); if (em) em.remove(); }
    } catch (e) { /* tenta no próximo ciclo */ }
  }
  await tick(true);
  token.timer = setInterval(() => tick(false), 3000);
};

Z.pages.learning = async function (soft, root) {
  const r = await api('GET', q('/api/patterns'));
  clear(root);
  add(root, [
    h('div', { class: 'note', style: 'margin-bottom:16px' }, 'Cada situação diferente vira um padrão conhecido. Se acontecer de novo com as mesmas características, o alerta não se repete; se for algo novo, o Zentry aprende e avisa.'),
    h('div', { class: 'card' }, h('h2', {}, fmt.n(r.total) + ' padrões aprendidos'),
      r.patterns.length ? h('div', { class: 'tablewrap' }, h('table', {}, h('thead', {}, h('tr', {}, ['Detector', 'Assinatura', 'Primeira vez', 'Última vez', 'Vezes'].map(x => h('th', {}, x)))),
        h('tbody', {}, r.patterns.map(p => h('tr', { class: p.last_alert_id ? 'click' : '', onclick: () => p.last_alert_id && openAlert(p.last_alert_id) },
          h('td', {}, p.detector), h('td', { class: 'mono dim', style: 'max-width:340px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }, p.signature), h('td', { class: 'dim' }, fmt.dt(p.first_seen)), h('td', { class: 'dim' }, fmt.dt(p.last_seen)), h('td', { class: 'mono' }, p.times)))))) : h('div', { class: 'empty' }, 'Ainda não há padrões.')),
  ]);
};

Z.pages.reports = async function (soft, root) {
  clear(root);
  const days = h('select', { style: 'width:auto' }, [['1', 'Últimas 24 h'], ['7', 'Últimos 7 dias'], ['30', 'Últimos 30 dias']].map(([v, l]) => h('option', { value: v }, l)));
  const frame = h('iframe', { sandbox: '', title: 'Relatório', style: 'width:100%;height:70vh;border:1px solid var(--line);border-radius:12px;background:#fff' });
  let url = '';
  const load = async () => {
    try {
      const res = await fetch(q('/api/report', '&days=' + days.value + '&format=html'), { credentials: 'same-origin' });
      if (!res.ok) throw new Error('falha ao gerar');
      frame.srcdoc = await res.text();
      url = q('/api/report', '&days=' + days.value + '&format=html');
    } catch (e) { toast(e.message, 'critico'); }
  };
  days.addEventListener('change', load);
  add(root, h('div', { class: 'card' }, h('div', { class: 'row', style: 'margin-bottom:12px' }, days,
    h('button', { class: 'btn', onclick: () => { if (url) window.open(url, '_blank', 'noopener'); } }, 'Abrir em nova aba / imprimir'), h('span', { class: 'sp' }), h('span', { class: 'dim' }, 'Gerado na hora com os dados reais')), frame));
  load();
};

Z.pages.chat = async function (soft, root, token) {
  clear(root);
  const sid = store.get('z.sid') || (() => { const v = Math.random().toString(36).slice(2, 10); store.set('z.sid', v); return v; })();
  const msgs = h('div', { class: 'msgs', 'aria-live': 'polite' });
  const input = h('input', { class: 'input', placeholder: 'Pergunte ou dê uma ordem… ex.: "o que aconteceu hoje?"', 'aria-label': 'Mensagem' });
  const orb = h('button', { class: 'orb off', 'aria-label': 'Ativar ou desativar o microfone', title: 'Clique para falar com o Zentry' });
  const status = h('div', { class: 'muted' }, 'Microfone desligado');
  function say(who, text, meta) { msgs.append(h('div', { class: 'msg ' + who }, text, meta ? h('span', { class: 'm' }, meta) : null)); msgs.scrollTop = msgs.scrollHeight; }
  async function ask(text, spoken) {
    text = String(text || '').trim(); if (!text) return;
    say('u', text); input.value = ''; Voice.state('thinking');
    try {
      const r = await api('POST', '/api/command', { client: Z.state.client, text, session: sid });
      say('a', r.text, r.mode === 'regras' ? 'modo offline · regras locais' : r.mode === 'acao' ? 'ação executada' : 'Zentry IA');
      if (spoken || Voice.speakOn) Voice.speak(r.text);
      else Voice.state(Voice.listening ? 'listening' : 'idle');
      if (r.mode === 'acao') refreshBadges();
    } catch (e) { say('a', e.message, 'erro'); Voice.state(Voice.listening ? 'listening' : 'idle'); }
  }
  const labels = { idle: 'Microfone desligado', listening: Voice.wake ? 'Ouvindo — diga “Zentry, …”' : 'Ouvindo…', thinking: 'Pensando…', speaking: 'Falando…' };
  Voice.onState = st => { orb.className = 'orb ' + (st === 'idle' ? 'off' : st); status.textContent = labels[st] || ''; };
  Voice.onCommand = (cmd, spoken) => ask(cmd, spoken);
  Voice.onState(Voice.listening ? 'listening' : 'idle');
  orb.addEventListener('click', () => { if (Voice.listening) Voice.stop(); else Voice.start(); });
  token.cleanup = () => { Voice.stop(); Voice.onState = null; Voice.onCommand = null; };
  input.addEventListener('keydown', e => { if (e.key === 'Enter') ask(input.value, false); });
  const toggle = (label, key, prop) => h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: Voice[prop], onchange: e => { Voice[prop] = e.target.checked; store.set(key, e.target.checked ? '1' : '0'); Voice.onState(Voice.status || 'idle'); } }), label);
  const chips = ['O que aconteceu hoje?', 'Resumo dos alertas abertos', 'Algum equipamento com problema?', 'O que você aprendeu?', 'Gerar relatório da semana'];
  add(root, h('div', { class: 'chatwrap' },
    h('div', { class: 'card', style: 'display:flex;flex-direction:column;min-height:0' }, msgs, h('div', { class: 'composer' }, input, h('button', { class: 'btn pri', onclick: () => ask(input.value, false) }, 'Enviar'))),
    h('div', { class: 'card orbbox' }, orb, status,
      h('div', { style: 'text-align:left;width:100%' }, toggle('Exigir a palavra “Zentry”', 'z.wake', 'wake'), toggle('Falar as respostas', 'z.speak', 'speakOn')),
      Voice.SR ? null : h('div', { class: 'note warn' }, 'Seu navegador não reconhece voz. Use o Chrome ou o Edge para dar comandos falados.'),
      h('div', { class: 'chips' }, chips.map(c => h('span', { class: 'chip', role: 'button', tabindex: 0, onclick: () => ask(c, false) }, c))))));
  say('a', 'Olá! Sou o Zentry IA. Pergunte sobre alertas, equipamentos ou pessoas, peça relatórios, ou diga “marcar alerta 12 como resolvido”.', Z.state.overview && Z.state.overview.llm ? 'conversa com IA ativa' : 'modo offline · regras locais');
  const m = location.hash.match(/ask=([^&]+)/);
  if (m) { const t = decodeURIComponent(m[1]); history.replaceState(null, '', '#/chat'); ask(t, false); }
};

Z.pages.diagnostics = async function (soft, root) {
  const d = await api('GET', '/api/diagnostics');
  clear(root);
  const row = (k, v, ok) => h('tr', {}, h('td', { class: 'muted' }, k), h('td', { class: 'mono' }, v), h('td', {}, ok == null ? null : h('span', { class: 'badge ' + (ok ? 'b-ok' : 'b-atencao') }, ok ? 'ok' : 'atenção')));
  add(root, h('div', { class: 'grid g2' },
    h('div', { class: 'card' }, h('h2', {}, 'Sistema'), h('table', {}, h('tbody', {},
      row('Versão do Zentry', d.version), row('Python', d.python), row('Sistema', d.os), row('Tempo ligado', fmt.ago(d.uptime_s)), row('Pasta de dados', d.home), row('Fuso horário', d.tz), row('Detectores', String(d.detectors)), row('Backups guardados', String(d.backups), d.backups > 0)))),
    h('div', { class: 'card' }, h('h2', {}, 'Dados e recursos'), h('table', {}, h('tbody', {},
      row('Eventos no banco', fmt.n(d.db_events)), row('Alertas no banco', fmt.n(d.db_alerts)), row('Último evento há', fmt.ago(d.last_event_age), d.last_event_age != null && d.last_event_age < 3600),
      row('Conversa com IA (Claude)', d.chat_ia ? 'configurada' : 'sem chave — usa regras locais', d.chat_ia), row('Voz do computador', d.voice_pc ? 'disponível' : 'indisponível', d.voice_pc)))),
  ));
  if (isAdmin()) {
    const rp = await api('GET', '/api/recent-pushes');
    add(root, h('div', { class: 'card', style: 'margin-top:16px' }, h('h2', {}, 'Últimos envios dos equipamentos', h('span', { class: 'sp' }), h('button', { class: 'btn sm', onclick: refreshPage }, 'Atualizar')),
      h('div', { class: 'note', style: 'margin-bottom:10px' }, 'O que os equipamentos mandaram de fato. Use isto para validar marcas e códigos de evento: se “eventos” for 0, o formato ou o código não foi reconhecido.'),
      rp.pushes.length ? h('div', { class: 'tablewrap' }, h('table', {}, h('thead', {}, h('tr', {}, ['Quando', 'IP', 'Marca', 'Caminho', 'Eventos', 'Amostra'].map(x => h('th', {}, x)))),
        h('tbody', {}, rp.pushes.map(p => h('tr', {}, h('td', { class: 'dim' }, fmt.tm(p.ts)), h('td', { class: 'mono' }, p.ip), h('td', {}, p.brand), h('td', { class: 'mono dim' }, p.path),
          h('td', { class: 'mono ' + (p.events ? 'c-green' : 'c-amber') }, p.events), h('td', { class: 'mono dim', style: 'max-width:380px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap', title: p.sample }, p.sample)))))) : h('div', { class: 'empty' }, 'Nada recebido desde que o Zentry iniciou.')));
  }
};

/* ---------------------------------------------------------------- shell e rotas */
const NAV = [
  ['command', 'Comando', 'command'], ['alerts', 'Alertas', 'alert'], ['devices', 'Equipamentos', 'device'], ['people', 'Pessoas', 'people'], ['live', 'Ao vivo', 'live'],
  ['learning', 'Aprendizado', 'brain'], ['reports', 'Relatórios', 'report'], ['chat', 'Zentry', 'chat'], ['config', 'Configurações', 'gear', true], ['diagnostics', 'Diagnóstico', 'pulse'],
];
const TITLES = { command: 'Centro de comando', alerts: 'Alertas', devices: 'Equipamentos', people: 'Pessoas', live: 'Ao vivo', learning: 'Aprendizado', reports: 'Relatórios', chat: 'Converse com o Zentry', config: 'Configurações', diagnostics: 'Diagnóstico' };

function shell() {
  const app = clear($('#app'));
  const nav = h('nav', { class: 'nav', 'aria-label': 'Principal' }, NAV.filter(n => !n[3] || isAdmin()).map(([id, label, ic]) =>
    h('a', { href: '#/' + id, 'data-id': id }, icon(ic), label, id === 'alerts' ? h('span', { class: 'badge b-critico', id: 'nav-alerts', hidden: true }) : null)));
  const main = h('main', { class: 'main', id: 'main' });
  add(app, h('div', { class: 'shell' },
    h('aside', { class: 'side' }, h('div', { class: 'brand' }, h('i', {}, 'Z'), 'ZENTRY'), nav,
      h('div', { class: 'foot' }, h('div', {}, Z.state.user.display_name || Z.state.user.username), h('div', {}, Z.state.user.role),
        h('div', { class: 'row', style: 'margin-top:8px' }, h('button', { class: 'btn sm', onclick: logout }, 'Sair')))),
    main));
  return main;
}
async function logout() { try { await api('POST', '/api/logout', {}); } catch (e) { /* já saiu */ } Z.state.user = null; route(); }

function updateBadges() {
  const ov = Z.state.overview; const b = $('#nav-alerts');
  if (b && ov) { b.hidden = !ov.open_total; b.textContent = ov.open_total; b.className = 'badge ' + (ov.open_critical ? 'b-critico' : 'b-atencao'); }
}
async function refreshBadges() { try { Z.state.overview = await api('GET', q('/api/overview')); updateBadges(); watchCritical(Z.state.overview); } catch (e) { /* ignora */ } loadUpdate(); }
let seenCritical = null;
function watchCritical(ov) {
  const ids = new Set((ov.top_alerts || []).filter(a => a.severity === 'critico').map(a => a.id));
  if (seenCritical) for (const id of ids) if (!seenCritical.has(id)) {
    const a = ov.top_alerts.find(x => x.id === id);
    toast('🚨 ' + a.title, 'critico', 9000);
    if (Voice.speakOn && store.get('z.alertvoice') === '1') Voice.speak('Alerta crítico. ' + a.title);
  }
  seenCritical = ids;
}

/* ---------------------------------------------------------------- atualizações */
async function loadUpdate() { try { Z.state.update = await api('GET', '/api/update'); } catch (e) { /* sem rede: ignora */ } renderBanner(); }
function updateBanner() {
  const u = Z.state.update;
  if (!u || !u.available || !u.latest) return null;
  const st = u.state || {};
  const busy = ['downloading', 'verifying', 'installing', 'restarting'].includes(st.phase);
  const msg = st.phase === 'downloading' ? `Baixando a atualização… ${st.progress}%` : st.phase === 'verifying' ? 'Conferindo a integridade do arquivo…'
    : st.phase === 'installing' || st.phase === 'restarting' ? 'Instalando… o Zentry vai fechar e reabrir sozinho.' : null;
  return h('div', { class: 'upd', id: 'upd-banner', role: 'status' },
    h('span', { class: 'dot pulse' }),
    h('div', { style: 'flex:1;min-width:0' }, h('b', {}, `Atualização disponível: Zentry ${u.latest.version}`), h('span', { class: 'muted' }, ` (você usa ${u.current})`),
      msg ? h('div', { class: 'muted' }, msg) : null, st.phase === 'error' ? h('div', { class: 'err' }, st.error) : null,
      busy ? h('div', { class: 'bar', style: 'margin-top:6px' }, h('i', { style: `width:${st.progress || 5}%` })) : null,
      !u.can_install && u.platform_note ? h('div', { class: 'muted' }, u.platform_note) : null),
    h('button', { class: 'btn sm', onclick: () => showNotes(u) }, 'Novidades'),
    isAdmin() && u.can_install ? h('button', { class: 'btn pri sm', disabled: busy, onclick: () => installUpdate(u) }, 'Baixar e instalar') : null,
    !u.can_install && u.latest.url ? h('a', { class: 'btn sm', href: u.latest.url, target: '_blank', rel: 'noopener noreferrer' }, 'Baixar na página') : null);
}
function renderBanner() {
  const old = $('#upd-banner'), nb = updateBanner();
  if (old) old.remove();
  const main = $('#main');
  if (nb && main) main.prepend(nb);
  const link = document.querySelector('.nav a[data-id="config"]');
  if (link) link.dataset.upd = Z.state.update && Z.state.update.available ? '1' : '';
}
function showNotes(u) {
  const scrim = h('div', { class: 'scrim', onclick: close });
  const box = h('aside', { class: 'drawer', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Novidades da versão' },
    h('div', { class: 'row' }, h('span', { class: 'badge b-info' }, 'v' + u.latest.version), h('span', { class: 'sp' }), h('button', { class: 'btn sm', onclick: close }, 'Fechar')),
    h('h3', {}, u.latest.name || 'Novidades'), h('div', { style: 'white-space:pre-wrap;color:var(--muted)' }, u.latest.notes || 'Sem notas de versão.'));
  function close() { scrim.remove(); box.remove(); }
  document.body.append(scrim, box);
}
async function installUpdate(u) {
  if (!confirm(`Instalar o Zentry ${u.latest.version} agora?\n\nO programa fecha e reabre sozinho (alguns segundos). Seus dados e configurações são mantidos e um backup é feito antes.`)) return;
  try { await api('POST', '/api/update/install', {}); } catch (e) { toast(e.message, 'critico'); return; }
  const timer = setInterval(async () => {
    try { await loadUpdate(); } catch (e) { /* o servidor reiniciando derruba a conexão: esperado */ }
    const ph = ((Z.state.update || {}).state || {}).phase;
    if (ph === 'error') clearInterval(timer);
    if (ph === 'installing' || ph === 'restarting') {
      clearInterval(timer);
      const wait = setInterval(async () => { try { const r = await fetch('/health', { cache: 'no-store' }); const j = await r.json(); if (j.version && j.version !== Z.state.update.current) { clearInterval(wait); location.reload(); } } catch (e) { /* ainda reiniciando */ } }, 3000);
    }
  }, 1500);
}
Z.loadUpdate = loadUpdate;

let pageToken = null;
async function route() {
  if (pageToken) { pageToken.dead = true; clearInterval(pageToken.timer); if (pageToken.cleanup) pageToken.cleanup(); pageToken = null; }
  currentRender = null;
  let sess;
  try { sess = await api('GET', '/api/session'); } catch (e) { return fatal(e.message); }
  Z.state.user = sess.user; Z.version = sess.version;
  if (sess.setup_needed) return Z.wizard(route);
  if (!sess.user) return Z.login(route);
  const id = (location.hash.replace(/^#\/?/, '').split(/[?/]/)[0]) || 'command';
  const page = Z.pages[id] ? id : 'command';
  if (page === 'config' && !isAdmin()) { location.hash = '#/command'; return; }
  let main = $('#main');
  if (!main) {
    main = shell();
    try {
      const ov = await api('GET', '/api/overview'); Z.state.clients = ov.clients; Z.state.client = Z.state.client || ov.client;
      Z.state.overview = ov;
    } catch (e) { /* segue */ }
  }
  for (const a of document.querySelectorAll('.nav a')) a.classList.toggle('on', a.dataset.id === page);
  const top = h('div', { class: 'top' }, h('h1', {}, TITLES[page]), h('span', { class: 'sp' }),
    Z.state.clients.length > 1 ? h('select', { style: 'width:auto', 'aria-label': 'Cliente', onchange: e => { Z.state.client = e.target.value; route(); } }, Z.state.clients.map(c => h('option', { value: c.id, selected: c.id === Z.state.client }, c.name))) : null,
    h('span', { class: 'pill' }, h('span', { class: 'dot pulse' }), Z.state.clients.length === 1 ? Z.state.clients[0].name : 'online'));
  const body = h('div', { id: 'page' });
  clear(main); add(main, [updateBanner(), top, body]);
  const token = pageToken = { dead: false };
  currentRender = async soft => {
    try { await Z.pages[page](soft, soft ? clear(body) : body, token); } catch (e) { clear(body); add(body, h('div', { class: 'card' }, h('div', { class: 'err' }, e.message))); }
  };
  updateBadges();
  loadUpdate();
  await currentRender(false);
  if (['command', 'alerts', 'devices'].includes(page)) token.timer = setInterval(() => { if (!token.dead && !document.querySelector('.drawer')) { currentRender(true); refreshBadges(); } }, 15000);
  else if (page !== 'live') { clearInterval(token.timer); token.timer = setInterval(refreshBadges, 20000); }
  if (page === 'live') token.timer2 = null;
}
function fatal(msg) { const a = clear($('#app')); add(a, h('div', { class: 'auth' }, h('div', { class: 'card authbox' }, h('h2', {}, 'Zentry IA'), h('div', { class: 'err' }, msg), h('button', { class: 'btn', onclick: () => location.reload() }, 'Tentar de novo')))); }

/* ---------------------------------------------------------------- login e assistente de instalação */
function authFrame(title, ...kids) {
  const a = clear($('#app'));
  add(a, h('div', { class: 'auth' }, h('div', { class: 'authbox' }, h('div', { class: 'logo' }, 'ZENTRY', h('small', {}, 'INTELIGÊNCIA PARA CONTROLE DE ACESSO')), h('div', { class: 'card' }, title ? h('h2', {}, title) : null, kids))));
}
Z.login = function (done) {
  const u = h('input', { class: 'input', autocomplete: 'username', autofocus: true, 'aria-label': 'Usuário' });
  const p = h('input', { class: 'input', type: 'password', autocomplete: 'current-password', 'aria-label': 'Senha' });
  const e = h('div', { class: 'err', role: 'alert' });
  const go = async () => {
    e.textContent = '';
    try { await api('POST', '/api/login', { username: u.value, password: p.value }); location.hash = '#/command'; done(); } catch (x) { e.textContent = x.message; }
  };
  p.addEventListener('keydown', k => { if (k.key === 'Enter') go(); });
  authFrame('Entrar', h('label', { class: 'f' }, h('span', {}, 'Usuário'), u), h('label', { class: 'f' }, h('span', {}, 'Senha'), p), e, h('button', { class: 'btn pri', style: 'width:100%;justify-content:center', onclick: go }, 'Entrar'));
};
Z.wizard = function (done) {
  const d = { step: 0 };
  const f = { name: h('input', { class: 'input', placeholder: 'Ex.: Condomínio Aurora' }), user: h('input', { class: 'input', autocomplete: 'username', value: 'admin' }), disp: h('input', { class: 'input', placeholder: 'Seu nome' }),
    pw: h('input', { class: 'input', type: 'password', autocomplete: 'new-password' }), pw2: h('input', { class: 'input', type: 'password', autocomplete: 'new-password' }),
    tz: h('select', {}, ['America/Sao_Paulo', 'America/Manaus', 'America/Fortaleza', 'America/Cuiaba', 'America/Rio_Branco', 'UTC'].map(z => h('option', { value: z }, z))) };
  const err = h('div', { class: 'err', role: 'alert' });
  const steps = () => h('div', { class: 'steps' }, [0, 1, 2].map(i => h('i', { class: i <= d.step ? 'on' : '' })));
  const draw = () => {
    err.textContent = '';
    if (d.step === 0) authFrame('Bem-vindo ao Zentry IA', steps(), h('p', { class: 'muted' }, 'Vamos configurar em um minuto. O banco de dados já foi criado neste computador — nada sai daqui sem você mandar.'),
      h('div', { class: 'note' }, 'O Zentry observa seus equipamentos e avisa sobre falhas e riscos. Ele não libera nem bloqueia acessos.'), h('div', { style: 'height:14px' }), h('button', { class: 'btn pri', style: 'width:100%;justify-content:center', onclick: () => { d.step = 1; draw(); } }, 'Começar'));
    else if (d.step === 1) authFrame('Conta do administrador', steps(), h('label', { class: 'f' }, h('span', {}, 'Seu nome'), f.disp), h('label', { class: 'f' }, h('span', {}, 'Usuário'), f.user),
      h('label', { class: 'f' }, h('span', {}, 'Senha (mínimo 8 caracteres)'), f.pw), h('label', { class: 'f' }, h('span', {}, 'Repita a senha'), f.pw2), err,
      h('div', { class: 'row' }, h('button', { class: 'btn', onclick: () => { d.step = 0; draw(); } }, 'Voltar'), h('span', { class: 'sp' }), h('button', { class: 'btn pri', onclick: () => {
        if (f.pw.value.length < 8) { err.textContent = 'A senha precisa ter pelo menos 8 caracteres.'; return; }
        if (f.pw.value !== f.pw2.value) { err.textContent = 'As senhas não conferem.'; return; }
        if (!f.user.value.trim()) { err.textContent = 'Informe o usuário.'; return; }
        d.step = 2; draw(); } }, 'Continuar')));
    else authFrame('Seu primeiro cliente', steps(), h('label', { class: 'f' }, h('span', {}, 'Nome do local / cliente'), f.name), h('label', { class: 'f' }, h('span', {}, 'Fuso horário'), f.tz),
      h('div', { class: 'note' }, 'Equipamentos, notificações e a chave de IA ficam em Configurações, depois de entrar.'), err, h('div', { style: 'height:12px' }),
      h('div', { class: 'row' }, h('button', { class: 'btn', onclick: () => { d.step = 1; draw(); } }, 'Voltar'), h('span', { class: 'sp' }), h('button', { class: 'btn pri', onclick: async () => {
        try { await api('POST', '/api/setup', { username: f.user.value, password: f.pw.value, display_name: f.disp.value, client_name: f.name.value, timezone: f.tz.value }); location.hash = '#/command'; done(); } catch (x) { err.textContent = x.message; } } }, 'Concluir')));
  };
  draw();
};

window.addEventListener('hashchange', () => { if (Z.state.user) route(); });
window.addEventListener('load', route);
})();
