"""ZKTeco (protocolo PUSH / “ADMS”): o equipamento fala com o servidor em /iclock/cdata.

No equipamento: Comunicação → Configuração de nuvem/ADMS → endereço do servidor = IP deste PC, porta 8000.
O número de série (SN) do equipamento é o ID cadastrado aqui.
"""

import json
import time

from ..config import resolve_device
from .base import Connector
from .common import parse_ts

# eventtype do tempo real (controle de acesso): 0 = abertura normal; 100+ = alarmes; demais = negação
RTLOG_GRANT = {0}


def parse_kv_line(line):
    return dict(p.split("=", 1) for p in line.strip().split("\t") if "=" in p)


def parse_rtlog(body):
    out = []
    for line in (body or "").splitlines():
        r = parse_kv_line(line)
        if not r:
            continue
        et = int(r["eventtype"]) if str(r.get("eventtype", "")).lstrip("-").isdigit() else None
        kind = "grant" if et in RTLOG_GRANT else ("alarm" if et is not None and et >= 100 else "deny")
        uid = r.get("pin") or r.get("cardno")
        out.append({"ts": parse_ts(r.get("time")), "kind": kind, "user_id": uid if uid not in ("", "0") else None,
                    "user_name": None, "code": et, "src_id": r.get("index"), "portal_id": r.get("linkid")})
    return out


def parse_attlog(body):
    out = []
    for line in (body or "").splitlines():
        p = line.rstrip("\r\n").split("\t")
        if len(p) >= 2 and p[0]:
            out.append({"ts": parse_ts(p[1]), "kind": "grant", "user_id": p[0], "user_name": None,
                        "code": int(p[3]) if len(p) > 3 and p[3].isdigit() else None, "src_id": f"{p[0]}-{p[1]}", "portal_id": None})
    return out


class ZktecoConnector(Connector):
    name = "zkteco"
    label = "ZKTeco (PUSH / ADMS)"
    push_path = "/iclock/cdata"
    help = ("PUSH: no equipamento, configure o servidor ADMS/nuvem com o IP deste PC e a porta 8000. "
            "Cadastre o equipamento com o ID igual ao número de série (SN). Os códigos de evento seguem o padrão ZKTeco "
            "(0 = liberado, 100+ = alarme, demais = negado); confira no seu modelo.")

    def handle_push(self, cfg, store, path, query, body, ip, now=None):
        now = int(now if now is not None else time.time())
        sn = (query.get("SN") or [None])[0] if isinstance(query.get("SN"), list) else query.get("SN")
        client, did = resolve_device(cfg, sn, ip)
        store.heartbeat(client, did, now)
        if path.endswith("/getrequest") or path.endswith("/registry"):
            return 200, "OK", 0
        text = body.decode("utf-8", errors="replace") if isinstance(body, (bytes, bytearray)) else (body or "")
        if not text.strip():  # handshake inicial (GET /iclock/cdata?SN=..&options=all)
            return 200, (f"GET OPTION FROM: {sn}\nErrorDelay=60\nDelay=30\nTransTimes=00:00;14:05\nTransInterval=1\n"
                         "TransFlag=TransData AttLog\tOpLog\nRealtime=1\nEncrypt=None"), 0
        table = (query.get("table") or [""])[0] if isinstance(query.get("table"), list) else query.get("table", "")
        evs = parse_rtlog(text) if table.lower() == "rtlog" else parse_attlog(text) if table.upper() == "ATTLOG" else []
        n = 0
        for e in evs:
            if e["ts"] is None:
                continue
            n += int(store.add_event(client, did, e["ts"], e["kind"], e["user_id"], e["user_name"], e["portal_id"], e["code"],
                                     e["src_id"], json.dumps(e, ensure_ascii=False), live=True, now=now))
        return 200, "OK", n
