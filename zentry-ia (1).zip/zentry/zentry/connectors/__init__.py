"""Conectores: como o Zentry conversa com cada marca de equipamento.

Para suportar outra marca, crie uma subclasse de `Connector` (veja docs/conectores.md) e registre em REGISTRY.
A marca vale por equipamento (`brand`) ou, se ausente, pelo cliente (`connector`); o padrão é `controlid`.
"""

from .axis import AxisConnector
from .base import Connector, device_brand
from .controlid import ControlIdConnector
from .dahua import DahuaConnector, IntelbrasConnector
from .generic import GenericConnector
from .hikvision import HikvisionConnector
from .zkteco import ZktecoConnector

_CLASSES = [ControlIdConnector, HikvisionConnector, IntelbrasConnector, DahuaConnector, AxisConnector, ZktecoConnector,
            GenericConnector]
REGISTRY = {c.name: c for c in _CLASSES}


def get(cfg=None, client=None, brand=None):
    name = brand or (((cfg or {}).get("clients", {}).get(client, {}) or {}).get("connector") if client else None) or "controlid"
    return REGISTRY.get(name, ControlIdConnector)()


def all_connectors():
    return [c() for c in _CLASSES]
